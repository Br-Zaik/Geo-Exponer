package com.brian.geoexponer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.KeyEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ExpoPlaybackService extends Service {
    public static final String ACTION_START = "com.brian.geoexponer.START";
    public static final String ACTION_TOGGLE = "com.brian.geoexponer.TOGGLE";
    public static final String ACTION_REPEAT = "com.brian.geoexponer.REPEAT";
    public static final String ACTION_NEXT = "com.brian.geoexponer.NEXT";
    public static final String ACTION_STOP = "com.brian.geoexponer.STOP";
    public static final String ACTION_STATUS = "com.brian.geoexponer.STATUS";

    public static final String EXTRA_TEXT = "text";
    public static final String EXTRA_SPEED = "speed";
    public static final String EXTRA_PAUSE_MS = "pause_ms";
    public static final String EXTRA_PHRASE = "phrase";
    public static final String EXTRA_INDEX = "index";
    public static final String EXTRA_TOTAL = "total";
    public static final String EXTRA_STATE = "state";

    public static final String STATE_PLAYING = "playing";
    public static final String STATE_WAITING = "waiting";
    public static final String STATE_PAUSED = "paused";
    public static final String STATE_STOPPED = "stopped";
    public static final String STATE_ERROR = "error";

    private static final String CHANNEL_ID = "geo_exponer_playback";
    private static final int NOTIFICATION_ID = 2026;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> phrases = new ArrayList<>();

    private TextToSpeech tts;
    private MediaSession mediaSession;
    private boolean ttsReady = false;
    private boolean pendingStart = false;
    private boolean running = false;
    private boolean paused = false;
    private int index = 0;
    private int pauseMs = 5000;
    private float speechRate = 1.0f;
    private String currentState = STATE_STOPPED;
    private int utteranceCounter = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        setupMediaSession();
        setupTextToSpeech();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIFICATION_ID, buildNotification());

        String action = intent != null ? intent.getAction() : null;
        if (ACTION_START.equals(action)) {
            startNewPractice(intent);
        } else if (ACTION_TOGGLE.equals(action)) {
            togglePlayback();
        } else if (ACTION_REPEAT.equals(action)) {
            repeatPhrase();
        } else if (ACTION_NEXT.equals(action)) {
            nextPhrase();
        } else if (ACTION_STOP.equals(action)) {
            stopPractice();
        } else {
            broadcastStatus(currentState);
        }

        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (mediaSession != null) {
            mediaSession.setActive(false);
            mediaSession.release();
        }
        super.onDestroy();
    }

    private void setupTextToSpeech() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true;
                int languageResult = tts.setLanguage(new Locale("es", "ES"));
                if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.getDefault());
                }
                tts.setPitch(1.0f);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                        handler.post(() -> {
                            currentState = STATE_PLAYING;
                            updatePlaybackState();
                            broadcastStatus(STATE_PLAYING);
                            refreshNotification();
                        });
                    }

                    @Override
                    public void onDone(String utteranceId) {
                        handler.post(() -> onSpeechDone());
                    }

                    @Override
                    public void onError(String utteranceId) {
                        handler.post(() -> {
                            currentState = STATE_ERROR;
                            updatePlaybackState();
                            broadcastStatus(STATE_ERROR);
                            refreshNotification();
                        });
                    }
                });

                if (pendingStart) {
                    pendingStart = false;
                    speakCurrentPhrase();
                }
            } else {
                currentState = STATE_ERROR;
                broadcastStatus(STATE_ERROR);
                refreshNotification();
            }
        });
    }

    private void setupMediaSession() {
        mediaSession = new MediaSession(this, "GeoExponerSession");
        mediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent sessionActivity = PendingIntent.getActivity(this, 1, openIntent, pendingFlags());
        mediaSession.setSessionActivity(sessionActivity);

        mediaSession.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() {
                resumePlayback();
            }

            @Override
            public void onPause() {
                pausePlayback();
            }

            @Override
            public void onStop() {
                stopPractice();
            }

            @Override
            public void onSkipToNext() {
                nextPhrase();
            }

            @Override
            public void onSkipToPrevious() {
                repeatPhrase();
            }

            @Override
            public boolean onMediaButtonEvent(Intent mediaButtonIntent) {
                KeyEvent event = mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
                if (event == null || event.getAction() != KeyEvent.ACTION_UP) {
                    return true;
                }

                int code = event.getKeyCode();
                if (code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code == KeyEvent.KEYCODE_HEADSETHOOK) {
                    togglePlayback();
                    return true;
                } else if (code == KeyEvent.KEYCODE_MEDIA_PLAY) {
                    resumePlayback();
                    return true;
                } else if (code == KeyEvent.KEYCODE_MEDIA_PAUSE) {
                    pausePlayback();
                    return true;
                } else if (code == KeyEvent.KEYCODE_MEDIA_NEXT) {
                    nextPhrase();
                    return true;
                } else if (code == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
                    repeatPhrase();
                    return true;
                }
                return super.onMediaButtonEvent(mediaButtonIntent);
            }
        });

        mediaSession.setActive(true);
        updatePlaybackState();
    }

    private void startNewPractice(Intent intent) {
        String text = intent.getStringExtra(EXTRA_TEXT);
        speechRate = intent.getFloatExtra(EXTRA_SPEED, 1.0f);
        pauseMs = intent.getIntExtra(EXTRA_PAUSE_MS, 5000);

        phrases.clear();
        phrases.addAll(splitText(text));
        index = 0;
        paused = false;
        running = phrases.size() > 0;
        handler.removeCallbacksAndMessages(null);

        if (!running) {
            currentState = STATE_ERROR;
            broadcastStatus(STATE_ERROR);
            refreshNotification();
            return;
        }

        if (ttsReady) {
            speakCurrentPhrase();
        } else {
            pendingStart = true;
            currentState = STATE_WAITING;
            broadcastStatus(STATE_WAITING);
            refreshNotification();
        }
    }

    private void speakCurrentPhrase() {
        if (!running || paused || phrases.isEmpty()) return;

        if (index < 0) index = 0;
        if (index >= phrases.size()) {
            stopPractice();
            return;
        }

        handler.removeCallbacksAndMessages(null);
        currentState = STATE_PLAYING;
        updatePlaybackState();
        broadcastStatus(STATE_PLAYING);
        refreshNotification();

        if (tts != null && ttsReady) {
            tts.stop();
            tts.setSpeechRate(speechRate);
            Bundle params = new Bundle();
            String utteranceId = "geo_exponer_" + (++utteranceCounter);
            tts.speak(phrases.get(index), TextToSpeech.QUEUE_FLUSH, params, utteranceId);
        }
    }

    private void onSpeechDone() {
        if (!running || paused || phrases.isEmpty()) return;

        currentState = STATE_WAITING;
        updatePlaybackState();
        broadcastStatus(STATE_WAITING);
        refreshNotification();

        handler.postDelayed(() -> {
            if (!running || paused) return;
            index++;
            speakCurrentPhrase();
        }, pauseMs);
    }

    private void togglePlayback() {
        if (!running || phrases.isEmpty()) {
            broadcastStatus(currentState);
            return;
        }

        if (paused || STATE_WAITING.equals(currentState)) {
            resumePlayback();
        } else {
            pausePlayback();
        }
    }

    private void pausePlayback() {
        if (!running) return;
        paused = true;
        handler.removeCallbacksAndMessages(null);
        if (tts != null) tts.stop();
        currentState = STATE_PAUSED;
        updatePlaybackState();
        broadcastStatus(STATE_PAUSED);
        refreshNotification();
    }

    private void resumePlayback() {
        if (!running || phrases.isEmpty()) return;
        paused = false;
        speakCurrentPhrase();
    }

    private void repeatPhrase() {
        if (!running || phrases.isEmpty()) return;
        paused = false;
        speakCurrentPhrase();
    }

    private void nextPhrase() {
        if (!running || phrases.isEmpty()) return;
        paused = false;
        index++;
        speakCurrentPhrase();
    }

    private void stopPractice() {
        running = false;
        paused = false;
        pendingStart = false;
        handler.removeCallbacksAndMessages(null);
        if (tts != null) tts.stop();
        currentState = STATE_STOPPED;
        updatePlaybackState();
        broadcastStatus(STATE_STOPPED);
        stopForeground(true);
        stopSelf();
    }

    private void broadcastStatus(String state) {
        Intent intent = new Intent(ACTION_STATUS);
        intent.setPackage(getPackageName());
        intent.putExtra(EXTRA_STATE, state);
        intent.putExtra(EXTRA_INDEX, phrases.isEmpty() ? 0 : index + 1);
        intent.putExtra(EXTRA_TOTAL, phrases.size());
        if (!phrases.isEmpty() && index >= 0 && index < phrases.size()) {
            intent.putExtra(EXTRA_PHRASE, phrases.get(index));
        } else {
            intent.putExtra(EXTRA_PHRASE, "");
        }
        sendBroadcast(intent);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Geo Exponer",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Controles de práctica de exposición");
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPendingIntent = PendingIntent.getActivity(this, 20, openIntent, pendingFlags());

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        String title = "Geo Exponer";
        String text = notificationText();

        builder.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(openPendingIntent)
                .setShowWhen(false)
                .setOngoing(running && !STATE_STOPPED.equals(currentState))
                .setVisibility(Notification.VISIBILITY_PUBLIC);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            builder.addAction(makeAction(ACTION_REPEAT, "Repetir", 31));
            builder.addAction(makeAction(ACTION_TOGGLE, paused ? "Reanudar" : "Pausar", 32));
            builder.addAction(makeAction(ACTION_NEXT, "Siguiente", 33));
            builder.addAction(makeAction(ACTION_STOP, "Detener", 34));
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && mediaSession != null) {
            builder.setStyle(new Notification.MediaStyle()
                    .setMediaSession(mediaSession.getSessionToken())
                    .setShowActionsInCompactView(0, 1, 2));
        }

        return builder.build();
    }

    private Notification.Action makeAction(String action, String title, int requestCode) {
        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(action);
        PendingIntent pendingIntent = PendingIntent.getService(this, requestCode, intent, pendingFlags());
        Icon icon = Icon.createWithResource(this, R.drawable.ic_notification);
        return new Notification.Action.Builder(icon, title, pendingIntent).build();
    }

    private void refreshNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(NOTIFICATION_ID, buildNotification());
        }
    }

    private String notificationText() {
        if (phrases.isEmpty() || index < 0 || index >= phrases.size()) {
            return "Listo para practicar";
        }
        String prefix;
        if (STATE_PAUSED.equals(currentState)) prefix = "Pausado";
        else if (STATE_WAITING.equals(currentState)) prefix = "Repite ahora";
        else if (STATE_PLAYING.equals(currentState)) prefix = "Escucha";
        else prefix = "Geo Exponer";

        String phrase = phrases.get(index);
        if (phrase.length() > 55) phrase = phrase.substring(0, 55) + "...";
        return prefix + ": " + phrase;
    }

    private void updatePlaybackState() {
        if (mediaSession == null) return;

        int playbackState;
        if (STATE_PLAYING.equals(currentState) || STATE_WAITING.equals(currentState)) {
            playbackState = PlaybackState.STATE_PLAYING;
        } else if (STATE_PAUSED.equals(currentState)) {
            playbackState = PlaybackState.STATE_PAUSED;
        } else {
            playbackState = PlaybackState.STATE_STOPPED;
        }

        long actions = PlaybackState.ACTION_PLAY
                | PlaybackState.ACTION_PAUSE
                | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_STOP
                | PlaybackState.ACTION_SKIP_TO_NEXT
                | PlaybackState.ACTION_SKIP_TO_PREVIOUS;

        PlaybackState state = new PlaybackState.Builder()
                .setActions(actions)
                .setState(playbackState, PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1.0f)
                .build();
        mediaSession.setPlaybackState(state);
    }

    private int pendingFlags() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return flags;
    }

    private List<String> splitText(String text) {
        List<String> result = new ArrayList<>();
        if (text == null) return result;

        String cleaned = text
                .replace("\r", "\n")
                .replaceAll("[\t ]+", " ")
                .replaceAll("\n{3,}", "\n\n")
                .trim();

        if (cleaned.length() == 0) return result;

        String[] paragraphs = cleaned.split("\\n+");
        for (String paragraph : paragraphs) {
            paragraph = paragraph.trim();
            if (paragraph.length() == 0) continue;

            String[] firstCuts = paragraph.split("(?<=[.!?])\\s+");
            for (String cut : firstCuts) {
                addReadableChunks(result, cut.trim());
            }
        }

        if (result.isEmpty()) {
            result.add(cleaned);
        }
        return result;
    }

    private void addReadableChunks(List<String> result, String text) {
        if (text.length() == 0) return;

        if (text.length() <= 220) {
            result.add(text);
            return;
        }

        String[] commaCuts = text.split("(?<=[,;:])\\s+");
        StringBuilder buffer = new StringBuilder();
        for (String part : commaCuts) {
            part = part.trim();
            if (part.length() == 0) continue;

            if (buffer.length() + part.length() + 1 <= 220) {
                if (buffer.length() > 0) buffer.append(' ');
                buffer.append(part);
            } else {
                if (buffer.length() > 0) {
                    result.add(buffer.toString());
                    buffer.setLength(0);
                }
                if (part.length() <= 220) {
                    buffer.append(part);
                } else {
                    addByLength(result, part);
                }
            }
        }
        if (buffer.length() > 0) result.add(buffer.toString());
    }

    private void addByLength(List<String> result, String text) {
        int start = 0;
        while (start < text.length()) {
            int end = Math.min(start + 180, text.length());
            if (end < text.length()) {
                int space = text.lastIndexOf(' ', end);
                if (space > start + 60) end = space;
            }
            String chunk = text.substring(start, end).trim();
            if (chunk.length() > 0) result.add(chunk);
            start = end;
        }
    }
}
