package com.brian.geoexponer;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "geo_exponer_prefs";
    private static final String KEY_TEXT = "last_text";

    private EditText inputText;
    private TextView currentPhrase;
    private TextView statusText;
    private RadioButton speed075;
    private RadioButton speed100;
    private RadioButton speed125;
    private RadioButton pause3;
    private RadioButton pause5;
    private RadioButton pause8;
    private RadioButton pause10;

    private SharedPreferences prefs;

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!ExpoPlaybackService.ACTION_STATUS.equals(intent.getAction())) return;

            String phrase = intent.getStringExtra(ExpoPlaybackService.EXTRA_PHRASE);
            int index = intent.getIntExtra(ExpoPlaybackService.EXTRA_INDEX, 0);
            int total = intent.getIntExtra(ExpoPlaybackService.EXTRA_TOTAL, 0);
            String state = intent.getStringExtra(ExpoPlaybackService.EXTRA_STATE);

            if (phrase != null && phrase.trim().length() > 0) {
                currentPhrase.setText(phrase);
            }

            if (total > 0) {
                statusText.setText(stateText(state) + " - Frase " + index + " / " + total);
            } else {
                statusText.setText(stateText(state));
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        inputText = findViewById(R.id.inputText);
        currentPhrase = findViewById(R.id.currentPhrase);
        statusText = findViewById(R.id.statusText);
        speed075 = findViewById(R.id.speed075);
        speed100 = findViewById(R.id.speed100);
        speed125 = findViewById(R.id.speed125);
        pause3 = findViewById(R.id.pause3);
        pause5 = findViewById(R.id.pause5);
        pause8 = findViewById(R.id.pause8);
        pause10 = findViewById(R.id.pause10);

        Button startButton = findViewById(R.id.startButton);
        Button toggleButton = findViewById(R.id.toggleButton);
        Button repeatButton = findViewById(R.id.repeatButton);
        Button nextButton = findViewById(R.id.nextButton);
        Button stopButton = findViewById(R.id.stopButton);

        inputText.setText(prefs.getString(KEY_TEXT, ""));
        inputText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                prefs.edit().putString(KEY_TEXT, s.toString()).apply();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        requestNotificationPermissionIfNeeded();

        startButton.setOnClickListener(v -> startPractice());
        toggleButton.setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_TOGGLE));
        repeatButton.setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_REPEAT));
        nextButton.setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_NEXT));
        stopButton.setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_STOP));
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(ExpoPlaybackService.ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(statusReceiver, filter);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            unregisterReceiver(statusReceiver);
        } catch (IllegalArgumentException ignored) {
        }
    }

    private void startPractice() {
        String text = inputText.getText().toString().trim();
        if (text.length() < 2) {
            Toast.makeText(this, "Primero pega tu texto de exposición.", Toast.LENGTH_SHORT).show();
            return;
        }

        prefs.edit().putString(KEY_TEXT, text).apply();
        currentPhrase.setText("Preparando lectura...");
        statusText.setText("Iniciando práctica...");

        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(ExpoPlaybackService.ACTION_START);
        intent.putExtra(ExpoPlaybackService.EXTRA_TEXT, text);
        intent.putExtra(ExpoPlaybackService.EXTRA_SPEED, getSelectedSpeed());
        intent.putExtra(ExpoPlaybackService.EXTRA_PAUSE_MS, getSelectedPauseMs());
        startServiceCompat(intent);
    }

    private void sendSimpleAction(String action) {
        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(action);
        startServiceCompat(intent);
    }

    private void startServiceCompat(Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    private float getSelectedSpeed() {
        if (speed075.isChecked()) return 0.75f;
        if (speed125.isChecked()) return 1.25f;
        speed100.setChecked(true);
        return 1.0f;
    }

    private int getSelectedPauseMs() {
        if (pause3.isChecked()) return 3000;
        if (pause8.isChecked()) return 8000;
        if (pause10.isChecked()) return 10000;
        pause5.setChecked(true);
        return 5000;
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
            }
        }
    }

    private String stateText(String state) {
        if (ExpoPlaybackService.STATE_PLAYING.equals(state)) return "Reproduciendo";
        if (ExpoPlaybackService.STATE_PAUSED.equals(state)) return "Pausado";
        if (ExpoPlaybackService.STATE_STOPPED.equals(state)) return "Detenido";
        if (ExpoPlaybackService.STATE_WAITING.equals(state)) return "Pausa para repetir";
        if (ExpoPlaybackService.STATE_ERROR.equals(state)) return "Error";
        return "Listo";
    }
}
