# Geo Exponer

APK sencilla para practicar exposiciones.

## Función principal

El usuario pega su texto de exposición, la app lo divide en frases, lo lee con Text To Speech de Android por auriculares Bluetooth y hace pausas para que el usuario repita.

## Incluye

- Sin IA.
- Sin API.
- Sin Gemini.
- Sin login.
- Sin internet obligatorio.
- Pegar texto largo.
- Guardado automático del último texto.
- Lectura con voz Android.
- Pausa automática para repetir.
- Velocidad 0.75x, 1x y 1.25x.
- Pausa 3s, 5s, 8s y 10s.
- Botones: iniciar, pausar/reanudar, repetir, siguiente y detener.
- Notificación tipo reproductor.
- Funciona con pantalla apagada mediante servicio en primer plano.
- Botón de auricular: 1 clic pausa / otro clic reanuda, si el auricular manda comando multimedia.

## Nombre visible

Geo Exponer

## Paquete

com.brian.geoexponer
