package com.brian.geoexponer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.KeyEvent;

public class ButtonIntentReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;

        String action = intent.getAction();
        boolean toggle = false;

        if (Intent.ACTION_MEDIA_BUTTON.equals(action)) {
            KeyEvent event = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
            if (event != null && event.getAction() == KeyEvent.ACTION_UP) {
                int code = event.getKeyCode();
                toggle = code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                        || code == KeyEvent.KEYCODE_HEADSETHOOK
                        || code == KeyEvent.KEYCODE_ASSIST
                        || code == KeyEvent.KEYCODE_VOICE_ASSIST;
            }
        } else if (Intent.ACTION_VOICE_COMMAND.equals(action)) {
            toggle = true;
        }

        if (!toggle) return;

        Intent serviceIntent = new Intent(context, ExpoPlaybackService.class);
        serviceIntent.setAction(ExpoPlaybackService.ACTION_ASSIST_TOGGLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }

        if (isOrderedBroadcast()) {
            abortBroadcast();
        }
    }
}
