# Geo Exponer v1.5.6

APK para practicar exposiciones con Text To Speech de Android, sin IA, sin API, sin login y sin internet obligatorio.

## Cambios v1.5.6

- Corrige el cambio de velocidad durante la práctica.
- Si cambias de 0.75x a 1x, 1.25x, etc., la app aplica la nueva velocidad al momento.
- Si está pausado y cambias la velocidad, al reanudar ya usa la nueva velocidad.
- El botón Detener deja la voz preparada para que al iniciar otra vez responda más rápido.
- No se tocó el modo Manual, Automático, Mixto, power, volumen, texto editable, anterior/siguiente ni la lógica de pausas.

## Uso recomendado

Selecciona Mixto, elige 0s o 1s según tu práctica, inicia la lectura y cambia la velocidad cuando lo necesites. La app aplicará el cambio sin tener que detener toda la práctica.
