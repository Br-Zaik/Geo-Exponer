@echo off
set DIR=%~dp0
echo This project includes a custom Unix gradlew for GitHub Actions.
echo Open this project in Android Studio on Windows, or build it in GitHub Actions.
exit /b 1
