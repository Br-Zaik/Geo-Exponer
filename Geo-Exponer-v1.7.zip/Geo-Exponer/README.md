# Geo Exponer v1.7

APK para practicar exposiciones con lectura corrida por auriculares Bluetooth.

## Cambios v1.7

- Modo principal ahora es **Corrido**.
- La app lee las frases seguidas, sin quedarse esperando en cada frase.
- Botón power del celular: pausa / reanuda usando pantalla apagada o encendida.
- Botón de asistente, auricular o comando multimedia: pausa / reanuda cuando Android entrega ese comando a la app.
- Mantiene servicio en primer plano, notificación y WAKE_LOCK para responder más rápido con pantalla bloqueada.
- Velocidad de voz: 0.25x, 0.50x, 0.75x, 1x, 1.25x, 1.50x.
- Opciones 3s, 5s, 8s y 10s siguen disponibles como pausa entre frases si se quiere practicar repitiendo.

## Uso recomendado

1. Pega tu texto.
2. Elige velocidad.
3. Deja marcado **Corrido**.
4. Toca **Iniciar práctica**.
5. Apaga la pantalla.
6. Cuando quieras pausar, presiona el botón power.
7. Para reanudar, presiona otra vez el botón power.

Sin IA, sin API, sin Gemini, sin login y sin internet obligatorio.
