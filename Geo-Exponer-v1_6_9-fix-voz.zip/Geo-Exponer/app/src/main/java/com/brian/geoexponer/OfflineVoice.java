package com.brian.geoexponer;

import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;

import java.util.Locale;
import java.util.Set;

/**
 * App 100 % offline: la voz siempre es una voz en español instalada en el teléfono,
 * nunca una voz por internet.
 */
final class OfflineVoice {
    private OfflineVoice() {
    }

    /** @return true si quedó puesta una voz en español que funciona sin internet. */
    static boolean apply(TextToSpeech tts) {
        if (tts == null) return false;
        try {
            Voice current = tts.getVoice();
            if (isOfflineSpanish(current)) return true;

            Set<Voice> voices = tts.getVoices();
            if (voices == null) return false;
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            for (Voice v : voices) {
                if (!isOfflineSpanish(v)) continue;
                int score = v.getQuality();
                String country = v.getLocale().getCountry();
                if (current != null && current.getLocale() != null
                        && country.equals(current.getLocale().getCountry())) score += 1000;
                if ("PE".equals(country)) score += 600;
                else if ("US".equals(country) || "MX".equals(country)) score += 400;
                else if ("ES".equals(country)) score += 300;
                if (score > bestScore) {
                    bestScore = score;
                    best = v;
                }
            }
            if (best == null) return false;
            return tts.setVoice(best) == TextToSpeech.SUCCESS;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean isOfflineSpanish(Voice v) {
        if (v == null) return false;
        Locale l = v.getLocale();
        if (l == null || !"es".equals(l.getLanguage())) return false;
        if (v.isNetworkConnectionRequired()) return false;
        Set<String> features = v.getFeatures();
        return features == null || !features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED);
    }

    static final String HELP_VOICE =
            "Ajustes del celular → Texto a voz → Google (engranaje) → Instalar datos de voz → Español.";
    static final String HELP_MIC =
            "App Google → tu foto → Ajustes → Voz → Reconocimiento de voz sin conexión → descarga Español.";
}
