# Geo Exponer v1.3

APK para practicar exposiciones con audio por auriculares Bluetooth.

Cambios de esta versión:
- Modo manual por defecto: escucha una frase, repite y continúa con clic.
- El selector 3s / 5s / 8s / 10s queda solo para avance automático.
- Pantalla apagada: pausa.
- Pantalla encendida en bloqueo: continúa desde donde iba, no vuelve a iniciar la práctica desde cero.
- Botón multimedia/asistente del auricular: intenta pausar, reanudar o continuar según el estado.
- Mantiene permiso de batería/segundo plano y notificación tipo reproductor.
- Velocidad: 0.25x, 0.50x, 0.75x, 1x, 1.25x, 1.50x.

Sin IA, sin API, sin Gemini, sin internet obligatorio, sin login.
