package com.brian.geoexponer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.media.VolumeProvider;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.KeyEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ExpoPlaybackService extends Service {
    public static final String ACTION_START = "com.brian.geoexponer.START";
    public static final String ACTION_TOGGLE = "com.brian.geoexponer.TOGGLE";
    public static final String ACTION_PHYSICAL_TOGGLE = "com.brian.geoexponer.PHYSICAL_TOGGLE";
    public static final String ACTION_ASSIST_TOGGLE = "com.brian.geoexponer.ASSIST_TOGGLE";
    public static final String ACTION_REPEAT = "com.brian.geoexponer.REPEAT";
    public static final String ACTION_PREVIOUS = "com.brian.geoexponer.PREVIOUS";
    public static final String ACTION_NEXT = "com.brian.geoexponer.NEXT";
    public static final String ACTION_STOP = "com.brian.geoexponer.STOP";
    public static final String ACTION_UPDATE_SETTINGS = "com.brian.geoexponer.UPDATE_SETTINGS";
    public static final String ACTION_STATUS = "com.brian.geoexponer.STATUS";
    public static final String ACTION_TICK = "com.brian.geoexponer.TICK";
    public static final String ACTION_STATUS_REQUEST = "com.brian.geoexponer.STATUS_REQUEST";
    /** Preparar la voz antes de tocar ▶ (sin notificación). */
    public static final String ACTION_WARMUP = "com.brian.geoexponer.WARMUP";
    /** true si el intent llegó con startForegroundService (obliga a mostrar notificación). */
    public static final String EXTRA_FOREGROUND = "foreground_start";
    public static final String ACTION_PREVIOUS_SLIDE = "com.brian.geoexponer.PREVIOUS_SLIDE";
    public static final String ACTION_NEXT_SLIDE = "com.brian.geoexponer.NEXT_SLIDE";
    public static final String ACTION_JUMP = "com.brian.geoexponer.JUMP";
    public static final String EXTRA_JUMP_INDEX = "jump_index";

    public static final String EXTRA_TEXT = "text";
    public static final String EXTRA_SCRIPT_ID = "script_id";
    public static final String EXTRA_SPEED = "speed";
    public static final String EXTRA_PAUSE_MS = "pause_ms";
    public static final String EXTRA_SMART_FACTOR = "smart_factor";
    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_CUE_TONE = "cue_tone";
    public static final String EXTRA_CUE_VOICE = "cue_voice";
    public static final String EXTRA_VIBRATE = "vibrate";
    public static final String EXTRA_TARGET_MIN = "target_min";
    public static final String EXTRA_HINT_READ = "hint_read";
    public static final String EXTRA_MULTI_TAP = "multi_tap";

    public static final String EXTRA_PHRASE = "phrase";
    public static final String EXTRA_NEXT_PHRASE = "next_phrase";
    public static final String EXTRA_SLIDE_TITLE = "slide_title";
    public static final String EXTRA_SLIDE_INDEX = "slide_index";
    public static final String EXTRA_SLIDE_COUNT = "slide_count";
    public static final String EXTRA_PHRASE_IN_SLIDE = "phrase_in_slide";
    public static final String EXTRA_PHRASES_IN_SLIDE = "phrases_in_slide";
    public static final String EXTRA_INDEX = "index";
    public static final String EXTRA_TOTAL = "total";
    public static final String EXTRA_STATE = "state";
    public static final String EXTRA_ELAPSED_MS = "elapsed_ms";
    public static final String EXTRA_TARGET_MS = "target_ms";
    public static final String EXTRA_OFFLINE_OK = "offline_ok";

    public static final String STATE_PLAYING = "playing";
    public static final String STATE_WAITING = "waiting";
    public static final String STATE_PAUSED = "paused";
    public static final String STATE_STOPPED = "stopped";
    public static final String STATE_ERROR = "error";

    public static final String MODE_MANUAL = "manual";
    public static final String MODE_AUTO = "auto";
    public static final String MODE_MIXED = "mixed";

    private static final String CHANNEL_ID = "geo_exponer_playback";
    private static final int NOTIFICATION_ID = 2026;
    private static final String PHRASE_PREFIX = "geo_exponer_";
    private static final String CUE_PREFIX = "geo_cue_";
    private static final long TOGGLE_DEBOUNCE_MS = 350L;
    private static final long MULTI_TAP_WINDOW_MS = 450L;
    private static final int HINT_WORDS = 3;

    private final Handler handler = new Handler(Looper.getMainLooper());
    // Las esperas/avances usan un handler separado. Así nunca se borran por accidente
    // los callbacks onStart/onDone/onError del TTS al cambiar de frase.
    private final Handler transitionHandler = new Handler(Looper.getMainLooper());
    private final Handler timerHandler = new Handler(Looper.getMainLooper());
    private final Handler tapHandler = new Handler(Looper.getMainLooper());
    // Vigilante: si la voz se queda callada por un fallo del motor, retoma sola.
    private final Handler watchHandler = new Handler(Looper.getMainLooper());
    private int retriesThisPhrase = 0;
    private int errorsThisPhrase = 0;
    private final List<TextParser.Item> items = new ArrayList<>();

    private TextToSpeech tts;
    private MediaSession mediaSession;
    private boolean ttsReady = false;
    private boolean pendingStart = false;
    private boolean running = false;
    private boolean paused = false;
    private boolean pausedByScreen = false;
    private boolean pausedDuringWaiting = false;
    private boolean screenReceiverRegistered = false;
    private PowerManager.WakeLock wakeLock;
    private long lastScreenContinueMs = 0L;
    private long screenControlReadyMs = 0L;
    private int index = 0;
    private int pauseMs = 1000;
    private float smartFactor = 1.0f;
    private String playbackMode = MODE_MANUAL;
    private float speechRate = 1.0f;
    private String currentState = STATE_STOPPED;
    private int utteranceCounter = 0;
    private String activePhraseUtterance = null;
    // Lectura continua (pausa 0 s): la siguiente frase ya está en la cola del motor de voz.
    private String queuedUtterance = null;
    private int queuedIndex = -1;
    private long phraseSpeakStartMs = 0L;
    private long lastPhraseDurationMs = 0L;
    private int lastCuedSlide = -1;

    private boolean cueTone = true;
    private boolean cueVoice = false;
    private boolean vibrateOnSlide = true;
    private int targetMinutes = 0;
    private boolean hintRead = false;
    private boolean multiTap = false;
    private String scriptId = "";

    private long practiceStartMs = 0L;
    private long pausedAccumMs = 0L;
    private long pauseStartedMs = 0L;
    private boolean warnedOneMinute = false;
    private boolean warnedTarget = false;

    private long lastToggleMs = 0L;
    private int tapCount = 0;
    private ToneGenerator toneGenerator;
    private boolean remoteVolumeActive = false;
    private long lastVolumeKeyMs = 0L;

    private final Runnable tapRunnable = new Runnable() {
        @Override
        public void run() {
            int taps = tapCount;
            tapCount = 0;
            pausedByScreen = false;
            if (taps >= 3) {
                repeatPhrase(true);
            } else if (taps == 2) {
                nextPhrase();
            } else {
                togglePlayback();
            }
        }
    };

    private final Runnable tickRunnable = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            long elapsed = elapsedMs();
            checkTargetAlerts(elapsed);
            Intent tick = new Intent(ACTION_TICK);
            tick.setPackage(getPackageName());
            tick.putExtra(EXTRA_ELAPSED_MS, elapsed);
            tick.putExtra(EXTRA_TARGET_MS, targetMinutes * 60_000L);
            sendBroadcast(tick);
            timerHandler.postDelayed(this, 1000L);
        }
    };

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || intent.getAction() == null) return;

            String action = intent.getAction();

            if (!Intent.ACTION_SCREEN_OFF.equals(action) && !Intent.ACTION_SCREEN_ON.equals(action)) return;
            if (!running) return;

            boolean customControlsConfigured = PhysicalControlSettings.isConfigured(ExpoPlaybackService.this);
            if (customControlsConfigured && !PhysicalControlSettings.power(ExpoPlaybackService.this)) return;

            long now = SystemClock.elapsedRealtime();
            if (now < screenControlReadyMs) return;
            if (now - lastScreenContinueMs < 700) return;
            lastScreenContinueMs = now;

            if (customControlsConfigured) {
                pausedByScreen = true;
                togglePhysicalPause();
                return;
            }

            if (manualMode() && STATE_WAITING.equals(currentState)) {
                pausedByScreen = false;
                pausedDuringWaiting = false;
                advanceToNextPhrase();
                return;
            }

            if (mixedMode()) {
                // Comportamiento original del modo mixto con power.
                if (STATE_WAITING.equals(currentState) && !paused) {
                    return;
                }
                pausedByScreen = true;
                togglePlayback();
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        registerScreenReceiver();
        setupMediaSession();
        setupTextToSpeech();
        setupWakeLock();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        // Preparación rápida: la app abierta despierta el servicio y la voz para que
        // ▶ suene al instante. No muestra notificación si no hace falta.
        boolean light = ACTION_WARMUP.equals(action) || ACTION_STATUS_REQUEST.equals(action);
        boolean mustForeground = intent != null && intent.getBooleanExtra(EXTRA_FOREGROUND, true);
        if (intent == null && !running) {
            // Reinicio automático del sistema sin práctica activa: no hacer nada.
            stopSelf();
            return START_NOT_STICKY;
        }
        // Si ya hay una práctica activa, el servicio YA está en foreground: no volver a
        // reconstruir la notificación antes de cada botón. Para un inicio nuevo, primero
        // se encola la voz y justo después se promueve el servicio a foreground.
        if (mustForeground && !running && !light && !ACTION_START.equals(action)) {
            startForegroundCompat();
        }
        if (tts == null) setupTextToSpeech();

        if (ACTION_START.equals(action)) {
            startNewPractice(intent);
            startForegroundCompat();
        } else if (ACTION_PHYSICAL_TOGGLE.equals(action)) {
            if (debounceToggle()) {
                pausedByScreen = false;
                togglePhysicalPause();
            }
        } else if (ACTION_TOGGLE.equals(action) || ACTION_ASSIST_TOGGLE.equals(action)) {
            if (debounceToggle()) {
                pausedByScreen = false;
                togglePlayback();
            }
        } else if (ACTION_REPEAT.equals(action)) {
            pausedByScreen = false;
            repeatPhrase(true);
        } else if (ACTION_PREVIOUS.equals(action)) {
            pausedByScreen = false;
            previousPhrase();
        } else if (ACTION_NEXT.equals(action)) {
            pausedByScreen = false;
            nextPhrase();
        } else if (ACTION_PREVIOUS_SLIDE.equals(action)) {
            pausedByScreen = false;
            jumpSlide(-1);
        } else if (ACTION_NEXT_SLIDE.equals(action)) {
            pausedByScreen = false;
            jumpSlide(1);
        } else if (ACTION_JUMP.equals(action)) {
            pausedByScreen = false;
            jumpTo(intent.getIntExtra(EXTRA_JUMP_INDEX, 0));
        } else if (ACTION_STOP.equals(action)) {
            stopPractice(false);
        } else if (ACTION_UPDATE_SETTINGS.equals(action)) {
            updateSettings(intent);
        } else if (ACTION_STATUS_REQUEST.equals(action) || ACTION_WARMUP.equals(action)) {
            broadcastStatus(currentState);
            warmUpVoice();
        } else {
            broadcastStatus(currentState);
        }

        if (!running) {
            // Sin práctica: sin notificación, pero el servicio y la voz quedan listos.
            stopForeground(true);
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    private long lastWarmupMs = 0L;
    private int voiceGeneration = 0;

    /** Abre el canal de audio del motor de voz con un silencio corto (no se escucha). */
    private void warmUpVoice() {
        if (tts == null || !ttsReady || running || SystemClock.elapsedRealtime() - lastWarmupMs < 30000L) return;
        lastWarmupMs = SystemClock.elapsedRealtime();
        try {
            Bundle silent = new Bundle();
            silent.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 0f);
            tts.speak("Listo", TextToSpeech.QUEUE_FLUSH, silent, "geo_warmup");
        } catch (Exception ignored) {
        }
    }

    private void startForegroundCompat() {
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
                return;
            } catch (Exception ignored) {
                // Si el sistema rechaza el tipo, se intenta sin tipo.
            }
        }
        startForeground(NOTIFICATION_ID, notification);
    }

    private boolean debounceToggle() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastToggleMs < TOGGLE_DEBOUNCE_MS) return false;
        lastToggleMs = now;
        return true;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        if (running && !STATE_STOPPED.equals(currentState)) {
            refreshNotification();
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        voiceGeneration++;
        handler.removeCallbacksAndMessages(null);
        transitionHandler.removeCallbacksAndMessages(null);
        timerHandler.removeCallbacksAndMessages(null);
        tapHandler.removeCallbacksAndMessages(null);
        watchHandler.removeCallbacksAndMessages(null);
        unregisterScreenReceiver();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (mediaSession != null) {
            try {
                mediaSession.setPlaybackToLocal(mediaAudioAttributes());
            } catch (Exception ignored) {
            }
            mediaSession.setActive(false);
            mediaSession.release();
        }
        if (toneGenerator != null) {
            try {
                toneGenerator.release();
            } catch (Exception ignored) {
            }
            toneGenerator = null;
        }
        releaseWakeLock();
        super.onDestroy();
    }

    private void registerScreenReceiver() {
        if (screenReceiverRegistered) return;
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(screenReceiver, filter);
        }
        screenReceiverRegistered = true;
    }

    private void unregisterScreenReceiver() {
        if (!screenReceiverRegistered) return;
        try {
            unregisterReceiver(screenReceiver);
        } catch (IllegalArgumentException ignored) {
        }
        screenReceiverRegistered = false;
    }

    private void setupWakeLock() {
        try {
            PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (powerManager != null) {
                wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoExponer:PlaybackWakeLock");
                wakeLock.setReferenceCounted(false);
            }
        } catch (Exception ignored) {
            wakeLock = null;
        }
    }

    private void acquireWakeLock() {
        try {
            if (wakeLock != null && !wakeLock.isHeld()) {
                wakeLock.acquire(6 * 60 * 60 * 1000L);
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        } catch (Exception ignored) {
        }
    }

    private void setupTextToSpeech() {
        final int generation = ++voiceGeneration;
        ttsReady = false;
        tts = new TextToSpeech(this, status -> handler.post(() -> {
            if (generation != voiceGeneration) return;
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true;
                int languageResult = tts.setLanguage(new Locale("es", "ES"));
                if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.getDefault());
                }
                tts.setPitch(1.0f);
                preferOfflineVoice();
                try {
                    tts.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build());
                } catch (Exception ignored) {
                }
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                        handler.post(() -> {
                            if (utteranceId != null && utteranceId.equals(queuedUtterance)) {
                                onQueuedPhraseStarted();
                                return;
                            }
                            if (utteranceId != null && utteranceId.equals(activePhraseUtterance)) {
                                // La UI ya se actualizó al encolar la frase. Aquí solo marcamos
                                // el inicio real del audio para el vigilante y la duración.
                                phraseSpeakStartMs = SystemClock.elapsedRealtime();
                            }
                        });
                    }

                    @Override
                    public void onDone(String utteranceId) {
                        handler.post(() -> {
                            if (!running || paused || utteranceId == null || !utteranceId.equals(activePhraseUtterance)) return;
                            if (phraseSpeakStartMs > 0L) {
                                lastPhraseDurationMs = SystemClock.elapsedRealtime() - phraseSpeakStartMs;
                            }
                            if (queuedUtterance != null) {
                                if (continuousMode() && running && !paused) {
                                    // La siguiente frase ya empieza sola, sin hueco.
                                    // Si el motor no arranca la cola pronto, se lanza directo.
                                    final String finished = utteranceId;
                                    watchHandler.removeCallbacksAndMessages(null);
                                    watchHandler.postDelayed(() -> {
                                        if (!running || paused) return;
                                        if (finished.equals(activePhraseUtterance)) {
                                            clearQueue();
                                            if (tts != null) tts.stop();
                                            advanceToNextPhrase();
                                        }
                                    }, 5000L);
                                    return;
                                }
                                // Cambiaste el ajuste: quitar la frase en cola y respetar la pausa nueva.
                                clearQueue();
                                tts.stop();
                            }
                            watchHandler.removeCallbacksAndMessages(null);
                            retriesThisPhrase = 0;
                            errorsThisPhrase = 0;
                            onSpeechDone();
                        });
                    }

                    @Override
                    public void onError(String utteranceId) {
                        handler.post(() -> {
                            if (utteranceId == null || !running || paused) return;
                            if (utteranceId.equals(queuedUtterance)) {
                                // Si falla solo la frase precargada, la actual sigue normal.
                                // Al terminar se iniciará la siguiente de forma directa.
                                clearQueue();
                                return;
                            }
                            if (!utteranceId.equals(activePhraseUtterance)) return;
                            watchHandler.removeCallbacksAndMessages(null);
                            final String failed = utteranceId;
                            watchHandler.postDelayed(() -> {
                                if (running && !paused && failed.equals(activePhraseUtterance)) recoverSilence();
                            }, 200L);
                        });
                    }
                });

                if (pendingStart) {
                    pendingStart = false;
                    speakCurrentPhrase(false);
                } else {
                    warmUpVoice();
                }
            } else {
                voiceFailure();
            }
        }));
        handler.postDelayed(() -> {
            if (generation == voiceGeneration && !ttsReady) voiceFailure();
        }, 12000L);
    }

    // Preserve the phrase when the engine fails. Never skip unread text.
    private void voiceFailure() {
        pendingStart = false;
        if (running && !paused) pausePlayback();
        pausedDuringWaiting = false;
        clearQueue();
        activePhraseUtterance = null;
        ttsReady = false;
        voiceGeneration++;
        TextToSpeech old = tts;
        tts = null;
        if (old != null) { try { old.shutdown(); } catch (Exception ignored) {} }
        currentState = STATE_ERROR;
        updatePlaybackState();
        broadcastStatus(STATE_ERROR);
        refreshNotification();
    }

    private void setupMediaSession() {
        mediaSession = new MediaSession(this, "GeoExponerSession");
        mediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);

        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent sessionActivity = PendingIntent.getActivity(this, 1, openIntent, pendingFlags());
        mediaSession.setSessionActivity(sessionActivity);

        Intent mediaButtonIntent = new Intent(Intent.ACTION_MEDIA_BUTTON);
        mediaButtonIntent.setClass(this, ButtonIntentReceiver.class);
        PendingIntent mediaButtonPendingIntent = PendingIntent.getBroadcast(this, 2, mediaButtonIntent, mediaButtonPendingFlags());
        mediaSession.setMediaButtonReceiver(mediaButtonPendingIntent);

        mediaSession.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() {
                pausedByScreen = false;
                resumePlayback();
            }

            @Override
            public void onPause() {
                pausedByScreen = false;
                pausePlayback();
            }

            @Override
            public void onStop() {
                stopPractice(false);
            }

            @Override
            public void onSkipToNext() {
                pausedByScreen = false;
                nextPhrase();
            }

            @Override
            public void onSkipToPrevious() {
                pausedByScreen = false;
                repeatPhrase(true);
            }

            @Override
            public boolean onMediaButtonEvent(Intent mediaButtonIntent) {
                KeyEvent event = mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
                if (event == null || event.getAction() != KeyEvent.ACTION_UP) {
                    return true;
                }

                int code = event.getKeyCode();
                if (code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code == KeyEvent.KEYCODE_HEADSETHOOK
                        || code == KeyEvent.KEYCODE_ASSIST || code == KeyEvent.KEYCODE_VOICE_ASSIST) {
                    pausedByScreen = false;
                    boolean headsetButton = code == KeyEvent.KEYCODE_HEADSETHOOK || code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
                    if (headsetButton && !PhysicalControlSettings.headset(ExpoPlaybackService.this)) {
                        return true;
                    }
                    if (multiTap && headsetButton && running) {
                        tapCount++;
                        tapHandler.removeCallbacks(tapRunnable);
                        tapHandler.postDelayed(tapRunnable, MULTI_TAP_WINDOW_MS);
                    } else if (debounceToggle()) {
                        togglePlayback();
                    }
                    return true;
                } else if (code == KeyEvent.KEYCODE_MEDIA_PLAY) {
                    pausedByScreen = false;
                    resumePlayback();
                    return true;
                } else if (code == KeyEvent.KEYCODE_MEDIA_PAUSE) {
                    pausedByScreen = false;
                    pausePlayback();
                    return true;
                } else if (code == KeyEvent.KEYCODE_MEDIA_NEXT) {
                    pausedByScreen = false;
                    nextPhrase();
                    return true;
                } else if (code == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
                    pausedByScreen = false;
                    previousPhrase();
                    return true;
                }
                return super.onMediaButtonEvent(mediaButtonIntent);
            }
        });

        mediaSession.setActive(true);
        updatePlaybackState();
    }

    /**
     * Volumen en el bolsillo: la sesión recibe los botones de volumen aunque la
     * pantalla esté apagada. Solo se activa si el usuario eligió esa opción.
     */
    private void applyVolumeControl() {
        if (mediaSession == null) return;
        boolean want = running && PhysicalControlSettings.isConfigured(this)
                && PhysicalControlSettings.volumePocket(this);
        if (want == remoteVolumeActive) return;
        try {
            if (want) {
                mediaSession.setPlaybackToRemote(new VolumeProvider(VolumeProvider.VOLUME_CONTROL_RELATIVE, 100, 50) {
                    @Override
                    public void onAdjustVolume(int direction) {
                        if (direction == 0) return;
                        long now = SystemClock.elapsedRealtime();
                        // Mantener presionado envía repeticiones: solo cuenta una por pulsación.
                        if (now - lastVolumeKeyMs < 450L) {
                            lastVolumeKeyMs = now;
                            return;
                        }
                        lastVolumeKeyMs = now;
                        handler.post(() -> {
                            if (!debounceToggle()) return;
                            pausedByScreen = false;
                            togglePhysicalPause();
                        });
                    }
                });
            } else {
                mediaSession.setPlaybackToLocal(mediaAudioAttributes());
            }
            remoteVolumeActive = want;
            updatePlaybackState();
        } catch (Exception ignored) {
            remoteVolumeActive = false;
        }
    }

    private static AudioAttributes mediaAudioAttributes() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build();
    }

    private void readSettings(Intent intent, boolean start) {
        if (intent == null) return;
        if (intent.hasExtra(EXTRA_PAUSE_MS)) {
            int newPause = intent.getIntExtra(EXTRA_PAUSE_MS, pauseMs);
            pauseMs = newPause;
        }
        if (intent.hasExtra(EXTRA_SMART_FACTOR)) {
            smartFactor = Math.max(0.5f, Math.min(2.0f, intent.getFloatExtra(EXTRA_SMART_FACTOR, 1.0f)));
        }
        if (intent.hasExtra(EXTRA_MODE)) {
            String newMode = intent.getStringExtra(EXTRA_MODE);
            if (!MODE_AUTO.equals(newMode) && !MODE_MIXED.equals(newMode)) newMode = MODE_MANUAL;
            boolean becameManual = !MODE_MANUAL.equals(playbackMode) && MODE_MANUAL.equals(newMode);
            playbackMode = newMode;
            if (!start && becameManual && STATE_WAITING.equals(currentState) && !paused) {
                // Cancelar el avance automático pendiente: ahora espera al usuario.
                transitionHandler.removeCallbacksAndMessages(null);
            }
        }
        cueTone = intent.getBooleanExtra(EXTRA_CUE_TONE, cueTone);
        cueVoice = intent.getBooleanExtra(EXTRA_CUE_VOICE, cueVoice);
        vibrateOnSlide = intent.getBooleanExtra(EXTRA_VIBRATE, vibrateOnSlide);
        int newTarget = intent.getIntExtra(EXTRA_TARGET_MIN, targetMinutes);
        if (newTarget != targetMinutes) {
            targetMinutes = Math.max(0, newTarget);
            warnedOneMinute = false;
            warnedTarget = false;
        }
        hintRead = intent.getBooleanExtra(EXTRA_HINT_READ, hintRead);
        multiTap = intent.getBooleanExtra(EXTRA_MULTI_TAP, multiTap);
    }

    private void updateSettings(Intent intent) {
        if (intent == null) return;
        int oldPause = pauseMs;
        String oldMode = playbackMode;
        boolean oldHint = hintRead;
        boolean oldCueVoice = cueVoice;
        readSettings(intent, false);
        applyVolumeControl();



        float newSpeechRate = intent.getFloatExtra(EXTRA_SPEED, speechRate);
        if (newSpeechRate < 0.25f) newSpeechRate = 0.25f;
        if (newSpeechRate > 1.50f) newSpeechRate = 1.50f;
        boolean speedChanged = Math.abs(newSpeechRate - speechRate) > 0.001f;
        speechRate = newSpeechRate;
        if (tts != null && ttsReady) {
            tts.setSpeechRate(speechRate);
        }

        boolean timingChanged = oldPause != pauseMs || !oldMode.equals(playbackMode)
                || oldHint != hintRead || oldCueVoice != cueVoice;
        if (timingChanged && running && !paused) {
            if (STATE_WAITING.equals(currentState) && !manualMode()) {
                // Esperando entre frases: aplicar el tiempo nuevo desde ya.
                transitionHandler.removeCallbacksAndMessages(null);
                long wait = waitAfterPhraseMs();
                if (wait <= 0) {
                    advanceToNextPhrase();
                    return;
                }
                transitionHandler.postDelayed(() -> {
                    if (!running || paused) return;
                    advanceToNextPhrase();
                }, wait);
            } else if (STATE_PLAYING.equals(currentState)) {
                if (continuousMode() && queuedUtterance == null) {
                    queueNextPhrase();
                }
                // Si ya no es continuo, la frase en cola se quita al terminar la actual.
            }
        }

        // TTS no cambia la velocidad de una frase que ya está sonando:
        // se reinicia solo la frase actual para aplicar la nueva velocidad.
        if (speedChanged && running && !paused && STATE_PLAYING.equals(currentState)) {
            speakCurrentPhrase(false);
            return;
        }

        broadcastStatus(currentState);
        refreshNotification();
    }

    private void startNewPractice(Intent intent) {
        String text = intent.getStringExtra(EXTRA_TEXT);
        speechRate = intent.getFloatExtra(EXTRA_SPEED, 1.0f);
        String id = intent.getStringExtra(EXTRA_SCRIPT_ID);
        scriptId = id == null ? "" : id;
        playbackMode = MODE_MANUAL;
        pauseMs = 1000;
        readSettings(intent, true);
        if (MODE_MANUAL.equals(playbackMode)) {
            pauseMs = -1;
        } else if (pauseMs == -1) {
            pauseMs = 1000;
        }
        screenControlReadyMs = SystemClock.elapsedRealtime() + 1800L;

        items.clear();
        items.addAll(TextParser.parseItems(text));
        index = Math.max(0, Math.min(intent.getIntExtra(EXTRA_JUMP_INDEX, 0), Math.max(0, items.size() - 1)));
        paused = false;
        pausedByScreen = false;
        pausedDuringWaiting = false;
        lastCuedSlide = -1;
        lastPhraseDurationMs = 0L;
        retriesThisPhrase = 0;
        errorsThisPhrase = 0;
        running = items.size() > 0;
        transitionHandler.removeCallbacksAndMessages(null);
        watchHandler.removeCallbacksAndMessages(null);
        timerHandler.removeCallbacksAndMessages(null);

        if (!running) {
            currentState = STATE_ERROR;
            broadcastStatus(STATE_ERROR);
            refreshNotification();
            return;
        }

        acquireWakeLock();
        practiceStartMs = SystemClock.elapsedRealtime();
        pausedAccumMs = 0L;
        pauseStartedMs = 0L;
        warnedOneMinute = false;
        warnedTarget = false;
        timerHandler.post(tickRunnable);
        applyVolumeControl();

        if (ttsReady) {
            speakCurrentPhrase(false);
        } else {
            pendingStart = true;
            currentState = STATE_WAITING;
            broadcastStatus(STATE_WAITING);
            refreshNotification();
        }
    }

    private void speakCurrentPhrase(boolean forceFull) {
        if (!running || paused || items.isEmpty()) return;

        if (index < 0) index = 0;
        if (index >= items.size()) {
            playEndCue();
            stopPractice(true);
            return;
        }

        transitionHandler.removeCallbacksAndMessages(null);
        watchHandler.removeCallbacksAndMessages(null);

        if (tts == null || !ttsReady) {
            if (tts == null) setupTextToSpeech();
            pendingStart = true;
            currentState = STATE_WAITING;
            updatePlaybackState();
            broadcastStatus(STATE_WAITING);
            refreshNotification();
            return;
        }

        TextParser.Item item = items.get(index);
        boolean newSlide = item.slideIndex != lastCuedSlide;
        boolean hasSlides = item.slideCount > 1;
        clearQueue();
        // Si el motor ya terminó la frase anterior no hace falta pararlo: evitar stop() aquí
        // reduce cortes y latencia. Solo se interrumpe cuando realmente sigue hablando.
        try {
            if (tts.isSpeaking()) tts.stop();
        } catch (Exception ignored) {
        }
        tts.setSpeechRate(speechRate);

        int queueMode = TextToSpeech.QUEUE_FLUSH;
        if (newSlide && hasSlides && lastCuedSlide >= 0) {
            // Aviso al cambiar de diapositiva (no en la primera).
            if (cueTone) playTone(ToneGenerator.TONE_PROP_BEEP, 120);
            if (vibrateOnSlide) vibrate(new long[]{0, 120});
            if (cueVoice) {
                String label = item.slideNumber.isEmpty()
                        ? "Siguiente parte"
                        : "Diapositiva " + item.slideNumber;
                tts.speak(label, TextToSpeech.QUEUE_FLUSH, new Bundle(), CUE_PREFIX + (++utteranceCounter));
                queueMode = TextToSpeech.QUEUE_ADD;
            }
        }
        lastCuedSlide = item.slideIndex;

        String toSpeak = item.spoken;
        if (hintRead && !forceFull) {
            toSpeak = firstWords(item.spoken, HINT_WORDS);
        }
        phraseSpeakStartMs = 0L;
        activePhraseUtterance = PHRASE_PREFIX + (++utteranceCounter);
        int speakResult = tts.speak(toSpeak, queueMode, new Bundle(), activePhraseUtterance);
        currentState = STATE_PLAYING;

        // En modo continuo se llena la cola antes de actualizar UI/notificación. Esto evita
        // huecos entre frases incluso en teléfonos lentos.
        if (speakResult == TextToSpeech.SUCCESS && continuousMode()) queueNextPhrase();
        if (speakResult == TextToSpeech.SUCCESS) {
            watchPhrase(activePhraseUtterance, TextParser.wordCount(toSpeak), queueMode == TextToSpeech.QUEUE_ADD);
        } else {
            final String failed = activePhraseUtterance;
            watchHandler.postDelayed(() -> {
                if (running && !paused && failed.equals(activePhraseUtterance)) recoverSilence();
            }, 120L);
        }

        updatePlaybackState();
        broadcastStatus(STATE_PLAYING);
        refreshNotification();
    }

    /**
     * Vigilante contra silencios: si el motor no inicia o no termina en el
     * tiempo esperado, se vuelve a decir. Máximo 2 reintentos por frase.
     */
    private void watchPhrase(final String utterance, int words, boolean hasCue) {
        watchHandler.removeCallbacksAndMessages(null);
        if (utterance == null) return;
        final long startLimit = hasCue ? 10000L : 7000L;
        watchHandler.postDelayed(() -> {
            if (!running || paused || !utterance.equals(activePhraseUtterance)) return;
            if (phraseSpeakStartMs == 0L && STATE_PLAYING.equals(currentState)) {
                recoverSilence();
            }
        }, startLimit);
        long expected = Math.round(Math.max(1, words) * 650L / Math.max(0.25f, speechRate)) + startLimit + 4000L;
        watchHandler.postDelayed(() -> {
            if (!running || paused || !utterance.equals(activePhraseUtterance)) return;
            if (STATE_PLAYING.equals(currentState)) recoverSilence();
        }, expected);
    }

    private void recoverSilence() {
        if (!running || paused) return;
        if (retriesThisPhrase >= 2) {
            voiceFailure();
            return;
        }
        retriesThisPhrase++;
        clearQueue();
        activePhraseUtterance = null;
        watchHandler.removeCallbacksAndMessages(null);
        if (retriesThisPhrase == 2) {
            // Reconnect a stuck engine, keeping the same phrase and controls.
            voiceGeneration++;
            TextToSpeech old = tts;
            tts = null;
            ttsReady = false;
            if (old != null) { try { old.shutdown(); } catch (Exception ignored) {} }
            pendingStart = true;
            setupTextToSpeech();
        } else {
            if (tts != null) tts.stop();
            speakCurrentPhrase(false);
        }
    }

    private boolean offlineVoiceOk = true;

    /** 100 % offline: usar solo voces en español instaladas en el teléfono. */
    private void preferOfflineVoice() {
        offlineVoiceOk = OfflineVoice.apply(tts);
    }

    /** Auto/Mixto con 0 s: sin espera entre frases. */
    private boolean continuousMode() {
        return !manualMode() && pauseMs == 0;
    }

    private void clearQueue() {
        queuedUtterance = null;
        queuedIndex = -1;
    }

    /** Deja la siguiente frase en la cola del motor de voz para que suene pegada. */
    private void queueNextPhrase() {
        if (tts == null || !ttsReady || !running || paused) return;
        int next = index + 1;
        if (next >= items.size()) return;
        TextParser.Item current = items.get(index);
        TextParser.Item item = items.get(next);
        if (cueVoice && item.slideCount > 1 && item.slideIndex != current.slideIndex) {
            String label = item.slideNumber.isEmpty() ? "Siguiente parte" : "Diapositiva " + item.slideNumber;
            tts.speak(label, TextToSpeech.QUEUE_ADD, new Bundle(), CUE_PREFIX + (++utteranceCounter));
        }
        String text = hintRead ? firstWords(item.spoken, HINT_WORDS) : item.spoken;
        queuedIndex = next;
        queuedUtterance = PHRASE_PREFIX + (++utteranceCounter);
        if (tts.speak(text, TextToSpeech.QUEUE_ADD, new Bundle(), queuedUtterance) != TextToSpeech.SUCCESS) clearQueue();
    }

    /** Empezó la frase que estaba en cola: pasa a ser la actual y se encola la que sigue. */
    private void onQueuedPhraseStarted() {
        if (!running || paused || queuedIndex < 0) return;
        index = queuedIndex;
        activePhraseUtterance = queuedUtterance;
        clearQueue();
        phraseSpeakStartMs = SystemClock.elapsedRealtime();
        TextParser.Item item = items.get(index);
        if (item.slideCount > 1 && item.slideIndex != lastCuedSlide && lastCuedSlide >= 0) {
            if (cueTone) playTone(ToneGenerator.TONE_PROP_BEEP, 120);
            if (vibrateOnSlide) vibrate(new long[]{0, 120});
        }
        lastCuedSlide = item.slideIndex;
        currentState = STATE_PLAYING;
        retriesThisPhrase = 0;
        errorsThisPhrase = 0;
        if (continuousMode()) queueNextPhrase();
        watchPhrase(activePhraseUtterance, TextParser.wordCount(item.spoken), false);
        updatePlaybackState();
        broadcastStatus(STATE_PLAYING);
        refreshNotification();
    }

    private static String firstWords(String text, int count) {
        String[] words = text.trim().split("\\s+");
        if (words.length <= count) return text;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (i > 0) b.append(' ');
            b.append(words[i]);
        }
        return b.toString();
    }

    private long waitAfterPhraseMs() {
        if (pauseMs != ExpoSettings.PAUSE_SMART) return pauseMs;
        // Pausa inteligente: el tiempo que tardas en repetir la frase.
        long base;
        TextParser.Item item = (index >= 0 && index < items.size()) ? items.get(index) : null;
        if (hintRead && item != null) {
            // En modo pista la voz solo dice el inicio: calcular por palabras.
            int words = TextParser.wordCount(item.spoken);
            base = Math.round(words * 420L / Math.max(0.5f, speechRate));
        } else if (lastPhraseDurationMs > 200L) {
            base = lastPhraseDurationMs;
        } else {
            int words = item == null ? 8 : TextParser.wordCount(item.spoken);
            base = Math.round(words * 420L / Math.max(0.5f, speechRate));
        }
        long wait = Math.round(base * smartFactor) + 500L;
        return Math.max(800L, Math.min(30_000L, wait));
    }

    private void onSpeechDone() {
        if (!running || paused || items.isEmpty()) return;

        currentState = STATE_WAITING;
        updatePlaybackState();
        broadcastStatus(STATE_WAITING);
        refreshNotification();

        if (manualMode()) {
            return;
        }

        long wait = waitAfterPhraseMs();
        if (wait <= 0) {
            advanceToNextPhrase();
            return;
        }

        transitionHandler.postDelayed(() -> {
            if (!running || paused) return;
            advanceToNextPhrase();
        }, wait);
    }

    private void togglePhysicalPause() {
        if (!running || items.isEmpty()) {
            broadcastStatus(currentState);
            return;
        }

        if (paused) {
            resumePlayback();
        } else {
            pausePlayback();
        }
    }

    private void togglePlayback() {
        if (!running || items.isEmpty()) {
            broadcastStatus(currentState);
            return;
        }

        if (paused) {
            if (pausedDuringWaiting) {
                pausedDuringWaiting = false;
                endPauseTimer();
                advanceToNextPhrase();
            } else {
                resumePlayback();
            }
        } else if (STATE_WAITING.equals(currentState)) {
            if (manualMode()) {
                advanceToNextPhrase();
            } else {
                pausePlayback();
            }
        } else {
            pausePlayback();
        }
    }

    private void pausePlayback() {
        if (!running) return;
        if (paused) return;
        if (mediaSession != null && !mediaSession.isActive()) mediaSession.setActive(true);
        pausedDuringWaiting = STATE_WAITING.equals(currentState) && !pendingStart;
        paused = true;
        pauseStartedMs = SystemClock.elapsedRealtime();
        transitionHandler.removeCallbacksAndMessages(null);
        watchHandler.removeCallbacksAndMessages(null);
        clearQueue();
        activePhraseUtterance = null;
        if (tts != null) tts.stop();
        currentState = STATE_PAUSED;
        updatePlaybackState();
        broadcastStatus(STATE_PAUSED);
        refreshNotification();
    }

    private void endPauseTimer() {
        if (pauseStartedMs > 0L) {
            pausedAccumMs += SystemClock.elapsedRealtime() - pauseStartedMs;
            pauseStartedMs = 0L;
        }
    }

    private void resumePlayback() {
        if (!running || items.isEmpty()) return;
        retriesThisPhrase = 0;
        paused = false;
        endPauseTimer();
        if (pausedDuringWaiting) {
            pausedDuringWaiting = false;
            advanceToNextPhrase();
            return;
        }
        speakCurrentPhrase(false);
    }

    private void repeatPhrase(boolean forceFull) {
        if (!running || items.isEmpty()) return;
        retriesThisPhrase = 0;
        errorsThisPhrase = 0;
        paused = false;
        pausedDuringWaiting = false;
        endPauseTimer();
        speakCurrentPhrase(forceFull);
    }

    private void previousPhrase() {
        if (!running || items.isEmpty()) return;
        retriesThisPhrase = 0;
        errorsThisPhrase = 0;
        paused = false;
        pausedDuringWaiting = false;
        endPauseTimer();
        transitionHandler.removeCallbacksAndMessages(null);
        if (index > 0) {
            index--;
        }
        speakCurrentPhrase(false);
    }

    private void nextPhrase() {
        if (!running || items.isEmpty()) return;
        errorsThisPhrase = 0;
        paused = false;
        pausedDuringWaiting = false;
        endPauseTimer();
        advanceToNextPhrase();
    }

    private void jumpSlide(int direction) {
        if (!running || items.isEmpty()) return;
        retriesThisPhrase = 0;
        errorsThisPhrase = 0;
        paused = false;
        pausedDuringWaiting = false;
        endPauseTimer();
        transitionHandler.removeCallbacksAndMessages(null);
        int current = items.get(Math.max(0, Math.min(index, items.size() - 1))).slideIndex;
        int target = current + direction;
        if (target < 0) target = 0;
        int newIndex = -1;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).slideIndex == target) {
                newIndex = i;
                break;
            }
        }
        if (newIndex < 0) {
            if (direction > 0) {
                newIndex = items.size() - 1;
            } else {
                newIndex = 0;
            }
        }
        index = newIndex;
        speakCurrentPhrase(false);
    }

    private void jumpTo(int newIndex) {
        if (!running || items.isEmpty()) return;
        retriesThisPhrase = 0;
        errorsThisPhrase = 0;
        paused = false;
        pausedDuringWaiting = false;
        endPauseTimer();
        transitionHandler.removeCallbacksAndMessages(null);
        index = Math.max(0, Math.min(newIndex, items.size() - 1));
        speakCurrentPhrase(false);
    }

    private void advanceToNextPhrase() {
        if (!running || items.isEmpty()) return;
        retriesThisPhrase = 0;
        errorsThisPhrase = 0;
        paused = false;
        pausedDuringWaiting = false;
        index++;
        speakCurrentPhrase(false);
    }

    private boolean manualMode() {
        return MODE_MANUAL.equals(playbackMode);
    }

    private boolean mixedMode() {
        return MODE_MIXED.equals(playbackMode);
    }

    private long elapsedMs() {
        if (practiceStartMs <= 0L) return 0L;
        long now = SystemClock.elapsedRealtime();
        long pausedNow = (paused && pauseStartedMs > 0L) ? now - pauseStartedMs : 0L;
        return Math.max(0L, now - practiceStartMs - pausedAccumMs - pausedNow);
    }

    private void checkTargetAlerts(long elapsed) {
        if (targetMinutes <= 0) return;
        long target = targetMinutes * 60_000L;
        if (targetMinutes >= 2 && !warnedOneMinute && elapsed >= target - 60_000L) {
            warnedOneMinute = true;
            playTone(ToneGenerator.TONE_PROP_BEEP2, 200);
            vibrate(new long[]{0, 150, 150, 150});
        }
        if (!warnedTarget && elapsed >= target) {
            warnedTarget = true;
            playTone(ToneGenerator.TONE_PROP_ACK, 300);
            vibrate(new long[]{0, 600});
        }
    }

    private void playEndCue() {
        if (cueTone) playTone(ToneGenerator.TONE_PROP_ACK, 250);
        if (vibrateOnSlide) vibrate(new long[]{0, 200, 120, 200});
    }

    private void playTone(int tone, int durationMs) {
        try {
            if (toneGenerator == null) {
                toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 55);
            }
            toneGenerator.startTone(tone, durationMs);
        } catch (Exception ignored) {
            toneGenerator = null;
        }
    }

    @SuppressWarnings("deprecation")
    private void vibrate(long[] pattern) {
        try {
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator == null || !vibrator.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1));
            } else {
                vibrator.vibrate(pattern, -1);
            }
        } catch (Exception ignored) {
        }
    }

    private void stopPractice(boolean finished) {
        boolean wasRunning = running;
        long duration = elapsedMs();
        running = false;
        paused = false;
        pausedByScreen = false;
        pausedDuringWaiting = false;
        pendingStart = false;
        transitionHandler.removeCallbacksAndMessages(null);
        timerHandler.removeCallbacksAndMessages(null);
        tapHandler.removeCallbacksAndMessages(null);
        watchHandler.removeCallbacksAndMessages(null);
        tapCount = 0;
        clearQueue();
        if (tts != null) tts.stop();
        activePhraseUtterance = null;
        applyVolumeControl();
        if (wasRunning && (finished || duration >= 5000L)) {
            ScriptStore.recordRehearsal(this, scriptId, duration);
        }
        currentState = STATE_STOPPED;
        updatePlaybackState();
        broadcastStatus(STATE_STOPPED);
        releaseWakeLock();
        stopForeground(true);
        // El servicio queda "caliente" para que el siguiente inicio responda rápido.
    }

    private void broadcastStatus(String state) {
        Intent intent = new Intent(ACTION_STATUS);
        intent.setPackage(getPackageName());
        intent.putExtra(EXTRA_STATE, state);
        intent.putExtra(EXTRA_INDEX, items.isEmpty() ? 0 : Math.min(index, items.size() - 1) + 1);
        intent.putExtra(EXTRA_TOTAL, items.size());
        intent.putExtra(EXTRA_ELAPSED_MS, elapsedMs());
        intent.putExtra(EXTRA_TARGET_MS, targetMinutes * 60_000L);
        intent.putExtra(EXTRA_OFFLINE_OK, !ttsReady || offlineVoiceOk);
        if (!items.isEmpty() && index >= 0 && index < items.size()) {
            TextParser.Item item = items.get(index);
            intent.putExtra(EXTRA_PHRASE, item.raw);
            intent.putExtra(EXTRA_SLIDE_TITLE, item.slideTitle);
            intent.putExtra(EXTRA_SLIDE_INDEX, item.slideIndex + 1);
            intent.putExtra(EXTRA_SLIDE_COUNT, item.slideCount);
            intent.putExtra(EXTRA_PHRASE_IN_SLIDE, item.phraseInSlide);
            intent.putExtra(EXTRA_PHRASES_IN_SLIDE, item.phrasesInSlide);
            intent.putExtra(EXTRA_NEXT_PHRASE, index + 1 < items.size() ? items.get(index + 1).raw : "");
        } else {
            intent.putExtra(EXTRA_PHRASE, "");
            intent.putExtra(EXTRA_NEXT_PHRASE, "");
        }
        sendBroadcast(intent);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Geo Exponer",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Controles de práctica de exposición");
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPendingIntent = PendingIntent.getActivity(this, 20, openIntent, pendingFlags());

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
            builder.setPriority(Notification.PRIORITY_LOW);
        }

        builder.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Geo Exponer")
                .setContentText(notificationText())
                .setContentIntent(openPendingIntent)
                .setShowWhen(false)
                .setOngoing(running && !STATE_STOPPED.equals(currentState))
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setCategory(Notification.CATEGORY_TRANSPORT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            builder.addAction(makeAction(ACTION_PREVIOUS, "Anterior", 31));
            builder.addAction(makeAction(ACTION_TOGGLE, paused ? "Reanudar" : "Pausar", 32));
            builder.addAction(makeAction(ACTION_NEXT, "Siguiente", 33));
            builder.addAction(makeAction(ACTION_STOP, "Detener", 34));
        }

        if (mediaSession != null) {
            builder.setStyle(new Notification.MediaStyle()
                    .setMediaSession(mediaSession.getSessionToken())
                    .setShowActionsInCompactView(0, 1, 2));
        }

        return builder.build();
    }

    private Notification.Action makeAction(String action, String title, int requestCode) {
        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(action);
        PendingIntent pendingIntent = PendingIntent.getService(this, requestCode, intent, pendingFlags());
        Icon icon = Icon.createWithResource(this, R.drawable.ic_notification);
        return new Notification.Action.Builder(icon, title, pendingIntent).build();
    }

    private void refreshNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(NOTIFICATION_ID, buildNotification());
        }
    }

    private String notificationText() {
        if (items.isEmpty() || index < 0 || index >= items.size()) {
            return "Listo para practicar";
        }
        String prefix;
        if (STATE_PAUSED.equals(currentState)) prefix = "Pausado";
        else if (STATE_WAITING.equals(currentState)) prefix = manualMode() ? "Clic power/asistente" : "Repite ahora";
        else if (STATE_PLAYING.equals(currentState)) prefix = "Escucha";
        else prefix = "Geo Exponer";

        String phrase = items.get(index).spoken;
        if (phrase.length() > 55) phrase = phrase.substring(0, 55) + "...";
        return prefix + ": " + phrase;
    }

    private void updatePlaybackState() {
        if (mediaSession == null) return;

        int playbackState;
        if (STATE_PLAYING.equals(currentState) || STATE_WAITING.equals(currentState)) {
            playbackState = PlaybackState.STATE_PLAYING;
        } else if (STATE_PAUSED.equals(currentState)) {
            // Con "volumen con pantalla apagada", Android solo manda el volumen a la app
            // si la sesión figura "reproduciendo". Si figura en pausa, el siguiente
            // botón de volumen cambia el volumen del celular y ya no reanuda.
            playbackState = (running && remoteVolumeActive)
                    ? PlaybackState.STATE_PLAYING
                    : PlaybackState.STATE_PAUSED;
        } else {
            playbackState = PlaybackState.STATE_STOPPED;
        }

        long actions = PlaybackState.ACTION_PLAY
                | PlaybackState.ACTION_PAUSE
                | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_STOP
                | PlaybackState.ACTION_SKIP_TO_NEXT
                | PlaybackState.ACTION_SKIP_TO_PREVIOUS;

        PlaybackState state = new PlaybackState.Builder()
                .setActions(actions)
                .setState(playbackState, PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1.0f)
                .build();
        mediaSession.setPlaybackState(state);
    }

    private int pendingFlags() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return flags;
    }

    private int mediaButtonPendingFlags() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            flags |= PendingIntent.FLAG_MUTABLE;
        }
        return flags;
    }
}
