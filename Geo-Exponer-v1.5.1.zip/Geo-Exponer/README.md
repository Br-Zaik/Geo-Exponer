# Geo Exponer v1.5

APK para practicar exposiciones con audio por auriculares Bluetooth.

Cambios de esta versión:
- Pensada para trabajar con la pantalla apagada/bloqueada.
- En modo manual, la app lee una frase y queda esperando.
- Clic en el botón power del celular, ya sea al prender o apagar pantalla, continúa con la siguiente frase si está esperando.
- No pausa solo por apagar pantalla; el audio sigue trabajando con el celular bloqueado.
- Botón de asistente / botón multimedia del auricular: intenta continuar, pausar o reanudar según el estado.
- El selector 1s / 2s / 3s / 5s / 8s / 10s queda solo para avance automático.
- Mantiene permiso de batería/segundo plano y notificación tipo reproductor.
- Velocidad: 0.25x, 0.50x, 0.75x, 1x, 1.25x, 1.50x.

Uso recomendado:
1. Pega tu exposición.
2. Selecciona modo Manual.
3. Inicia práctica.
4. Apaga la pantalla.
5. Escucha una frase por Bluetooth.
6. Repite.
7. Da clic al botón power o al botón de asistente/auricular para continuar.

Sin IA, sin API, sin Gemini, sin internet obligatorio, sin login.


Versión v1.5.1: se agregaron pausas rápidas de 1s y 2s para el modo automático/continuo.
