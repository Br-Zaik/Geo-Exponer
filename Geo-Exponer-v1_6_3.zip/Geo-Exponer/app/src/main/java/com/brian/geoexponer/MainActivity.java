package com.brian.geoexponer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.Html;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.BackgroundColorSpan;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.widget.CheckBox;
import android.widget.ScrollView;
import android.view.ViewGroup;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String KEY_BATTERY_PROMPT_SHOWN = "battery_prompt_shown";
    private static final int TAB_EXPONER = 0;
    private static final int TAB_TEXTOS = 1;

    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    private ScriptStore store;
    private ExpoSettings settings;
    private String currentScriptId = "";
    private boolean bindingText = false;
    private boolean syncingUi = false;

    private TextView scriptTitle;
    private View exponerPanel;
    private View textosPanel;
    private TextView navExponer;
    private TextView navTextos;
    private TextView navMemorizar;

    private TextView progressText;
    private TextView timerText;
    private ProgressBar progressBar;
    private TextView currentPhrase;
    private TextView statusText;
    private ImageButton playButton;
    private TextView quickMode;
    private TextView quickSpeed;
    private TextView quickPause;
    private ScrollView fullTextScroll;
    private TextView fullText;
    private EditText fullTextEdit;
    private TextView fullEditToggle;
    private boolean editingFull = false;
    private List<TextParser.Item> fullItems = new java.util.ArrayList<>();
    private int[] itemStarts = new int[0];
    private int[] itemEnds = new int[0];
    private SpannableStringBuilder fullSpannable;
    private BackgroundColorSpan highlightBg;
    private ForegroundColorSpan highlightFg;
    private int highlightedIndex = -1;

    private EditText inputText;
    private TextView scriptInfo;

    private View settingsOverlay;
    private View smartBox;
    private TextView smartLabel;
    private SeekBar smartSeek;
    private TextView targetLabel;
    private SeekBar targetSeek;
    private Switch switchCueTone;
    private Switch switchCueVoice;
    private Switch switchVibrate;
    private Switch switchHintRead;
    private Switch switchMultiTap;
    private CheckBox checkHeadset;
    private CheckBox checkVolume;
    private CheckBox checkVolumePocket;
    private CheckBox checkPower;

    private View pocketOverlay;
    private boolean pocketActive = false;
    private boolean pinnedByPocket = false;
    private int backTapCount = 0;
    private long firstBackTapMs = 0L;
    private AlertDialog pocketExitDialog;

    private String lastState = ExpoPlaybackService.STATE_STOPPED;
    private int lastTotal = 0;
    private int currentTab = TAB_EXPONER;

    private final Runnable saveTextRunnable = new Runnable() {
        @Override
        public void run() {
            if (store != null && inputText != null) {
                store.updateText(currentScriptId, inputText.getText().toString());
                updateScriptInfo();
            }
        }
    };

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            if (ExpoPlaybackService.ACTION_TICK.equals(intent.getAction())) {
                updateTimer(intent.getLongExtra(ExpoPlaybackService.EXTRA_ELAPSED_MS, 0L),
                        intent.getLongExtra(ExpoPlaybackService.EXTRA_TARGET_MS, 0L));
                return;
            }
            if (!ExpoPlaybackService.ACTION_STATUS.equals(intent.getAction())) return;
            applyStatus(intent);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        store = new ScriptStore(this);
        settings = new ExpoSettings(this);

        bindViews();
        setupTabs();
        setupExponerControls();
        setupTextos();
        setupSettingsSheet();
        setupQuickOptions();
        setupPocketMode();

        loadScript(store.current().id);
        showTab(TAB_EXPONER);

        requestNotificationPermissionIfNeeded();
        requestBatteryPermissionIfNeeded(false);

        if (savedInstanceState == null) {
            handleIncomingIntent(getIntent());
        }
        updatePlayButton();
    }

    private void bindViews() {
        scriptTitle = findViewById(R.id.scriptTitle);
        exponerPanel = findViewById(R.id.exponerPanel);
        textosPanel = findViewById(R.id.textosPanel);
        navExponer = findViewById(R.id.navExponer);
        navTextos = findViewById(R.id.navTextos);
        navMemorizar = findViewById(R.id.navMemorizar);

        progressText = findViewById(R.id.progressText);
        timerText = findViewById(R.id.timerText);
        progressBar = findViewById(R.id.progressBar);
        currentPhrase = findViewById(R.id.currentPhrase);
        statusText = findViewById(R.id.statusText);
        playButton = findViewById(R.id.playButton);
        quickMode = findViewById(R.id.quickMode);
        quickSpeed = findViewById(R.id.quickSpeed);
        quickPause = findViewById(R.id.quickPause);
        fullTextScroll = findViewById(R.id.fullTextScroll);
        fullText = findViewById(R.id.fullText);
        fullText.setMovementMethod(LinkMovementMethod.getInstance());
        fullText.setHighlightColor(0x00000000);
        fullTextEdit = findViewById(R.id.fullTextEdit);
        fullEditToggle = findViewById(R.id.fullEditToggle);
        fullEditToggle.setOnClickListener(v -> toggleFullEdit());

        inputText = findViewById(R.id.inputText);
        scriptInfo = findViewById(R.id.scriptInfo);

        settingsOverlay = findViewById(R.id.settingsOverlay);
        smartBox = findViewById(R.id.smartBox);
        smartLabel = findViewById(R.id.smartLabel);
        smartSeek = findViewById(R.id.smartSeek);
        targetLabel = findViewById(R.id.targetLabel);
        targetSeek = findViewById(R.id.targetSeek);
        switchCueTone = findViewById(R.id.switchCueTone);
        switchCueVoice = findViewById(R.id.switchCueVoice);
        switchVibrate = findViewById(R.id.switchVibrate);
        switchHintRead = findViewById(R.id.switchHintRead);
        switchMultiTap = findViewById(R.id.switchMultiTap);
        checkHeadset = findViewById(R.id.checkHeadset);
        checkVolume = findViewById(R.id.checkVolume);
        checkVolumePocket = findViewById(R.id.checkVolumePocket);
        checkPower = findViewById(R.id.checkPower);

        pocketOverlay = findViewById(R.id.pocketOverlay);
    }

    // ---------------------------------------------------------------- Pestañas

    private void setupTabs() {
        navExponer.setOnClickListener(v -> showTab(TAB_EXPONER));
        navTextos.setOnClickListener(v -> showTab(TAB_TEXTOS));
        navMemorizar.setOnClickListener(v -> openMemorizeMode());
        findViewById(R.id.titleBox).setOnClickListener(v -> showScriptPicker());
        findViewById(R.id.settingsButton).setOnClickListener(v -> openSettings());
    }

    private void showTab(int tab) {
        if (editingFull) finishFullEdit();
        currentTab = tab;
        exponerPanel.setVisibility(tab == TAB_EXPONER ? View.VISIBLE : View.GONE);
        textosPanel.setVisibility(tab == TAB_TEXTOS ? View.VISIBLE : View.GONE);
        navExponer.setSelected(tab == TAB_EXPONER);
        navTextos.setSelected(tab == TAB_TEXTOS);
        navMemorizar.setSelected(false);
        if (tab != TAB_TEXTOS) {
            flushTextSave();
            hideKeyboard();
            if (tab == TAB_EXPONER && !practiceRunning()) rebuildFullText();
        } else {
            updateScriptInfo();
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && inputText != null) imm.hideSoftInputFromWindow(inputText.getWindowToken(), 0);
            if (inputText != null) inputText.clearFocus();
        } catch (Exception ignored) {
        }
    }

    // ---------------------------------------------------------------- Exponer

    private void setupExponerControls() {
        playButton.setOnClickListener(v -> mainButtonAction());
        findViewById(R.id.previousButton).setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_PREVIOUS));
        findViewById(R.id.nextButton).setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_NEXT));
        findViewById(R.id.previousButton).setOnLongClickListener(v -> {
            sendSimpleAction(ExpoPlaybackService.ACTION_PREVIOUS_SLIDE);
            Toast.makeText(this, "Diapositiva anterior", Toast.LENGTH_SHORT).show();
            return true;
        });
        findViewById(R.id.nextButton).setOnLongClickListener(v -> {
            sendSimpleAction(ExpoPlaybackService.ACTION_NEXT_SLIDE);
            Toast.makeText(this, "Siguiente diapositiva", Toast.LENGTH_SHORT).show();
            return true;
        });
        findViewById(R.id.repeatButton).setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_REPEAT));
        findViewById(R.id.stopButton).setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_STOP));
    }

    private void applyStatus(Intent intent) {
        String state = intent.getStringExtra(ExpoPlaybackService.EXTRA_STATE);
        int index = intent.getIntExtra(ExpoPlaybackService.EXTRA_INDEX, 0);
        int total = intent.getIntExtra(ExpoPlaybackService.EXTRA_TOTAL, 0);
        String phrase = intent.getStringExtra(ExpoPlaybackService.EXTRA_PHRASE);
        String slideTitle = intent.getStringExtra(ExpoPlaybackService.EXTRA_SLIDE_TITLE);
        int slideIndex = intent.getIntExtra(ExpoPlaybackService.EXTRA_SLIDE_INDEX, 0);
        int slideCount = intent.getIntExtra(ExpoPlaybackService.EXTRA_SLIDE_COUNT, 0);
        int inSlide = intent.getIntExtra(ExpoPlaybackService.EXTRA_PHRASE_IN_SLIDE, 0);
        int ofSlide = intent.getIntExtra(ExpoPlaybackService.EXTRA_PHRASES_IN_SLIDE, 0);

        lastState = state != null ? state : ExpoPlaybackService.STATE_STOPPED;
        lastTotal = total;

        if (phrase != null && phrase.trim().length() > 0) {
            currentPhrase.setText(html(phrase));
        }

        if (total > 0) {
            if (slideCount > 1) {
                String title = slideTitle != null ? slideTitle : ("Diapo " + slideIndex);
                progressText.setText(title + "  ·  " + inSlide + "/" + ofSlide + "  ·  diapo " + slideIndex + "/" + slideCount);
            } else {
                progressText.setText("Frase " + index + " / " + total);
            }
            progressBar.setProgress(Math.round(1000f * index / total));
            if (total == fullItems.size()) highlightItem(index - 1, true);
        } else {
            progressText.setText("Listo");
            progressBar.setProgress(0);
        }

        updateTimer(intent.getLongExtra(ExpoPlaybackService.EXTRA_ELAPSED_MS, 0L),
                intent.getLongExtra(ExpoPlaybackService.EXTRA_TARGET_MS, 0L));
        statusText.setText(stateText(lastState));
        updatePlayButton();
    }

    // ---------------------------------------------------------------- Cuadro de texto completo

    /** Arma el cuadro del texto completo: títulos de diapositiva y frases tocables. */
    private void rebuildFullText() {
        if (fullText == null) return;
        String text = inputText.getText().toString();
        List<TextParser.Section> sections = TextParser.parseSections(text);
        fullItems = TextParser.flatten(sections);
        itemStarts = new int[fullItems.size()];
        itemEnds = new int[fullItems.size()];
        highlightedIndex = -1;
        highlightBg = null;
        highlightFg = null;

        SpannableStringBuilder b = new SpannableStringBuilder();
        if (fullItems.isEmpty()) {
            b.append("Pega tu exposición en la pestaña Textos.");
            fullSpannable = b;
            fullText.setText(b);
            return;
        }
        int lastSlide = -1;
        int primary = getResources().getColor(R.color.primary_blue);
        for (int i = 0; i < fullItems.size(); i++) {
            TextParser.Item item = fullItems.get(i);
            if (item.slideIndex != lastSlide) {
                if (b.length() > 0) b.append("\n\n");
                if (item.slideCount > 1 || !"Todo el texto".equals(item.slideTitle)) {
                    int ts = b.length();
                    b.append(item.slideTitle);
                    b.setSpan(new ForegroundColorSpan(primary), ts, b.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    b.setSpan(new StyleSpan(Typeface.BOLD), ts, b.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    b.setSpan(new RelativeSizeSpan(0.9f), ts, b.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    b.append("\n");
                }
                lastSlide = item.slideIndex;
            } else {
                b.append(' ');
            }
            int start = b.length();
            b.append(item.spoken);
            int end = b.length();
            itemStarts[i] = start;
            itemEnds[i] = end;
            final int target = i;
            b.setSpan(new ClickableSpan() {
                @Override
                public void onClick(View widget) {
                    if (pocketActive) return;
                    jumpToPhrase(target);
                }

                @Override
                public void updateDrawState(TextPaint ds) {
                    ds.setUnderlineText(false);
                }
            }, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        fullSpannable = b;
        fullText.setText(b);
    }

    private void highlightItem(int i, boolean scroll) {
        if (fullSpannable == null || i < 0 || i >= itemStarts.length) return;
        if (i == highlightedIndex) return;
        if (highlightBg != null) fullSpannable.removeSpan(highlightBg);
        if (highlightFg != null) fullSpannable.removeSpan(highlightFg);
        highlightBg = new BackgroundColorSpan(0x3313B9FF);
        highlightFg = new ForegroundColorSpan(getResources().getColor(R.color.text_main));
        fullSpannable.setSpan(highlightBg, itemStarts[i], itemEnds[i], Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        fullSpannable.setSpan(highlightFg, itemStarts[i], itemEnds[i], Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        highlightedIndex = i;
        fullText.setText(fullSpannable);
        if (scroll) {
            final int offset = itemStarts[i];
            fullText.post(() -> {
                if (fullText.getLayout() == null) return;
                int line = fullText.getLayout().getLineForOffset(offset);
                int y = fullText.getLayout().getLineTop(line) + fullText.getPaddingTop();
                fullTextScroll.smoothScrollTo(0, Math.max(0, y - fullTextScroll.getHeight() / 3));
            });
        }
    }

    /** ✎ = editar el texto aquí mismo; ✓ = guardar y volver a modo lectura. */
    private void toggleFullEdit() {
        if (pocketActive) return;
        if (!editingFull) {
            if (practiceRunning()) {
                sendSimpleAction(ExpoPlaybackService.ACTION_STOP);
                Toast.makeText(this, "Práctica detenida para editar.", Toast.LENGTH_SHORT).show();
            }
            editingFull = true;
            final String raw = inputText.getText().toString();
            fullTextEdit.setText(raw);
            final int cursor = locatePhrase(raw, fullItems, highlightedIndex);
            fullTextScroll.setVisibility(View.GONE);
            fullTextEdit.setVisibility(View.VISIBLE);
            fullEditToggle.setText("✓");
            fullEditToggle.setContentDescription("Guardar texto");
            fullTextEdit.requestFocus();
            fullTextEdit.post(() -> {
                try {
                    fullTextEdit.setSelection(Math.max(0, Math.min(cursor, fullTextEdit.length())));
                    fullTextEdit.bringPointIntoView(fullTextEdit.getSelectionStart());
                } catch (Exception ignored) {
                }
                try {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(fullTextEdit, InputMethodManager.SHOW_IMPLICIT);
                } catch (Exception ignored) {
                }
            });
        } else {
            finishFullEdit();
        }
    }

    /** Posición en el texto donde empieza la frase actual (para abrir el editor ahí). */
    static int locatePhrase(String raw, List<TextParser.Item> items, int target) {
        if (raw == null || items == null || target < 0 || target >= items.size()) return 0;
        int pos = 0;
        for (int i = 0; i <= target; i++) {
            String phrase = items.get(i).raw;
            int found = raw.indexOf(phrase, pos);
            if (found < 0) {
                String head = phrase.length() > 20 ? phrase.substring(0, 20) : phrase;
                found = raw.indexOf(head, pos);
            }
            if (found < 0) continue;
            if (i == target) return found;
            pos = found + Math.min(phrase.length(), Math.max(1, raw.length() - found));
        }
        return 0;
    }

    private void finishFullEdit() {
        if (!editingFull) return;
        editingFull = false;
        String edited = fullTextEdit.getText().toString();
        if (!edited.equals(inputText.getText().toString())) {
            bindingText = true;
            inputText.setText(edited);
            bindingText = false;
            store.updateText(currentScriptId, edited);
            updateScriptInfo();
        }
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(fullTextEdit.getWindowToken(), 0);
        } catch (Exception ignored) {
        }
        fullTextEdit.clearFocus();
        fullTextEdit.setVisibility(View.GONE);
        fullTextScroll.setVisibility(View.VISIBLE);
        fullEditToggle.setText("✎");
        fullEditToggle.setContentDescription("Editar texto");
        rebuildFullText();
    }

    /** Tocar una frase del texto: salta ahí (o empieza desde ahí). */
    private void jumpToPhrase(int i) {
        if (practiceRunning() && lastTotal == fullItems.size()) {
            Intent intent = new Intent(this, ExpoPlaybackService.class);
            intent.setAction(ExpoPlaybackService.ACTION_JUMP);
            intent.putExtra(ExpoPlaybackService.EXTRA_JUMP_INDEX, i);
            startServiceCompat(intent);
        } else {
            startPracticeAt(i);
        }
    }

    private CharSequence html(String raw) {
        String h = TextParser.toHtml(raw);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return Html.fromHtml(h, Html.FROM_HTML_MODE_LEGACY);
        }
        //noinspection deprecation
        return Html.fromHtml(h);
    }

    private void updateTimer(long elapsedMs, long targetMs) {
        String text = formatTime(elapsedMs);
        if (targetMs > 0) text = text + " / " + formatTime(targetMs);
        timerText.setText(text);
        if (targetMs > 0 && elapsedMs > targetMs) {
            timerText.setTextColor(getResources().getColor(R.color.warn_red));
        } else if (targetMs > 0 && elapsedMs > targetMs - 60_000L) {
            timerText.setTextColor(0xFFFFC857);
        } else {
            timerText.setTextColor(getResources().getColor(R.color.text_soft));
        }
    }

    private static String formatTime(long ms) {
        long totalSec = Math.max(0L, ms / 1000L);
        return String.format(Locale.US, "%02d:%02d", totalSec / 60, totalSec % 60);
    }

    private boolean practiceRunning() {
        return lastTotal > 0
                && !ExpoPlaybackService.STATE_STOPPED.equals(lastState)
                && !ExpoPlaybackService.STATE_ERROR.equals(lastState);
    }

    private void mainButtonAction() {
        if (editingFull) finishFullEdit();
        if (practiceRunning()) {
            sendSimpleAction(ExpoPlaybackService.ACTION_TOGGLE);
        } else {
            startPractice();
        }
    }

    private void updatePlayButton() {
        if (playButton == null) return;
        boolean showPause;
        String description;
        if (!practiceRunning()) {
            showPause = false;
            description = "Iniciar";
        } else if (ExpoPlaybackService.STATE_WAITING.equals(lastState)) {
            boolean manual = ExpoPlaybackService.MODE_MANUAL.equals(settings.mode());
            showPause = !manual;
            description = manual ? "Continuar" : "Pausar";
        } else if (ExpoPlaybackService.STATE_PAUSED.equals(lastState)) {
            showPause = false;
            description = "Reanudar";
        } else {
            showPause = true;
            description = "Pausar";
        }
        playButton.setImageResource(showPause ? R.drawable.ic_pause : R.drawable.ic_play);
        playButton.setContentDescription(description);
    }

    private void startPractice() {
        startPracticeAt(0);
    }

    private void startPracticeAt(int startIndex) {
        flushTextSave();
        String text = inputText.getText().toString().trim();
        if (TextParser.parseItems(text).isEmpty()) {
            Toast.makeText(this, "Primero pega tu texto en la pestaña Textos.", Toast.LENGTH_SHORT).show();
            showTab(TAB_TEXTOS);
            return;
        }

        rebuildFullText();
        currentPhrase.setText("Preparando lectura...");
        statusText.setText("Iniciando...");
        lastState = ExpoPlaybackService.STATE_PLAYING;
        lastTotal = 1;
        updatePlayButton();

        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(ExpoPlaybackService.ACTION_START);
        intent.putExtra(ExpoPlaybackService.EXTRA_TEXT, text);
        intent.putExtra(ExpoPlaybackService.EXTRA_SCRIPT_ID, currentScriptId);
        intent.putExtra(ExpoPlaybackService.EXTRA_JUMP_INDEX, startIndex);
        putSettingsExtras(intent);
        startServiceCompat(intent);
    }

    private void putSettingsExtras(Intent intent) {
        String mode = settings.mode();
        intent.putExtra(ExpoPlaybackService.EXTRA_MODE, mode);
        intent.putExtra(ExpoPlaybackService.EXTRA_SPEED, settings.speed());
        intent.putExtra(ExpoPlaybackService.EXTRA_PAUSE_MS,
                ExpoPlaybackService.MODE_MANUAL.equals(mode) ? -1 : settings.pauseMs());
        intent.putExtra(ExpoPlaybackService.EXTRA_SMART_FACTOR, settings.smartFactor());
        intent.putExtra(ExpoPlaybackService.EXTRA_CUE_TONE, settings.cueTone());
        intent.putExtra(ExpoPlaybackService.EXTRA_CUE_VOICE, settings.cueVoice());
        intent.putExtra(ExpoPlaybackService.EXTRA_VIBRATE, settings.vibrate());
        intent.putExtra(ExpoPlaybackService.EXTRA_TARGET_MIN, settings.targetMinutes());
        intent.putExtra(ExpoPlaybackService.EXTRA_HINT_READ, settings.hintRead());
        intent.putExtra(ExpoPlaybackService.EXTRA_MULTI_TAP, settings.multiTap());
    }

    private void sendSettingsUpdateIfRunning() {
        if (!practiceRunning()) return;
        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(ExpoPlaybackService.ACTION_UPDATE_SETTINGS);
        putSettingsExtras(intent);
        startServiceCompat(intent);
    }

    private void sendSimpleAction(String action) {
        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(action);
        startServiceCompat(intent);
    }

    private void startServiceCompat(Intent intent) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo iniciar el servicio de voz.", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------- Botones físicos

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int keyCode = event.getKeyCode();
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
                && event.getAction() == KeyEvent.ACTION_DOWN
                && event.getRepeatCount() == 0) {
            if (practiceRunning()) {
                if (PhysicalControlSettings.isConfigured(this)) {
                    // Si "volumen con pantalla apagada" está marcado, el servicio lo recibe directo.
                    if (PhysicalControlSettings.volume(this) && !PhysicalControlSettings.volumePocket(this)) {
                        sendSimpleAction(ExpoPlaybackService.ACTION_PHYSICAL_TOGGLE);
                    }
                } else if (ExpoPlaybackService.MODE_MIXED.equals(settings.mode())) {
                    // Comportamiento original hasta que el usuario marque las casillas.
                    sendSimpleAction(ExpoPlaybackService.ACTION_TOGGLE);
                }
            }
            return super.dispatchKeyEvent(event);
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_ASSIST
                || keyCode == KeyEvent.KEYCODE_VOICE_ASSIST
                || keyCode == KeyEvent.KEYCODE_HEADSETHOOK
                || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            boolean headsetKey = keyCode == KeyEvent.KEYCODE_HEADSETHOOK || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
            if (!headsetKey || PhysicalControlSettings.headset(this)) {
                sendSimpleAction(ExpoPlaybackService.ACTION_ASSIST_TOGGLE);
            }
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        if (pocketActive) {
            onPocketBackTap();
            return;
        }
        if (settingsOverlay.getVisibility() == View.VISIBLE) {
            closeSettings();
            return;
        }
        if (editingFull) {
            finishFullEdit();
            return;
        }
        if (currentTab != TAB_EXPONER) {
            showTab(TAB_EXPONER);
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_VOICE_COMMAND.equals(action)) {
            sendSimpleAction(ExpoPlaybackService.ACTION_ASSIST_TOGGLE);
            return;
        }
        if (Intent.ACTION_SEND.equals(action)) {
            String shared = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (shared != null && shared.trim().length() > 0) {
                String subject = intent.getStringExtra(Intent.EXTRA_SUBJECT);
                ScriptStore.Script s = store.create(subject != null ? subject : null, shared.trim());
                loadScript(s.id);
                showTab(TAB_TEXTOS);
                Toast.makeText(this, "Texto recibido como nueva exposición.", Toast.LENGTH_SHORT).show();
            }
            // Evitar que se vuelva a importar al girar la pantalla.
            intent.setAction(Intent.ACTION_MAIN);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter();
        filter.addAction(ExpoPlaybackService.ACTION_STATUS);
        filter.addAction(ExpoPlaybackService.ACTION_TICK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(statusReceiver, filter);
        }
        sendSimpleAction(ExpoPlaybackService.ACTION_STATUS_REQUEST);
    }

    @Override
    protected void onResume() {
        super.onResume();
        navMemorizar.setSelected(false);
        reloadIfChangedElsewhere();
        if (currentTab == TAB_TEXTOS) updateScriptInfo();
    }

    @Override
    protected void onPause() {
        if (editingFull) {
            String edited = fullTextEdit.getText().toString();
            if (!edited.equals(inputText.getText().toString())) {
                bindingText = true;
                inputText.setText(edited);
                bindingText = false;
            }
        }
        flushTextSave();
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            unregisterReceiver(statusReceiver);
        } catch (IllegalArgumentException ignored) {
        }
    }

    // ---------------------------------------------------------------- Textos

    private void setupTextos() {
        inputText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (bindingText) return;
                uiHandler.removeCallbacks(saveTextRunnable);
                uiHandler.postDelayed(saveTextRunnable, 500L);
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        findViewById(R.id.newScriptButton).setOnClickListener(v -> askNewScript());
        findViewById(R.id.pasteButton).setOnClickListener(v -> pasteFromClipboard());
        findViewById(R.id.scriptMenuButton).setOnClickListener(v -> showScriptMenu());
    }

    private void flushTextSave() {
        uiHandler.removeCallbacks(saveTextRunnable);
        if (store != null && inputText != null && !currentScriptId.isEmpty()) {
            store.updateText(currentScriptId, inputText.getText().toString());
        }
    }

    private void loadScript(String id) {
        flushTextSave();
        ScriptStore.Script s = store.find(id);
        if (s == null) s = store.current();
        store.select(s.id);
        currentScriptId = s.id;
        bindingText = true;
        inputText.setText(s.text);
        bindingText = false;
        scriptTitle.setText(s.name + " ▾");
        updateScriptInfo();
        rebuildFullText();
    }

    /** Si el texto se editó en Memorizar, cargar la versión nueva. */
    private void reloadIfChangedElsewhere() {
        uiHandler.removeCallbacks(saveTextRunnable);
        store = new ScriptStore(this);
        ScriptStore.Script s = store.find(currentScriptId);
        if (s == null) return;
        if (!s.text.equals(inputText.getText().toString())) {
            bindingText = true;
            inputText.setText(s.text);
            bindingText = false;
            if (editingFull) fullTextEdit.setText(s.text);
            updateScriptInfo();
            if (!practiceRunning()) rebuildFullText();
        }
    }

    private void updateScriptInfo() {
        if (scriptInfo == null) return;
        String text = inputText.getText().toString();
        List<TextParser.Section> sections = TextParser.parseSections(text);
        int phrases = 0;
        int words = 0;
        for (TextParser.Section s : sections) {
            phrases += s.phrases.size();
            for (String p : s.phrases) words += TextParser.wordCount(p);
        }
        if (phrases == 0) {
            scriptInfo.setText("Sin texto todavía");
            return;
        }
        int minutes = Math.max(1, Math.round(words / 130f));
        StringBuilder info = new StringBuilder();
        info.append(sections.size()).append(sections.size() == 1 ? " diapositiva" : " diapositivas");
        info.append(" · ").append(phrases).append(" frases");
        info.append(" · ~").append(minutes).append(" min");
        int rehearsals = store.rehearsals(currentScriptId);
        if (rehearsals > 0) {
            info.append(" · Ensayos: ").append(rehearsals)
                    .append(" (último ").append(formatTime(store.lastDurationMs(currentScriptId))).append(")");
        }
        scriptInfo.setText(info.toString());
    }

    private void confirmStopIfRunning(Runnable then) {
        if (!practiceRunning()) {
            then.run();
            return;
        }
        sendSimpleAction(ExpoPlaybackService.ACTION_STOP);
        then.run();
    }

    private void showScriptPicker() {
        flushTextSave();
        final List<ScriptStore.Script> all = store.all();
        String[] names = new String[all.size() + 1];
        int checked = 0;
        for (int i = 0; i < all.size(); i++) {
            names[i] = all.get(i).name;
            if (all.get(i).id.equals(currentScriptId)) checked = i;
        }
        names[all.size()] = "+ Nueva exposición";
        new AlertDialog.Builder(this)
                .setTitle("Mis exposiciones")
                .setSingleChoiceItems(names, checked, (dialog, which) -> {
                    dialog.dismiss();
                    if (which == all.size()) {
                        askNewScript();
                    } else if (!all.get(which).id.equals(currentScriptId)) {
                        confirmStopIfRunning(() -> loadScript(all.get(which).id));
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void askNewScript() {
        final EditText name = new EditText(this);
        name.setHint("Nombre (ej. Charla SST)");
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        name.setSingleLine(true);
        LinearLayout box = new LinearLayout(this);
        int pad = Math.round(20 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(name, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle("Nueva exposición")
                .setView(box)
                .setPositiveButton("Crear", (d, w) -> confirmStopIfRunning(() -> {
                    flushTextSave();
                    ScriptStore.Script s = store.create(name.getText().toString(), "");
                    loadScript(s.id);
                    showTab(TAB_TEXTOS);
                }))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showScriptMenu() {
        String[] options = {"Cambiar de exposición", "Renombrar", "Copiar todo el texto", "Eliminar esta exposición"};
        new AlertDialog.Builder(this)
                .setItems(options, (dialog, which) -> {
                    if (which == 0) showScriptPicker();
                    else if (which == 1) askRename();
                    else if (which == 2) copyAllText();
                    else if (which == 3) askDelete();
                })
                .show();
    }

    private void askRename() {
        ScriptStore.Script s = store.find(currentScriptId);
        if (s == null) return;
        final EditText name = new EditText(this);
        name.setText(s.name);
        name.setSingleLine(true);
        name.setSelectAllOnFocus(true);
        LinearLayout box = new LinearLayout(this);
        int pad = Math.round(20 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(name, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle("Renombrar")
                .setView(box)
                .setPositiveButton("Guardar", (d, w) -> {
                    store.rename(currentScriptId, name.getText().toString());
                    ScriptStore.Script updated = store.find(currentScriptId);
                    if (updated != null) scriptTitle.setText(updated.name + " ▾");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void askDelete() {
        ScriptStore.Script s = store.find(currentScriptId);
        if (s == null) return;
        new AlertDialog.Builder(this)
                .setTitle("¿Eliminar «" + s.name + "»?")
                .setMessage("Se borrará el texto de esta exposición.")
                .setPositiveButton("Eliminar", (d, w) -> confirmStopIfRunning(() -> {
                    store.delete(currentScriptId);
                    currentScriptId = "";
                    loadScript(store.current().id);
                }))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void copyAllText() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("Exposición", inputText.getText().toString()));
                Toast.makeText(this, "Texto copiado.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ignored) {
        }
    }

    private void pasteFromClipboard() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip() == null
                    || cm.getPrimaryClip().getItemCount() == 0) {
                Toast.makeText(this, "El portapapeles está vacío.", Toast.LENGTH_SHORT).show();
                return;
            }
            CharSequence clip = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (clip == null || clip.toString().trim().isEmpty()) {
                Toast.makeText(this, "El portapapeles está vacío.", Toast.LENGTH_SHORT).show();
                return;
            }
            final String pasted = clip.toString();
            if (inputText.getText().toString().trim().isEmpty()) {
                inputText.setText(pasted);
                flushTextSave();
                updateScriptInfo();
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("Pegar texto")
                    .setItems(new String[]{"Reemplazar todo", "Agregar al final"}, (d, which) -> {
                        if (which == 0) {
                            inputText.setText(pasted);
                        } else {
                            inputText.append("\n\n" + pasted);
                        }
                        flushTextSave();
                        updateScriptInfo();
                    })
                    .show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo pegar.", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------- Memorizar

    private void openMemorizeMode() {
        if (editingFull) finishFullEdit();
        flushTextSave();
        String text = inputText.getText().toString().trim();
        if (TextParser.parseItems(text).isEmpty()) {
            Toast.makeText(this, "Primero pega tu texto en la pestaña Textos.", Toast.LENGTH_SHORT).show();
            showTab(TAB_TEXTOS);
            return;
        }
        if (practiceRunning()) {
            sendSimpleAction(ExpoPlaybackService.ACTION_STOP);
        }
        Intent intent = new Intent(this, MemorizeActivity.class);
        intent.putExtra(MemorizeActivity.EXTRA_MEMORY_TEXT, text);
        startActivity(intent);
    }

    // ---------------------------------------------------------------- Ajustes

    private static final String[] MODE_VALUES = {
            ExpoPlaybackService.MODE_MANUAL, ExpoPlaybackService.MODE_AUTO, ExpoPlaybackService.MODE_MIXED};
    private static final String[] MODE_LABELS = {"Manual", "Auto", "Mixto"};
    private static final String[] SPEED_PICK = {"0.25", "0.5", "0.625", "0.75", "1.0", "1.25", "1.5"};
    private static final String[] PAUSE_PICK = {"Según frase", "0 s", "1 s", "2 s", "3 s", "5 s", "8 s", "10 s"};

    private void setupQuickOptions() {
        quickMode.setOnClickListener(v -> {
            int sel = 0;
            for (int i = 0; i < MODE_VALUES.length; i++) {
                if (MODE_VALUES[i].equals(settings.mode())) sel = i;
            }
            ValuePicker.show(this, "Modo", MODE_LABELS, sel, i -> {
                settings.setMode(MODE_VALUES[i]);
                syncQuickOptions();
                sendSettingsUpdateIfRunning();
                updatePlayButton();
            });
        });
        quickSpeed.setOnClickListener(v -> ValuePicker.show(this, "Velocidad de voz", SPEED_PICK,
                settings.speedIndex(), i -> {
                    settings.setSpeedIndex(i);
                    syncQuickOptions();
                    sendSettingsUpdateIfRunning();
                }));
        quickPause.setOnClickListener(v -> {
            if (ExpoPlaybackService.MODE_MANUAL.equals(settings.mode())) {
                Toast.makeText(this, "En Manual avanzas tú. Elige Auto o Mixto para usar el tiempo entre frases.", Toast.LENGTH_LONG).show();
                return;
            }
            ValuePicker.show(this, "Tiempo entre frases", PAUSE_PICK, settings.pauseIndex(), i -> {
                settings.setPauseIndex(i);
                syncQuickOptions();
                sendSettingsUpdateIfRunning();
            });
        });
        syncQuickOptions();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void syncQuickOptions() {
        String mode = settings.mode();
        String modeLabel = MODE_LABELS[0];
        for (int i = 0; i < MODE_VALUES.length; i++) {
            if (MODE_VALUES[i].equals(mode)) modeLabel = MODE_LABELS[i];
        }
        quickMode.setText(modeLabel + " ▾");
        quickSpeed.setText("x" + SPEED_PICK[settings.speedIndex()] + " ▾");
        boolean manual = ExpoPlaybackService.MODE_MANUAL.equals(mode);
        if (manual) {
            quickPause.setText("⏱ Tú avanzas");
            quickPause.setAlpha(0.5f);
        } else {
            String p = settings.pauseIndex() == 0 ? "Auto" : PAUSE_PICK[settings.pauseIndex()].replace(" ", "");
            quickPause.setText("⏱ " + p + " ▾");
            quickPause.setAlpha(1f);
        }
    }

    private void setupSettingsSheet() {
        findViewById(R.id.settingsScrim).setOnClickListener(v -> closeSettings());
        findViewById(R.id.settingsClose).setOnClickListener(v -> closeSettings());

        smartSeek.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                settings.setSmartIndex(progress);
                syncSettingsUi();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                sendSettingsUpdateIfRunning();
            }
        });
        targetSeek.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                settings.setTargetMinutes(progress);
                syncSettingsUi();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                sendSettingsUpdateIfRunning();
            }
        });

        switchCueTone.setOnCheckedChangeListener((b, checked) -> {
            if (syncingUi) return;
            settings.setCueTone(checked);
            sendSettingsUpdateIfRunning();
        });
        switchCueVoice.setOnCheckedChangeListener((b, checked) -> {
            if (syncingUi) return;
            settings.setCueVoice(checked);
            sendSettingsUpdateIfRunning();
        });
        switchVibrate.setOnCheckedChangeListener((b, checked) -> {
            if (syncingUi) return;
            settings.setVibrate(checked);
            sendSettingsUpdateIfRunning();
        });
        switchHintRead.setOnCheckedChangeListener((b, checked) -> {
            if (syncingUi) return;
            settings.setHintRead(checked);
            sendSettingsUpdateIfRunning();
        });
        switchMultiTap.setOnCheckedChangeListener((b, checked) -> {
            if (syncingUi) return;
            settings.setMultiTap(checked);
            sendSettingsUpdateIfRunning();
        });

        CheckBox[] checks = {checkHeadset, checkVolume, checkVolumePocket, checkPower};
        for (CheckBox c : checks) {
            c.setOnCheckedChangeListener((b, checked) -> {
                if (syncingUi) return;
                PhysicalControlSettings.set(this,
                        checkVolume.isChecked(),
                        checkVolumePocket.isChecked(),
                        checkPower.isChecked(),
                        checkHeadset.isChecked());
                sendSettingsUpdateIfRunning();
            });
        }

        findViewById(R.id.prepareButton).setOnClickListener(v -> showPreparePhone());
        syncSettingsUi();
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar seekBar) {}
        @Override public void onStopTrackingTouch(SeekBar seekBar) {}
    }

    private void syncSettingsUi() {
        syncingUi = true;
        try {
            boolean smart = !ExpoPlaybackService.MODE_MANUAL.equals(settings.mode())
                    && settings.pauseMs() == ExpoSettings.PAUSE_SMART;
            smartBox.setVisibility(smart ? View.VISIBLE : View.GONE);
            smartSeek.setProgress(settings.smartIndex());
            smartLabel.setText("Pausa «según frase»: " + ExpoSettings.SMART_LABELS[settings.smartIndex()] + " lo que dura la frase");

            targetSeek.setProgress(settings.targetMinutes());
            targetLabel.setText(settings.targetMinutes() == 0
                    ? "Tiempo objetivo: sin límite"
                    : "Tiempo objetivo: " + settings.targetMinutes() + " min (aviso 1 min antes)");

            switchCueTone.setChecked(settings.cueTone());
            switchCueVoice.setChecked(settings.cueVoice());
            switchVibrate.setChecked(settings.vibrate());
            switchHintRead.setChecked(settings.hintRead());
            switchMultiTap.setChecked(settings.multiTap());

            boolean configured = PhysicalControlSettings.isConfigured(this);
            checkHeadset.setChecked(PhysicalControlSettings.headset(this));
            checkVolume.setChecked(configured ? PhysicalControlSettings.volume(this)
                    : ExpoPlaybackService.MODE_MIXED.equals(settings.mode()));
            checkVolumePocket.setChecked(PhysicalControlSettings.volumePocket(this));
            checkPower.setChecked(configured ? PhysicalControlSettings.power(this)
                    : !ExpoPlaybackService.MODE_AUTO.equals(settings.mode()));
        } finally {
            syncingUi = false;
        }
    }

    private void openSettings() {
        hideKeyboard();
        syncSettingsUi();
        settingsOverlay.setVisibility(View.VISIBLE);
    }

    private void closeSettings() {
        settingsOverlay.setVisibility(View.GONE);
    }

    private void showPreparePhone() {
        String brand = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase(Locale.US);
        String tip;
        if (brand.contains("xiaomi") || brand.contains("redmi") || brand.contains("poco")) {
            tip = "Xiaomi/Redmi/POCO:\n• Batería: «Sin restricciones».\n• Activa «Inicio automático».\n• En Recientes, bloquea la app con el candado.";
        } else if (brand.contains("samsung")) {
            tip = "Samsung:\n• Batería > Límites de uso en segundo plano.\n• Agrega Geo Exponer a «Apps que nunca se suspenden».";
        } else if (brand.contains("huawei") || brand.contains("honor")) {
            tip = "Huawei/Honor:\n• Batería > Inicio de apps: gestionar manualmente y activa todo.";
        } else if (brand.contains("oppo") || brand.contains("realme") || brand.contains("oneplus") || brand.contains("vivo")) {
            tip = "OPPO/realme/OnePlus/vivo:\n• Batería: permitir actividad en segundo plano.\n• Permite inicio automático.";
        } else {
            tip = "• Batería: «Sin restricciones» para Geo Exponer.";
        }
        String status = isIgnoringBatteryOptimizations()
                ? "✓ Permiso de batería: permitido.\n\n"
                : "✗ Permiso de batería: falta.\n\n";
        new AlertDialog.Builder(this)
                .setTitle("Preparar mi celular")
                .setMessage(status + tip + "\n\nConsejo: activa «No molestar» al exponer para que ninguna notificación encienda la pantalla.")
                .setPositiveButton("Permiso de batería", (d, w) -> openBatteryPermissionScreen())
                .setNeutralButton("Ajustes de la app", (d, w) -> openAppSettings())
                .setNegativeButton("Cerrar", null)
                .show();
    }

    // ---------------------------------------------------------------- Modo bolsillo

    private void setupPocketMode() {
        findViewById(R.id.pocketButton).setOnClickListener(v -> enterPocketMode());
        // La capa transparente se come todos los toques: la pantalla se ve igual pero no responde.
        pocketOverlay.setOnClickListener(v -> { });
        pocketOverlay.setOnLongClickListener(v -> true);
    }

    private void enterPocketMode() {
        if (editingFull) finishFullEdit();
        closeSettings();
        hideKeyboard();
        pocketActive = true;
        backTapCount = 0;
        pocketOverlay.setVisibility(View.VISIBLE);
        // "Fijar pantalla" de Android: inicio y recientes no sacan de la app.
        pinnedByPocket = false;
        try {
            startLockTask();
            pinnedByPocket = true;
        } catch (Exception ignored) {
        }
        Toast.makeText(this, "Bolsillo: toques bloqueados. Atrás ◁ 3 veces para salir.", Toast.LENGTH_SHORT).show();
    }

    private void onPocketBackTap() {
        long now = SystemClock.elapsedRealtime();
        if (backTapCount == 0 || now - firstBackTapMs > 1500L) {
            backTapCount = 0;
            firstBackTapMs = now;
        }
        backTapCount++;
        if (backTapCount >= 3) {
            backTapCount = 0;
            askExitPocket();
        }
    }

    private void askExitPocket() {
        if (pocketExitDialog != null && pocketExitDialog.isShowing()) return;
        pocketExitDialog = new AlertDialog.Builder(this)
                .setTitle("¿Deseas salir del modo bolsillo?")
                .setPositiveButton("Salir", (d, w) -> exitPocketMode())
                .setNegativeButton("Cancelar", null)
                .create();
        pocketExitDialog.show();
    }

    private void exitPocketMode() {
        pocketActive = false;
        backTapCount = 0;
        pocketOverlay.setVisibility(View.GONE);
        if (pinnedByPocket) {
            try {
                stopLockTask();
            } catch (Exception ignored) {
            }
            pinnedByPocket = false;
        }
    }

    // ---------------------------------------------------------------- Permisos

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
            }
        }
    }

    private void requestBatteryPermissionIfNeeded(boolean forcedByUser) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
        if (isIgnoringBatteryOptimizations()) {
            if (forcedByUser) Toast.makeText(this, "Permiso de batería ya permitido.", Toast.LENGTH_SHORT).show();
            return;
        }
        android.content.SharedPreferences prefs = getSharedPreferences(ScriptStore.PREFS, MODE_PRIVATE);
        boolean shownBefore = prefs.getBoolean(KEY_BATTERY_PROMPT_SHOWN, false);
        if (!forcedByUser && shownBefore) return;
        prefs.edit().putBoolean(KEY_BATTERY_PROMPT_SHOWN, true).apply();

        new AlertDialog.Builder(this)
                .setTitle("Permiso de batería")
                .setMessage("Para que Geo Exponer no se cierre con la pantalla apagada, toca Permitir. Luego revisa ⚙ > Preparar mi celular.")
                .setPositiveButton("Abrir permiso", (dialog, which) -> openBatteryPermissionScreen())
                .setNegativeButton("Luego", null)
                .show();
    }

    private boolean isIgnoringBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    private void openBatteryPermissionScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (isIgnoringBatteryOptimizations()) {
                Toast.makeText(this, "Permiso de batería ya permitido.", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                return;
            } catch (Exception ignored) {
            }
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                return;
            } catch (Exception ignored) {
            }
        }
        openAppSettings();
    }

    private void openAppSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception ignored) {
            Toast.makeText(this, "Hazlo manual desde Ajustes > Apps > Geo Exponer.", Toast.LENGTH_LONG).show();
        }
    }

    private String stateText(String state) {
        if (ExpoPlaybackService.STATE_PLAYING.equals(state)) return "Escucha…";
        if (ExpoPlaybackService.STATE_PAUSED.equals(state)) return "Pausado";
        if (ExpoPlaybackService.STATE_STOPPED.equals(state)) return "Detenido";
        if (ExpoPlaybackService.STATE_WAITING.equals(state)) {
            return ExpoPlaybackService.MODE_MANUAL.equals(settings.mode())
                    ? "Tu turno · toca ▶, power o auricular para seguir"
                    : "Tu turno · repite la frase";
        }
        if (ExpoPlaybackService.STATE_ERROR.equals(state)) return "Error de voz · revisa el motor de voz del teléfono";
        return "Listo";
    }
}
