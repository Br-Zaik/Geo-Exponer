package com.brian.geoexponer;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Independent memorization mode. It does not reuse or change ExpoPlaybackService,
 * so the normal Manual, Automatic and Mixed modes keep their existing behavior.
 */
public class MemorizeActivity extends Activity {
    public static final String EXTRA_MEMORY_TEXT = "memory_text";

    private static final int REQUEST_RECORD_AUDIO = 201;
    private static final String UTTERANCE_ID = "MEMORY_PHRASE";
    private static final int PASS_SCORE = 78;
    private static final int MAX_WORDS_PER_PHRASE = 12;

    private static final Pattern SLIDE_HEADING = Pattern.compile(
            "(?i)^\\s*diapo(?:sitiva)?\\s*(\\d+)\\s*(?:[.\\-–—:]\\s*)?(.*)$"
    );
    private static final Pattern FINAL_HEADING = Pattern.compile(
            "(?i)^\\s*frase(?:\\s+final)?\\s*[.\\-–—:]?\\s*$"
    );

    private static final class MemorySection {
        final String title;
        final ArrayList<String> phrases = new ArrayList<>();

        MemorySection(String title) {
            this.title = title;
        }
    }

    private static final class PracticePhrase {
        final String sectionTitle;
        final String text;
        final int sectionPhraseIndex;
        final int sectionPhraseTotal;

        PracticePhrase(String sectionTitle, String text, int sectionPhraseIndex, int sectionPhraseTotal) {
            this.sectionTitle = sectionTitle;
            this.text = text;
            this.sectionPhraseIndex = sectionPhraseIndex;
            this.sectionPhraseTotal = sectionPhraseTotal;
        }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<MemorySection> sections = new ArrayList<>();
    private final ArrayList<CheckBox> sectionChecks = new ArrayList<>();
    private final ArrayList<PracticePhrase> phrases = new ArrayList<>();

    private LinearLayout selectionPanel;
    private LinearLayout sectionList;
    private LinearLayout practicePanel;
    private TextView selectionStatus;
    private TextView phraseCounter;
    private TextView phraseText;
    private TextView instructionText;
    private TextView heardText;
    private TextView scoreText;
    private TextView micLevelText;
    private Button selectAllButton;
    private Button clearSelectionButton;
    private Button startSelectedButton;
    private Button actionButton;
    private Button pauseButton;
    private Button listenAgainButton;
    private Button saidItRightButton;
    private Button previousButton;
    private Button nextButton;
    private Button changeSelectionButton;

    private TextToSpeech textToSpeech;
    private SpeechRecognizer speechRecognizer;
    private Intent recognitionIntent;

    private int currentIndex = 0;
    private boolean ttsReady = false;
    private boolean listening = false;
    private boolean sessionFinished = false;
    private boolean pendingStartAfterPermission = false;
    private boolean recognitionExpected = false;
    private boolean practiceStarted = false;
    private boolean paused = false;
    private int roundToken = 0;
    private String activeUtteranceId = null;
    private int evaluatedPhrases = 0;
    private int scoreSum = 0;

    private final Runnable autoNextRunnable = new Runnable() {
        @Override
        public void run() {
            if (!isFinishing() && practiceStarted && !sessionFinished && !paused) {
                moveToPhrase(currentIndex + 1, true);
            }
        }
    };

    private final Runnable pendingListenRunnable = new Runnable() {
        @Override
        public void run() {
            startListening();
        }
    };

    private final Runnable beginRoundRunnable = new Runnable() {
        @Override
        public void run() {
            beginCurrentRound();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memorize);

        selectionPanel = findViewById(R.id.memorySelectionPanel);
        sectionList = findViewById(R.id.memorySectionList);
        practicePanel = findViewById(R.id.memoryPracticePanel);
        selectionStatus = findViewById(R.id.memorySelectionStatus);
        phraseCounter = findViewById(R.id.memoryPhraseCounter);
        phraseText = findViewById(R.id.memoryPhraseText);
        instructionText = findViewById(R.id.memoryInstructionText);
        heardText = findViewById(R.id.memoryHeardText);
        scoreText = findViewById(R.id.memoryScoreText);
        micLevelText = findViewById(R.id.memoryMicLevelText);
        selectAllButton = findViewById(R.id.memorySelectAllButton);
        clearSelectionButton = findViewById(R.id.memoryClearSelectionButton);
        startSelectedButton = findViewById(R.id.memoryStartSelectedButton);
        actionButton = findViewById(R.id.memoryActionButton);
        pauseButton = findViewById(R.id.memoryPauseButton);
        listenAgainButton = findViewById(R.id.memoryListenAgainButton);
        saidItRightButton = findViewById(R.id.memorySaidItRightButton);
        previousButton = findViewById(R.id.memoryPreviousButton);
        nextButton = findViewById(R.id.memoryNextButton);
        changeSelectionButton = findViewById(R.id.memoryChangeSelectionButton);
        Button closeButton = findViewById(R.id.memoryCloseButton);

        String text = getIntent().getStringExtra(EXTRA_MEMORY_TEXT);
        sections.addAll(parseSections(text));
        buildSectionSelection();

        selectAllButton.setOnClickListener(v -> setAllSectionsChecked(true));
        clearSelectionButton.setOnClickListener(v -> setAllSectionsChecked(false));
        startSelectedButton.setOnClickListener(v -> startSelectedPractice());
        changeSelectionButton.setOnClickListener(v -> showSelectionScreen());
        pauseButton.setOnClickListener(v -> togglePause());

        actionButton.setOnClickListener(v -> {
            if (sessionFinished) {
                currentIndex = 0;
                evaluatedPhrases = 0;
                scoreSum = 0;
                sessionFinished = false;
                paused = false;
                prepareCurrentPhrase();
                beginCurrentRound();
            } else {
                beginCurrentRound();
            }
        });
        listenAgainButton.setOnClickListener(v -> beginCurrentRound());
        saidItRightButton.setOnClickListener(v -> moveToPhrase(currentIndex + 1, true));
        previousButton.setOnClickListener(v -> moveToPhrase(currentIndex - 1, false));
        nextButton.setOnClickListener(v -> moveToPhrase(currentIndex + 1, false));
        closeButton.setOnClickListener(v -> {
            cancelVoiceOperations();
            finish();
        });

        initializeTextToSpeech();
        initializeSpeechRecognizer();
    }

    private void buildSectionSelection() {
        sectionList.removeAllViews();
        sectionChecks.clear();

        if (sections.isEmpty()) {
            selectionStatus.setText("No se encontraron frases para practicar.");
            startSelectedButton.setEnabled(false);
            selectAllButton.setEnabled(false);
            clearSelectionButton.setEnabled(false);
            return;
        }

        for (MemorySection section : sections) {
            CheckBox checkBox = new CheckBox(this);
            String countLabel = section.phrases.size() == 1 ? "1 frase" : section.phrases.size() + " frases";
            checkBox.setText(section.title + " — " + countLabel);
            checkBox.setTextColor(getResources().getColor(R.color.text_main));
            checkBox.setTextSize(15f);
            checkBox.setChecked(true);
            checkBox.setPadding(dp(6), dp(6), dp(6), dp(6));
            checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> updateSelectionStatus());

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            sectionList.addView(checkBox, params);
            sectionChecks.add(checkBox);
        }
        updateSelectionStatus();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void setAllSectionsChecked(boolean checked) {
        for (CheckBox checkBox : sectionChecks) {
            checkBox.setChecked(checked);
        }
        updateSelectionStatus();
    }

    private void updateSelectionStatus() {
        int selectedSections = 0;
        int selectedPhrases = 0;
        for (int i = 0; i < sectionChecks.size(); i++) {
            if (sectionChecks.get(i).isChecked()) {
                selectedSections++;
                selectedPhrases += sections.get(i).phrases.size();
            }
        }

        if (selectedSections == 0) {
            selectionStatus.setText("Selecciona al menos una diapositiva.");
            startSelectedButton.setEnabled(false);
        } else {
            String sectionLabel = selectedSections == 1 ? "1 bloque" : selectedSections + " bloques";
            String phraseLabel = selectedPhrases == 1 ? "1 frase" : selectedPhrases + " frases";
            selectionStatus.setText("Seleccionados: " + sectionLabel + " · " + phraseLabel);
            startSelectedButton.setEnabled(true);
        }
    }

    private void startSelectedPractice() {
        cancelVoiceOperations();
        phrases.clear();

        for (int i = 0; i < sectionChecks.size(); i++) {
            if (!sectionChecks.get(i).isChecked()) continue;
            MemorySection section = sections.get(i);
            for (int j = 0; j < section.phrases.size(); j++) {
                phrases.add(new PracticePhrase(
                        section.title,
                        section.phrases.get(j),
                        j + 1,
                        section.phrases.size()
                ));
            }
        }

        if (phrases.isEmpty()) {
            Toast.makeText(this, "Selecciona al menos una diapositiva.", Toast.LENGTH_SHORT).show();
            return;
        }

        currentIndex = 0;
        evaluatedPhrases = 0;
        scoreSum = 0;
        sessionFinished = false;
        practiceStarted = true;
        paused = false;
        pauseButton.setText("PAUSAR");
        selectionPanel.setVisibility(View.GONE);
        practicePanel.setVisibility(View.VISIBLE);
        prepareCurrentPhrase();
    }

    private void showSelectionScreen() {
        cancelVoiceOperations();
        practiceStarted = false;
        sessionFinished = false;
        paused = false;
        phrases.clear();
        practicePanel.setVisibility(View.GONE);
        selectionPanel.setVisibility(View.VISIBLE);
        updateSelectionStatus();
    }

    private void initializeTextToSpeech() {
        textToSpeech = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                ttsReady = false;
                if (practiceStarted) instructionText.setText("No se pudo iniciar la voz del teléfono.");
                return;
            }

            int result = textToSpeech.setLanguage(new Locale("es", "PE"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                result = textToSpeech.setLanguage(new Locale("es", "ES"));
            }
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                ttsReady = false;
                if (practiceStarted) instructionText.setText("El motor de voz no tiene español instalado.");
                return;
            }

            textToSpeech.setSpeechRate(0.92f);
            textToSpeech.setPitch(1.0f);
            textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onStart(String utteranceId) {
                    if (!utteranceId.equals(activeUtteranceId)) return;
                    runOnUiThread(() -> {
                        if (paused || !practiceStarted) return;
                        instructionText.setText("Escucha la frase completa.");
                        actionButton.setEnabled(false);
                        listenAgainButton.setEnabled(false);
                    });
                }

                @Override
                public void onDone(String utteranceId) {
                    if (!utteranceId.equals(activeUtteranceId)) return;
                    runOnUiThread(() -> {
                        if (sessionFinished || isFinishing() || paused || !practiceStarted) return;
                        phraseText.setText("Ahora repítela sin mirar…");
                        instructionText.setText("El micrófono se activará. Habla claro y cerca del teléfono o del auricular.");
                        handler.postDelayed(pendingListenRunnable, 350);
                    });
                }

                @Override
                public void onError(String utteranceId) {
                    if (!utteranceId.equals(activeUtteranceId)) return;
                    runOnUiThread(() -> {
                        if (paused || !practiceStarted) return;
                        instructionText.setText("No se pudo reproducir la frase. Toca Reintentar.");
                        restoreAfterListening();
                    });
                }
            });
            ttsReady = true;
            if (practiceStarted && !paused && !phrases.isEmpty()) {
                actionButton.setEnabled(true);
            }
        });
    }

    private void initializeSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            recognitionIntent = null;
            speechRecognizer = null;
            return;
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                if (!recognitionExpected || paused || !practiceStarted) return;
                listening = true;
                micLevelText.setVisibility(View.VISIBLE);
                micLevelText.setText("Micrófono activo");
                instructionText.setText("Habla ahora. La app esperará a que termines.");
                actionButton.setText("ESCUCHANDO…");
            }

            @Override
            public void onBeginningOfSpeech() {
                if (!recognitionExpected || paused || !practiceStarted) return;
                instructionText.setText("Te estoy escuchando…");
            }

            @Override
            public void onRmsChanged(float rmsdB) {
                if (!recognitionExpected || paused || !practiceStarted) return;
                int bars = Math.max(1, Math.min(8, Math.round((rmsdB + 2f) / 2f)));
                StringBuilder level = new StringBuilder("Voz: ");
                for (int i = 0; i < bars; i++) level.append("▮");
                micLevelText.setText(level.toString());
            }

            @Override
            public void onBufferReceived(byte[] buffer) {
            }

            @Override
            public void onEndOfSpeech() {
                if (!recognitionExpected || paused || !practiceStarted) return;
                listening = false;
                micLevelText.setText("Analizando voz…");
                instructionText.setText("Comparando lo que dijiste con la frase original.");
            }

            @Override
            public void onError(int error) {
                if (!recognitionExpected || paused || !practiceStarted) return;
                recognitionExpected = false;
                listening = false;
                micLevelText.setVisibility(View.GONE);
                String message;
                switch (error) {
                    case SpeechRecognizer.ERROR_NO_MATCH:
                        message = "No entendí una frase completa. Puede haber ruido o hablaste muy lejos.";
                        break;
                    case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                        message = "No detecté tu voz. Acércate al micrófono y vuelve a intentarlo.";
                        break;
                    case SpeechRecognizer.ERROR_AUDIO:
                        message = "Hubo un problema con el micrófono.";
                        break;
                    case SpeechRecognizer.ERROR_NETWORK:
                    case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                        message = "El reconocimiento de voz tuvo un problema de conexión.";
                        break;
                    case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                        message = "Falta el permiso del micrófono.";
                        break;
                    case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                        message = "El reconocedor estaba ocupado. Toca Reintentar.";
                        break;
                    default:
                        message = "No pude reconocer tu voz. Toca Reintentar.";
                        break;
                }
                showRecognitionFailure(message);
            }

            @Override
            public void onResults(Bundle results) {
                if (!recognitionExpected || paused || !practiceStarted) return;
                recognitionExpected = false;
                listening = false;
                micLevelText.setVisibility(View.GONE);
                ArrayList<String> candidates = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                evaluateCandidates(candidates);
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
            }

            @Override
            public void onEvent(int eventType, Bundle params) {
            }
        });

        recognitionIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE");
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE");
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L);
    }

    private void beginCurrentRound() {
        handler.removeCallbacks(autoNextRunnable);
        if (!practiceStarted || paused || phrases.isEmpty() || sessionFinished) return;
        if (!ttsReady) {
            Toast.makeText(this, "La voz todavía se está preparando.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingStartAfterPermission = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
            return;
        }
        if (speechRecognizer == null || recognitionIntent == null) {
            showRecognitionFailure("Este teléfono no tiene reconocimiento de voz disponible.");
            return;
        }

        cancelVoiceOperations();
        clearEvaluation();
        PracticePhrase phrase = phrases.get(currentIndex);
        phraseText.setText(phrase.text);
        instructionText.setText("Escucha. Cuando termine, la frase se ocultará y deberás repetirla.");
        actionButton.setText("PREPARANDO…");
        actionButton.setEnabled(false);
        listenAgainButton.setEnabled(false);
        saidItRightButton.setEnabled(false);

        Bundle params = new Bundle();
        roundToken++;
        activeUtteranceId = UTTERANCE_ID + "_" + roundToken;
        textToSpeech.speak(phrase.text, TextToSpeech.QUEUE_FLUSH, params, activeUtteranceId);
    }

    private void startListening() {
        if (!practiceStarted || paused || sessionFinished || isFinishing() || speechRecognizer == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            showRecognitionFailure("Falta el permiso del micrófono.");
            return;
        }
        try {
            recognitionExpected = true;
            speechRecognizer.startListening(recognitionIntent);
        } catch (Exception error) {
            recognitionExpected = false;
            showRecognitionFailure("No se pudo activar el micrófono. Toca Reintentar.");
        }
    }

    private void evaluateCandidates(ArrayList<String> candidates) {
        if (!practiceStarted || paused || phrases.isEmpty()) return;
        if (candidates == null || candidates.isEmpty()) {
            showRecognitionFailure("No obtuve palabras claras. Toca Reintentar.");
            return;
        }

        String expected = phrases.get(currentIndex).text;
        String bestCandidate = candidates.get(0);
        int bestScore = 0;
        for (String candidate : candidates) {
            int score = similarityScore(expected, candidate);
            if (score > bestScore) {
                bestScore = score;
                bestCandidate = candidate;
            }
        }

        evaluatedPhrases++;
        scoreSum += bestScore;
        heardText.setVisibility(View.VISIBLE);
        heardText.setText("La app entendió:\n“" + bestCandidate + "”");
        scoreText.setVisibility(View.VISIBLE);
        scoreText.setText("Coincidencia: " + bestScore + "%");
        actionButton.setText("REINTENTAR");
        actionButton.setEnabled(true);
        listenAgainButton.setEnabled(true);
        saidItRightButton.setEnabled(true);

        if (bestScore >= PASS_SCORE) {
            phraseText.setText(expected);
            instructionText.setText("Bien. Pasando a la siguiente frase…");
            scoreText.setText("✓ Coincidencia: " + bestScore + "%");
            handler.postDelayed(autoNextRunnable, 1700);
        } else {
            phraseText.setText(expected);
            instructionText.setText("Revisa la frase y vuelve a intentarlo. Si tú la dijiste bien pero el teléfono falló, toca “YO LO DIJE BIEN”.");
        }
    }

    private void showRecognitionFailure(String message) {
        recognitionExpected = false;
        if (!phrases.isEmpty()) phraseText.setText(phrases.get(currentIndex).text);
        instructionText.setText(message);
        heardText.setVisibility(View.VISIBLE);
        heardText.setText("No se pudo evaluar este intento.");
        scoreText.setVisibility(View.GONE);
        restoreAfterListening();
        saidItRightButton.setEnabled(true);
    }

    private void restoreAfterListening() {
        listening = false;
        micLevelText.setVisibility(View.GONE);
        actionButton.setText("REINTENTAR");
        actionButton.setEnabled(!paused);
        listenAgainButton.setEnabled(!paused);
    }

    private void moveToPhrase(int newIndex, boolean fromResult) {
        if (!practiceStarted || paused) return;
        handler.removeCallbacks(autoNextRunnable);
        cancelVoiceOperations();

        if (newIndex >= phrases.size()) {
            finishSession();
            return;
        }
        if (newIndex < 0) newIndex = 0;

        currentIndex = newIndex;
        sessionFinished = false;
        prepareCurrentPhrase();
        if (fromResult) {
            handler.postDelayed(beginRoundRunnable, 350);
        }
    }

    private void prepareCurrentPhrase() {
        if (phrases.isEmpty()) return;
        PracticePhrase phrase = phrases.get(currentIndex);
        clearEvaluation();
        phraseCounter.setText(
                phrase.sectionTitle
                        + "\nFrase " + phrase.sectionPhraseIndex + " de " + phrase.sectionPhraseTotal
                        + "  ·  Total " + (currentIndex + 1) + " de " + phrases.size()
        );
        phraseText.setText(phrase.text);
        instructionText.setText("Toca COMENZAR. Escucharás la frase y luego la repetirás sin verla.");
        actionButton.setText("COMENZAR");
        actionButton.setEnabled(ttsReady && !paused);
        pauseButton.setText(paused ? "REANUDAR" : "PAUSAR");
        pauseButton.setEnabled(true);
        listenAgainButton.setEnabled(!paused);
        saidItRightButton.setEnabled(false);
        previousButton.setEnabled(!paused && currentIndex > 0);
        nextButton.setEnabled(!paused && currentIndex < phrases.size() - 1);
    }

    private void togglePause() {
        if (!practiceStarted || sessionFinished || phrases.isEmpty()) return;

        if (!paused) {
            paused = true;
            cancelVoiceOperations();
            phraseText.setText(phrases.get(currentIndex).text);
            instructionText.setText("Práctica pausada. La frase actual quedó guardada.");
            pauseButton.setText("REANUDAR");
            actionButton.setEnabled(false);
            listenAgainButton.setEnabled(false);
            saidItRightButton.setEnabled(false);
            previousButton.setEnabled(false);
            nextButton.setEnabled(false);
        } else {
            paused = false;
            pauseButton.setText("PAUSAR");
            prepareCurrentPhrase();
            instructionText.setText("Reanudando desde la misma frase…");
            handler.postDelayed(beginRoundRunnable, 300);
        }
    }

    private void finishSession() {
        sessionFinished = true;
        paused = false;
        cancelVoiceOperations();
        phraseCounter.setText("Práctica terminada");
        phraseText.setText("¡Completaste todas las frases seleccionadas!");
        int average = evaluatedPhrases > 0 ? Math.round((float) scoreSum / evaluatedPhrases) : 0;
        instructionText.setText(evaluatedPhrases > 0
                ? "Promedio de coincidencia de los intentos evaluados: " + average + "%"
                : "Puedes volver a practicar desde el inicio.");
        heardText.setVisibility(View.GONE);
        scoreText.setVisibility(View.GONE);
        micLevelText.setVisibility(View.GONE);
        actionButton.setText("PRACTICAR DE NUEVO");
        actionButton.setEnabled(true);
        pauseButton.setText("PAUSAR");
        pauseButton.setEnabled(false);
        listenAgainButton.setEnabled(false);
        saidItRightButton.setEnabled(false);
        previousButton.setEnabled(!phrases.isEmpty());
        nextButton.setEnabled(false);
    }

    private void clearEvaluation() {
        heardText.setText("");
        heardText.setVisibility(View.GONE);
        scoreText.setText("");
        scoreText.setVisibility(View.GONE);
        micLevelText.setVisibility(View.GONE);
    }

    private void cancelVoiceOperations() {
        handler.removeCallbacks(autoNextRunnable);
        handler.removeCallbacks(pendingListenRunnable);
        handler.removeCallbacks(beginRoundRunnable);
        activeUtteranceId = null;
        recognitionExpected = false;
        if (textToSpeech != null) textToSpeech.stop();
        if (speechRecognizer != null) {
            try {
                speechRecognizer.cancel();
            } catch (Exception ignored) {
            }
        }
        listening = false;
        if (micLevelText != null) micLevelText.setVisibility(View.GONE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_RECORD_AUDIO) return;

        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (granted && pendingStartAfterPermission) {
            pendingStartAfterPermission = false;
            if (!paused && practiceStarted) beginCurrentRound();
        } else {
            pendingStartAfterPermission = false;
            if (practiceStarted) {
                instructionText.setText("Sin permiso de micrófono no se puede comprobar lo que repites.");
                saidItRightButton.setEnabled(true);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (listening && speechRecognizer != null) {
            recognitionExpected = false;
            try {
                speechRecognizer.cancel();
            } catch (Exception ignored) {
            }
            listening = false;
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        super.onDestroy();
    }

    private static List<MemorySection> parseSections(String source) {
        ArrayList<MemorySection> parsed = new ArrayList<>();
        if (source == null) return parsed;

        String clean = source.replace("\r\n", "\n").replace('\r', '\n').trim();
        if (clean.isEmpty()) return parsed;

        MemorySection current = null;
        String[] lines = clean.split("\\n");
        for (String rawLine : lines) {
            String line = rawLine.replaceAll("[\\t ]+", " ").trim();
            if (line.isEmpty()) continue;

            Matcher slideMatcher = SLIDE_HEADING.matcher(line);
            if (slideMatcher.matches()) {
                String number = slideMatcher.group(1);
                String subtitle = cleanHeadingSubtitle(slideMatcher.group(2));
                String title = "Diapo " + number + (subtitle.isEmpty() ? "" : " · " + subtitle);
                current = new MemorySection(title);
                parsed.add(current);
                continue;
            }

            if (FINAL_HEADING.matcher(line).matches()) {
                current = new MemorySection("Frase final");
                parsed.add(current);
                continue;
            }

            if (current == null) {
                current = new MemorySection("Todo el texto");
                parsed.add(current);
            }
            current.phrases.addAll(splitContentIntoPhrases(line));
        }

        for (int i = parsed.size() - 1; i >= 0; i--) {
            if (parsed.get(i).phrases.isEmpty()) parsed.remove(i);
        }
        return parsed;
    }

    private static String cleanHeadingSubtitle(String subtitle) {
        if (subtitle == null) return "";
        return subtitle.trim()
                .replaceAll("^[.\\-–—:\\s]+", "")
                .replaceAll("[.\\-–—:\\s]+$", "")
                .trim();
    }

    private static List<String> splitContentIntoPhrases(String source) {
        ArrayList<String> result = new ArrayList<>();
        if (source == null) return result;
        String clean = source.replaceAll("[\\t ]+", " ").trim();
        if (clean.isEmpty()) return result;

        String[] roughParts = clean.split("(?<=[.!?;:])\\s+");
        for (String part : roughParts) {
            String phrase = part.trim();
            if (phrase.isEmpty()) continue;

            String[] words = phrase.split("\\s+");
            if (words.length <= MAX_WORDS_PER_PHRASE) {
                result.add(phrase);
                continue;
            }

            StringBuilder chunk = new StringBuilder();
            int count = 0;
            for (String word : words) {
                if (chunk.length() > 0) chunk.append(' ');
                chunk.append(word);
                count++;
                if (count >= MAX_WORDS_PER_PHRASE) {
                    result.add(chunk.toString().trim());
                    chunk.setLength(0);
                    count = 0;
                }
            }
            if (chunk.length() > 0) result.add(chunk.toString().trim());
        }
        return result;
    }

    private static int similarityScore(String expected, String spoken) {
        String[] expectedWords = normalize(expected).split(" ");
        String[] spokenWords = normalize(spoken).split(" ");
        if (expectedWords.length == 1 && expectedWords[0].isEmpty()) return 0;
        if (spokenWords.length == 1 && spokenWords[0].isEmpty()) return 0;

        int matches = fuzzyLcs(expectedWords, spokenWords);
        int denominator = expectedWords.length + spokenWords.length;
        if (denominator == 0) return 0;
        return Math.max(0, Math.min(100, Math.round((200f * matches) / denominator)));
    }

    private static int fuzzyLcs(String[] first, String[] second) {
        int[][] table = new int[first.length + 1][second.length + 1];
        for (int i = 1; i <= first.length; i++) {
            for (int j = 1; j <= second.length; j++) {
                if (wordsEquivalent(first[i - 1], second[j - 1])) {
                    table[i][j] = table[i - 1][j - 1] + 1;
                } else {
                    table[i][j] = Math.max(table[i - 1][j], table[i][j - 1]);
                }
            }
        }
        return table[first.length][second.length];
    }

    private static boolean wordsEquivalent(String first, String second) {
        if (first.equals(second)) return true;
        if (first.length() < 5 || second.length() < 5) return false;
        if (Math.abs(first.length() - second.length()) > 1) return false;
        return editDistance(first, second) <= 1;
    }

    private static int editDistance(String first, String second) {
        int[] previous = new int[second.length() + 1];
        int[] current = new int[second.length() + 1];
        for (int j = 0; j <= second.length(); j++) previous[j] = j;

        for (int i = 1; i <= first.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= second.length(); j++) {
                int cost = first.charAt(i - 1) == second.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(
                        Math.min(current[j - 1] + 1, previous[j] + 1),
                        previous[j - 1] + cost
                );
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }
        return previous[second.length()];
    }

    private static String normalize(String value) {
        if (value == null) return "";
        String normalized = Normalizer.normalize(value.toLowerCase(new Locale("es", "PE")), Normalizer.Form.NFD);
        normalized = normalized.replaceAll("\\p{M}+", "");
        normalized = normalized.replaceAll("[^a-z0-9ñ]+", " ");
        return normalized.trim().replaceAll("\\s+", " ");
    }
}
