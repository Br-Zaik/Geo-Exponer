# Modo Memorizar con voz

Esta versión mantiene el modo normal de Geo Exponer y añade una pantalla independiente para memorizar.

## Acceso

- El modo normal sigue siendo la pantalla principal.
- El acceso a **Modo Memorizar** está en el engranaje ubicado junto al título **Geo Exponer**.
- Se eliminó el botón grande de memorizar que estaba al final de la pantalla principal.

## Selección por diapositivas

1. Pega todo el texto en la pantalla principal.
2. Usa encabezados como `Diapo 1. Portada.`, `Diapo 2. ¿Qué es el EPP?` o `Frase`.
3. Entra al engranaje.
4. La app organiza automáticamente el contenido por diapositivas.
5. Marca únicamente las diapositivas que quieras practicar.
6. Toca **EMPEZAR CON LO SELECCIONADO**.

Los encabezados `Diapo...`, `Diapositiva...` y `Frase` solo sirven para organizar. No se leen, no se repiten y no se comparan con la voz.

## Práctica

1. La app lee una frase y luego la oculta.
2. Repítela en voz alta.
3. La app muestra lo que entendió y calcula la coincidencia.
4. Con 78 % o más avanza automáticamente.
5. Si el reconocimiento falla aunque la hayas dicho bien, usa **YO LO DIJE BIEN**.
6. **PAUSAR / REANUDAR** conserva la frase actual y continúa desde esa misma frase.
7. **Cambiar diapositivas seleccionadas** permite volver a la lista sin regresar al modo normal.

## Notas

- Requiere permiso de micrófono.
- El reconocimiento usa el servicio de voz disponible en el teléfono; según el dispositivo puede necesitar conexión.
- Para ruido de fondo, se recomienda usar auriculares con micrófono y hablar cerca de él.
- `ExpoPlaybackService.java` y `ButtonIntentReceiver.java` no fueron modificados.
