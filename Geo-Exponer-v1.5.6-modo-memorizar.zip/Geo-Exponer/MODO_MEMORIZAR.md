# Modo Memorizar con voz

Esta versión mantiene el modo normal de Geo Exponer y añade una pantalla independiente para memorizar.

## Flujo

1. Pega el texto en la pantalla principal.
2. Toca **MODO MEMORIZAR CON VOZ**.
3. La app divide el texto en fragmentos de hasta 12 palabras.
4. Toca **COMENZAR**: la app lee la frase y luego la oculta.
5. Repítela en voz alta.
6. La app muestra lo que entendió y calcula la coincidencia.
7. Con 78 % o más avanza automáticamente. Si el reconocimiento falla aunque la hayas dicho bien, usa **YO LO DIJE BIEN**.

## Notas

- Requiere permiso de micrófono.
- El reconocimiento usa el servicio de voz disponible en el teléfono; según el dispositivo puede necesitar conexión.
- Para ruido de fondo, se recomienda usar auriculares con micrófono y hablar cerca de él.
- `ExpoPlaybackService.java` y `ButtonIntentReceiver.java` no fueron modificados.
