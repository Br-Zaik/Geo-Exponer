package com.brian.geoexponer;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Independent memorization mode. It deliberately does not reuse or change
 * ExpoPlaybackService so the original practice modes keep their behavior.
 */
public class MemorizeActivity extends Activity {
    public static final String EXTRA_MEMORY_TEXT = "memory_text";

    private static final int REQUEST_RECORD_AUDIO = 201;
    private static final String UTTERANCE_ID = "MEMORY_PHRASE";
    private static final int PASS_SCORE = 78;
    private static final int MAX_WORDS_PER_PHRASE = 12;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<String> phrases = new ArrayList<>();

    private TextView phraseCounter;
    private TextView phraseText;
    private TextView instructionText;
    private TextView heardText;
    private TextView scoreText;
    private TextView micLevelText;
    private Button actionButton;
    private Button listenAgainButton;
    private Button saidItRightButton;
    private Button previousButton;
    private Button nextButton;

    private TextToSpeech textToSpeech;
    private SpeechRecognizer speechRecognizer;
    private Intent recognitionIntent;

    private int currentIndex = 0;
    private boolean ttsReady = false;
    private boolean listening = false;
    private boolean sessionFinished = false;
    private boolean pendingStartAfterPermission = false;
    private boolean recognitionExpected = false;
    private int roundToken = 0;
    private String activeUtteranceId = null;
    private int evaluatedPhrases = 0;
    private int scoreSum = 0;

    private final Runnable autoNextRunnable = new Runnable() {
        @Override
        public void run() {
            if (!isFinishing() && !sessionFinished) {
                moveToPhrase(currentIndex + 1, true);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memorize);

        phraseCounter = findViewById(R.id.memoryPhraseCounter);
        phraseText = findViewById(R.id.memoryPhraseText);
        instructionText = findViewById(R.id.memoryInstructionText);
        heardText = findViewById(R.id.memoryHeardText);
        scoreText = findViewById(R.id.memoryScoreText);
        micLevelText = findViewById(R.id.memoryMicLevelText);
        actionButton = findViewById(R.id.memoryActionButton);
        listenAgainButton = findViewById(R.id.memoryListenAgainButton);
        saidItRightButton = findViewById(R.id.memorySaidItRightButton);
        previousButton = findViewById(R.id.memoryPreviousButton);
        nextButton = findViewById(R.id.memoryNextButton);
        Button closeButton = findViewById(R.id.memoryCloseButton);

        String text = getIntent().getStringExtra(EXTRA_MEMORY_TEXT);
        phrases.addAll(splitForMemorization(text));

        actionButton.setOnClickListener(v -> {
            if (sessionFinished) {
                currentIndex = 0;
                evaluatedPhrases = 0;
                scoreSum = 0;
                sessionFinished = false;
                prepareCurrentPhrase();
                beginCurrentRound();
            } else {
                beginCurrentRound();
            }
        });
        listenAgainButton.setOnClickListener(v -> beginCurrentRound());
        saidItRightButton.setOnClickListener(v -> moveToPhrase(currentIndex + 1, true));
        previousButton.setOnClickListener(v -> moveToPhrase(currentIndex - 1, false));
        nextButton.setOnClickListener(v -> moveToPhrase(currentIndex + 1, false));
        closeButton.setOnClickListener(v -> finish());

        initializeTextToSpeech();
        initializeSpeechRecognizer();

        if (phrases.isEmpty()) {
            phraseCounter.setText("Sin texto");
            phraseText.setText("No hay contenido para memorizar.");
            instructionText.setText("Regresa, pega tu exposición y vuelve a entrar.");
            setPracticeControlsEnabled(false);
        } else {
            prepareCurrentPhrase();
        }
    }

    private void initializeTextToSpeech() {
        textToSpeech = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                instructionText.setText("No se pudo iniciar la voz del teléfono.");
                return;
            }

            int result = textToSpeech.setLanguage(new Locale("es", "PE"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                result = textToSpeech.setLanguage(new Locale("es", "ES"));
            }
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                instructionText.setText("El motor de voz no tiene español instalado.");
                return;
            }

            textToSpeech.setSpeechRate(0.92f);
            textToSpeech.setPitch(1.0f);
            textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onStart(String utteranceId) {
                    if (!utteranceId.equals(activeUtteranceId)) return;
                    runOnUiThread(() -> {
                        instructionText.setText("Escucha la frase completa.");
                        actionButton.setEnabled(false);
                        listenAgainButton.setEnabled(false);
                    });
                }

                @Override
                public void onDone(String utteranceId) {
                    if (!utteranceId.equals(activeUtteranceId)) return;
                    runOnUiThread(() -> {
                        if (sessionFinished || isFinishing()) return;
                        phraseText.setText("Ahora repítela sin mirar…");
                        instructionText.setText("El micrófono se activará. Habla claro y cerca del teléfono o del auricular.");
                        handler.postDelayed(() -> startListening(), 350);
                    });
                }

                @Override
                public void onError(String utteranceId) {
                    if (!utteranceId.equals(activeUtteranceId)) return;
                    runOnUiThread(() -> {
                        instructionText.setText("No se pudo reproducir la frase. Toca Reintentar.");
                        restoreAfterListening();
                    });
                }
            });
            ttsReady = true;
            actionButton.setEnabled(!phrases.isEmpty());
        });
    }

    private void initializeSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            instructionText.setText("Este teléfono no tiene un servicio de reconocimiento de voz disponible.");
            return;
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                if (!recognitionExpected) return;
                listening = true;
                micLevelText.setVisibility(View.VISIBLE);
                micLevelText.setText("Micrófono activo");
                instructionText.setText("Habla ahora. La app esperará a que termines.");
                actionButton.setText("ESCUCHANDO…");
            }

            @Override
            public void onBeginningOfSpeech() {
                if (!recognitionExpected) return;
                instructionText.setText("Te estoy escuchando…");
            }

            @Override
            public void onRmsChanged(float rmsdB) {
                if (!recognitionExpected) return;
                int bars = Math.max(1, Math.min(8, Math.round((rmsdB + 2f) / 2f)));
                StringBuilder level = new StringBuilder("Voz: ");
                for (int i = 0; i < bars; i++) level.append("▮");
                micLevelText.setText(level.toString());
            }

            @Override
            public void onBufferReceived(byte[] buffer) {
            }

            @Override
            public void onEndOfSpeech() {
                if (!recognitionExpected) return;
                listening = false;
                micLevelText.setText("Analizando voz…");
                instructionText.setText("Comparando lo que dijiste con la frase original.");
            }

            @Override
            public void onError(int error) {
                if (!recognitionExpected) return;
                recognitionExpected = false;
                listening = false;
                micLevelText.setVisibility(View.GONE);
                String message;
                switch (error) {
                    case SpeechRecognizer.ERROR_NO_MATCH:
                        message = "No entendí una frase completa. Puede haber ruido o hablaste muy lejos.";
                        break;
                    case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                        message = "No detecté tu voz. Acércate al micrófono y vuelve a intentarlo.";
                        break;
                    case SpeechRecognizer.ERROR_AUDIO:
                        message = "Hubo un problema con el micrófono.";
                        break;
                    case SpeechRecognizer.ERROR_NETWORK:
                    case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                        message = "El reconocimiento de voz tuvo un problema de conexión.";
                        break;
                    case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                        message = "Falta el permiso del micrófono.";
                        break;
                    case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                        message = "El reconocedor estaba ocupado. Toca Reintentar.";
                        break;
                    default:
                        message = "No pude reconocer tu voz. Toca Reintentar.";
                        break;
                }
                showRecognitionFailure(message);
            }

            @Override
            public void onResults(Bundle results) {
                if (!recognitionExpected) return;
                recognitionExpected = false;
                listening = false;
                micLevelText.setVisibility(View.GONE);
                ArrayList<String> candidates = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                evaluateCandidates(candidates);
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
            }

            @Override
            public void onEvent(int eventType, Bundle params) {
            }
        });

        recognitionIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE");
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE");
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L);
    }

    private void beginCurrentRound() {
        handler.removeCallbacks(autoNextRunnable);
        if (phrases.isEmpty() || sessionFinished) return;
        if (!ttsReady) {
            Toast.makeText(this, "La voz todavía se está preparando.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingStartAfterPermission = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
            return;
        }
        if (speechRecognizer == null || recognitionIntent == null) {
            showRecognitionFailure("Este teléfono no tiene reconocimiento de voz disponible.");
            return;
        }

        cancelVoiceOperations();
        clearEvaluation();
        String phrase = phrases.get(currentIndex);
        phraseText.setText(phrase);
        instructionText.setText("Escucha. Cuando termine, la frase se ocultará y deberás repetirla.");
        actionButton.setText("PREPARANDO…");
        actionButton.setEnabled(false);
        listenAgainButton.setEnabled(false);
        saidItRightButton.setEnabled(false);

        Bundle params = new Bundle();
        roundToken++;
        activeUtteranceId = UTTERANCE_ID + "_" + roundToken;
        textToSpeech.speak(phrase, TextToSpeech.QUEUE_FLUSH, params, activeUtteranceId);
    }

    private void startListening() {
        if (sessionFinished || isFinishing() || speechRecognizer == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            showRecognitionFailure("Falta el permiso del micrófono.");
            return;
        }
        try {
            recognitionExpected = true;
            speechRecognizer.startListening(recognitionIntent);
        } catch (Exception error) {
            showRecognitionFailure("No se pudo activar el micrófono. Toca Reintentar.");
        }
    }

    private void evaluateCandidates(ArrayList<String> candidates) {
        if (candidates == null || candidates.isEmpty()) {
            showRecognitionFailure("No obtuve palabras claras. Toca Reintentar.");
            return;
        }

        String expected = phrases.get(currentIndex);
        String bestCandidate = candidates.get(0);
        int bestScore = 0;
        for (String candidate : candidates) {
            int score = similarityScore(expected, candidate);
            if (score > bestScore) {
                bestScore = score;
                bestCandidate = candidate;
            }
        }

        evaluatedPhrases++;
        scoreSum += bestScore;
        heardText.setVisibility(View.VISIBLE);
        heardText.setText("La app entendió:\n“" + bestCandidate + "”");
        scoreText.setVisibility(View.VISIBLE);
        scoreText.setText("Coincidencia: " + bestScore + "%");
        actionButton.setText("REINTENTAR");
        actionButton.setEnabled(true);
        listenAgainButton.setEnabled(true);
        saidItRightButton.setEnabled(true);

        if (bestScore >= PASS_SCORE) {
            phraseText.setText(expected);
            instructionText.setText("Bien. Pasando a la siguiente frase…");
            scoreText.setText("✓ Coincidencia: " + bestScore + "%");
            handler.postDelayed(autoNextRunnable, 1700);
        } else {
            phraseText.setText(expected);
            instructionText.setText("Revisa la frase y vuelve a intentarlo. Si tú la dijiste bien pero el teléfono falló, toca “YO LO DIJE BIEN”.");
        }
    }

    private void showRecognitionFailure(String message) {
        recognitionExpected = false;
        phraseText.setText(phrases.isEmpty() ? "" : phrases.get(currentIndex));
        instructionText.setText(message);
        heardText.setVisibility(View.VISIBLE);
        heardText.setText("No se pudo evaluar este intento.");
        scoreText.setVisibility(View.GONE);
        restoreAfterListening();
        saidItRightButton.setEnabled(true);
    }

    private void restoreAfterListening() {
        listening = false;
        micLevelText.setVisibility(View.GONE);
        actionButton.setText("REINTENTAR");
        actionButton.setEnabled(true);
        listenAgainButton.setEnabled(true);
    }

    private void moveToPhrase(int newIndex, boolean fromResult) {
        handler.removeCallbacks(autoNextRunnable);
        cancelVoiceOperations();

        if (newIndex >= phrases.size()) {
            finishSession();
            return;
        }
        if (newIndex < 0) newIndex = 0;

        currentIndex = newIndex;
        sessionFinished = false;
        prepareCurrentPhrase();
        if (fromResult) {
            handler.postDelayed(this::beginCurrentRound, 350);
        }
    }

    private void prepareCurrentPhrase() {
        if (phrases.isEmpty()) return;
        clearEvaluation();
        phraseCounter.setText("Frase " + (currentIndex + 1) + " de " + phrases.size());
        phraseText.setText(phrases.get(currentIndex));
        instructionText.setText("Toca COMENZAR. Escucharás la frase y luego la repetirás sin verla.");
        actionButton.setText("COMENZAR");
        actionButton.setEnabled(ttsReady);
        listenAgainButton.setEnabled(true);
        saidItRightButton.setEnabled(false);
        previousButton.setEnabled(currentIndex > 0);
        nextButton.setEnabled(currentIndex < phrases.size() - 1);
    }

    private void finishSession() {
        sessionFinished = true;
        cancelVoiceOperations();
        phraseCounter.setText("Práctica terminada");
        phraseText.setText("¡Completaste todas las frases!");
        int average = evaluatedPhrases > 0 ? Math.round((float) scoreSum / evaluatedPhrases) : 0;
        instructionText.setText(evaluatedPhrases > 0
                ? "Promedio de coincidencia de los intentos evaluados: " + average + "%"
                : "Puedes volver a practicar desde el inicio.");
        heardText.setVisibility(View.GONE);
        scoreText.setVisibility(View.GONE);
        micLevelText.setVisibility(View.GONE);
        actionButton.setText("PRACTICAR DE NUEVO");
        actionButton.setEnabled(true);
        listenAgainButton.setEnabled(false);
        saidItRightButton.setEnabled(false);
        previousButton.setEnabled(!phrases.isEmpty());
        nextButton.setEnabled(false);
    }

    private void clearEvaluation() {
        heardText.setText("");
        heardText.setVisibility(View.GONE);
        scoreText.setText("");
        scoreText.setVisibility(View.GONE);
        micLevelText.setVisibility(View.GONE);
    }

    private void setPracticeControlsEnabled(boolean enabled) {
        actionButton.setEnabled(enabled);
        listenAgainButton.setEnabled(enabled);
        saidItRightButton.setEnabled(enabled);
        previousButton.setEnabled(enabled);
        nextButton.setEnabled(enabled);
    }

    private void cancelVoiceOperations() {
        handler.removeCallbacks(autoNextRunnable);
        activeUtteranceId = null;
        recognitionExpected = false;
        if (textToSpeech != null) textToSpeech.stop();
        if (speechRecognizer != null) {
            try {
                speechRecognizer.cancel();
            } catch (Exception ignored) {
            }
        }
        listening = false;
        if (micLevelText != null) micLevelText.setVisibility(View.GONE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_RECORD_AUDIO) return;

        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (granted && pendingStartAfterPermission) {
            pendingStartAfterPermission = false;
            beginCurrentRound();
        } else {
            pendingStartAfterPermission = false;
            instructionText.setText("Sin permiso de micrófono no se puede comprobar lo que repites.");
            saidItRightButton.setEnabled(true);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (listening && speechRecognizer != null) {
            recognitionExpected = false;
            try {
                speechRecognizer.cancel();
            } catch (Exception ignored) {
            }
            listening = false;
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        super.onDestroy();
    }

    private static List<String> splitForMemorization(String source) {
        ArrayList<String> result = new ArrayList<>();
        if (source == null) return result;

        String clean = source.replace('\r', '\n')
                .replaceAll("[\\t ]+", " ")
                .replaceAll("\\n{2,}", "\n")
                .trim();
        if (clean.isEmpty()) return result;

        String[] roughParts = clean.split("(?<=[.!?;:])\\s+|\\n+");
        for (String part : roughParts) {
            String phrase = part.trim();
            if (phrase.isEmpty()) continue;

            String[] words = phrase.split("\\s+");
            if (words.length <= MAX_WORDS_PER_PHRASE) {
                result.add(phrase);
                continue;
            }

            StringBuilder chunk = new StringBuilder();
            int count = 0;
            for (String word : words) {
                if (chunk.length() > 0) chunk.append(' ');
                chunk.append(word);
                count++;
                if (count >= MAX_WORDS_PER_PHRASE) {
                    result.add(chunk.toString().trim());
                    chunk.setLength(0);
                    count = 0;
                }
            }
            if (chunk.length() > 0) result.add(chunk.toString().trim());
        }
        return result;
    }

    private static int similarityScore(String expected, String spoken) {
        String[] expectedWords = normalize(expected).split(" ");
        String[] spokenWords = normalize(spoken).split(" ");
        if (expectedWords.length == 1 && expectedWords[0].isEmpty()) return 0;
        if (spokenWords.length == 1 && spokenWords[0].isEmpty()) return 0;

        int matches = fuzzyLcs(expectedWords, spokenWords);
        int denominator = expectedWords.length + spokenWords.length;
        if (denominator == 0) return 0;
        return Math.max(0, Math.min(100, Math.round((200f * matches) / denominator)));
    }

    private static int fuzzyLcs(String[] first, String[] second) {
        int[][] table = new int[first.length + 1][second.length + 1];
        for (int i = 1; i <= first.length; i++) {
            for (int j = 1; j <= second.length; j++) {
                if (wordsEquivalent(first[i - 1], second[j - 1])) {
                    table[i][j] = table[i - 1][j - 1] + 1;
                } else {
                    table[i][j] = Math.max(table[i - 1][j], table[i][j - 1]);
                }
            }
        }
        return table[first.length][second.length];
    }

    private static boolean wordsEquivalent(String first, String second) {
        if (first.equals(second)) return true;
        if (first.length() < 5 || second.length() < 5) return false;
        if (Math.abs(first.length() - second.length()) > 1) return false;
        return editDistance(first, second) <= 1;
    }

    private static int editDistance(String first, String second) {
        int[] previous = new int[second.length() + 1];
        int[] current = new int[second.length() + 1];
        for (int j = 0; j <= second.length(); j++) previous[j] = j;

        for (int i = 1; i <= first.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= second.length(); j++) {
                int cost = first.charAt(i - 1) == second.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(
                        Math.min(current[j - 1] + 1, previous[j] + 1),
                        previous[j - 1] + cost
                );
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }
        return previous[second.length()];
    }

    private static String normalize(String value) {
        if (value == null) return "";
        String normalized = Normalizer.normalize(value.toLowerCase(new Locale("es", "PE")), Normalizer.Form.NFD);
        normalized = normalized.replaceAll("\\p{M}+", "");
        normalized = normalized.replaceAll("[^a-z0-9ñ]+", " ");
        return normalized.trim().replaceAll("\\s+", " ");
    }
}
