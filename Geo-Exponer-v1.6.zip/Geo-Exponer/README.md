# Geo Exponer v1.6

APK simple para practicar exposiciones como reproductor de frases.

Cambios v1.6:
- Respuesta más rápida al clic del botón power cuando la pantalla está bloqueada.
- Se agregó WakeLock para mantener la CPU despierta durante la práctica y evitar demora al continuar.
- Modo Manual: lee una frase, espera tu repetición y continúa con botón power, asistente o auricular.
- Mantiene audio por auriculares Bluetooth si están conectados.
- Sin IA, sin API, sin Gemini y sin internet obligatorio.

Uso recomendado:
1. Pega tu exposición.
2. Marca Modo Manual.
3. Toca Iniciar práctica.
4. Apaga la pantalla.
5. Escucha una frase, repítela y da clic al botón power/asistente para continuar.
