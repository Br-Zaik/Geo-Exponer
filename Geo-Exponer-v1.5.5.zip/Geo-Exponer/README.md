# Geo Exponer v1.5.5

APK para practicar exposiciones con Text To Speech de Android, sin IA, sin API, sin login y sin internet obligatorio.

## Cambios v1.5.5

- Mantiene el control con botón de encendido/apagado en modo Manual y Mixto.
- En modo Mixto, con pantalla encendida, Volumen + y Volumen - cambian el volumen normal y también pausan/reanudan.
- En modo Mixto con 0s, la lectura avanza de corrido sin pausa programada entre frases.
- Se reduce el riesgo de pausas falsas ignorando eventos de pantalla durante el pequeño intervalo entre frases.
- Mantiene cuadro de texto editable, botones anterior/siguiente, repetir, detener, servicio en segundo plano, WAKE_LOCK y notificación tipo reproductor.

## Uso recomendado

Para automático + control manual: selecciona Mixto, elige 0s o 1s, inicia la práctica y controla con power o con volumen si la pantalla está encendida.
