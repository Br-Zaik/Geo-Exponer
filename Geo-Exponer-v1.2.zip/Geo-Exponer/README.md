# Geo Exponer v1.2

APK sencilla para practicar exposiciones como reproductor de audio.

## Funciones

- Sin IA, sin API, sin Gemini y sin internet obligatorio.
- Pegar texto largo y guardarlo automáticamente.
- Lectura con Text To Speech de Android.
- Audio por auriculares Bluetooth si están conectados.
- Velocidades: 0.25x, 0.50x, 0.75x, 1x, 1.25x y 1.50x.
- Pausa para repetir: 3s, 5s, 8s y 10s.
- Repetir frase, siguiente frase, pausar/reanudar y detener.
- Servicio en primer plano con notificación tipo reproductor.
- Permiso de batería/segundo plano para reducir cierres con pantalla bloqueada.
- Pantalla apagada = pausa. Pantalla encendida/bloqueada = reanuda.
- Botón multimedia de auricular Bluetooth: pausa/reanuda.
- Se agregó intento de captura para botón de asistente/voz del auricular o celular cuando Android lo entregue a la app.

## Importante

El botón de asistente depende del celular y del auricular. Algunos modelos lo entregan como comando multimedia o voz y Geo Exponer lo puede usar. Otros lo reservan para Google Assistant y Android no permite capturarlo al 100%.
