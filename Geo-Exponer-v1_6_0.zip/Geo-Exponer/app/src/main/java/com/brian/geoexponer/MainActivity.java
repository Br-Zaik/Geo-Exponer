package com.brian.geoexponer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.Html;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String KEY_BATTERY_PROMPT_SHOWN = "battery_prompt_shown";
    private static final int TAB_EXPONER = 0;
    private static final int TAB_TEXTOS = 1;

    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    private ScriptStore store;
    private ExpoSettings settings;
    private String currentScriptId = "";
    private boolean bindingText = false;
    private boolean syncingUi = false;

    private TextView scriptTitle;
    private View exponerPanel;
    private View textosPanel;
    private TextView navExponer;
    private TextView navTextos;
    private TextView navMemorizar;

    private TextView progressText;
    private TextView timerText;
    private ProgressBar progressBar;
    private TextView slideTitleText;
    private TextView currentPhrase;
    private TextView nextPhrase;
    private TextView statusText;
    private TextView chipMode;
    private TextView chipSpeed;
    private TextView chipPause;
    private ImageButton playButton;

    private EditText inputText;
    private TextView scriptInfo;

    private View settingsOverlay;
    private RadioButton modeManual;
    private RadioButton modeAuto;
    private RadioButton modeMixed;
    private TextView modeHelp;
    private TextView speedLabel;
    private SeekBar speedSeek;
    private TextView pauseLabel;
    private SeekBar pauseSeek;
    private View smartBox;
    private TextView smartLabel;
    private SeekBar smartSeek;
    private TextView targetLabel;
    private SeekBar targetSeek;
    private Switch switchCueTone;
    private Switch switchCueVoice;
    private Switch switchVibrate;
    private Switch switchHintRead;
    private Switch switchMultiTap;

    private View pocketOverlay;
    private float savedBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;

    private String lastState = ExpoPlaybackService.STATE_STOPPED;
    private int lastTotal = 0;
    private int currentTab = TAB_EXPONER;

    private final Runnable saveTextRunnable = new Runnable() {
        @Override
        public void run() {
            if (store != null && inputText != null) {
                store.updateText(currentScriptId, inputText.getText().toString());
                updateScriptInfo();
            }
        }
    };

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            if (ExpoPlaybackService.ACTION_TICK.equals(intent.getAction())) {
                updateTimer(intent.getLongExtra(ExpoPlaybackService.EXTRA_ELAPSED_MS, 0L),
                        intent.getLongExtra(ExpoPlaybackService.EXTRA_TARGET_MS, 0L));
                return;
            }
            if (!ExpoPlaybackService.ACTION_STATUS.equals(intent.getAction())) return;
            applyStatus(intent);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        store = new ScriptStore(this);
        settings = new ExpoSettings(this);

        bindViews();
        setupTabs();
        setupExponerControls();
        setupTextos();
        setupSettingsSheet();
        setupPocketMode();

        loadScript(store.current().id);
        showTab(TAB_EXPONER);
        refreshChips();

        requestNotificationPermissionIfNeeded();
        requestBatteryPermissionIfNeeded(false);

        if (savedInstanceState == null) {
            handleIncomingIntent(getIntent());
        }
        updatePlayButton();
    }

    private void bindViews() {
        scriptTitle = findViewById(R.id.scriptTitle);
        exponerPanel = findViewById(R.id.exponerPanel);
        textosPanel = findViewById(R.id.textosPanel);
        navExponer = findViewById(R.id.navExponer);
        navTextos = findViewById(R.id.navTextos);
        navMemorizar = findViewById(R.id.navMemorizar);

        progressText = findViewById(R.id.progressText);
        timerText = findViewById(R.id.timerText);
        progressBar = findViewById(R.id.progressBar);
        slideTitleText = findViewById(R.id.slideTitleText);
        currentPhrase = findViewById(R.id.currentPhrase);
        nextPhrase = findViewById(R.id.nextPhrase);
        statusText = findViewById(R.id.statusText);
        chipMode = findViewById(R.id.chipMode);
        chipSpeed = findViewById(R.id.chipSpeed);
        chipPause = findViewById(R.id.chipPause);
        playButton = findViewById(R.id.playButton);

        inputText = findViewById(R.id.inputText);
        scriptInfo = findViewById(R.id.scriptInfo);

        settingsOverlay = findViewById(R.id.settingsOverlay);
        modeManual = findViewById(R.id.modeManual);
        modeAuto = findViewById(R.id.modeAuto);
        modeMixed = findViewById(R.id.modeMixed);
        modeHelp = findViewById(R.id.modeHelp);
        speedLabel = findViewById(R.id.speedLabel);
        speedSeek = findViewById(R.id.speedSeek);
        pauseLabel = findViewById(R.id.pauseLabel);
        pauseSeek = findViewById(R.id.pauseSeek);
        smartBox = findViewById(R.id.smartBox);
        smartLabel = findViewById(R.id.smartLabel);
        smartSeek = findViewById(R.id.smartSeek);
        targetLabel = findViewById(R.id.targetLabel);
        targetSeek = findViewById(R.id.targetSeek);
        switchCueTone = findViewById(R.id.switchCueTone);
        switchCueVoice = findViewById(R.id.switchCueVoice);
        switchVibrate = findViewById(R.id.switchVibrate);
        switchHintRead = findViewById(R.id.switchHintRead);
        switchMultiTap = findViewById(R.id.switchMultiTap);

        pocketOverlay = findViewById(R.id.pocketOverlay);
    }

    // ---------------------------------------------------------------- Pestañas

    private void setupTabs() {
        navExponer.setOnClickListener(v -> showTab(TAB_EXPONER));
        navTextos.setOnClickListener(v -> showTab(TAB_TEXTOS));
        navMemorizar.setOnClickListener(v -> openMemorizeMode());
        findViewById(R.id.titleBox).setOnClickListener(v -> showScriptPicker());
        findViewById(R.id.settingsButton).setOnClickListener(v -> openSettings());
    }

    private void showTab(int tab) {
        currentTab = tab;
        exponerPanel.setVisibility(tab == TAB_EXPONER ? View.VISIBLE : View.GONE);
        textosPanel.setVisibility(tab == TAB_TEXTOS ? View.VISIBLE : View.GONE);
        navExponer.setSelected(tab == TAB_EXPONER);
        navTextos.setSelected(tab == TAB_TEXTOS);
        navMemorizar.setSelected(false);
        if (tab != TAB_TEXTOS) {
            flushTextSave();
            hideKeyboard();
        } else {
            updateScriptInfo();
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && inputText != null) imm.hideSoftInputFromWindow(inputText.getWindowToken(), 0);
            if (inputText != null) inputText.clearFocus();
        } catch (Exception ignored) {
        }
    }

    // ---------------------------------------------------------------- Exponer

    private void setupExponerControls() {
        playButton.setOnClickListener(v -> mainButtonAction());
        findViewById(R.id.previousButton).setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_PREVIOUS));
        findViewById(R.id.nextButton).setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_NEXT));
        findViewById(R.id.previousButton).setOnLongClickListener(v -> {
            sendSimpleAction(ExpoPlaybackService.ACTION_PREVIOUS_SLIDE);
            Toast.makeText(this, "Diapositiva anterior", Toast.LENGTH_SHORT).show();
            return true;
        });
        findViewById(R.id.nextButton).setOnLongClickListener(v -> {
            sendSimpleAction(ExpoPlaybackService.ACTION_NEXT_SLIDE);
            Toast.makeText(this, "Siguiente diapositiva", Toast.LENGTH_SHORT).show();
            return true;
        });
        findViewById(R.id.repeatButton).setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_REPEAT));
        findViewById(R.id.stopButton).setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_STOP));
        chipMode.setOnClickListener(v -> openSettings());
        chipSpeed.setOnClickListener(v -> openSettings());
        chipPause.setOnClickListener(v -> openSettings());
    }

    private void applyStatus(Intent intent) {
        String state = intent.getStringExtra(ExpoPlaybackService.EXTRA_STATE);
        int index = intent.getIntExtra(ExpoPlaybackService.EXTRA_INDEX, 0);
        int total = intent.getIntExtra(ExpoPlaybackService.EXTRA_TOTAL, 0);
        String phrase = intent.getStringExtra(ExpoPlaybackService.EXTRA_PHRASE);
        String next = intent.getStringExtra(ExpoPlaybackService.EXTRA_NEXT_PHRASE);
        String slideTitle = intent.getStringExtra(ExpoPlaybackService.EXTRA_SLIDE_TITLE);
        int slideIndex = intent.getIntExtra(ExpoPlaybackService.EXTRA_SLIDE_INDEX, 0);
        int slideCount = intent.getIntExtra(ExpoPlaybackService.EXTRA_SLIDE_COUNT, 0);
        int inSlide = intent.getIntExtra(ExpoPlaybackService.EXTRA_PHRASE_IN_SLIDE, 0);
        int ofSlide = intent.getIntExtra(ExpoPlaybackService.EXTRA_PHRASES_IN_SLIDE, 0);

        lastState = state != null ? state : ExpoPlaybackService.STATE_STOPPED;
        lastTotal = total;

        if (phrase != null && phrase.trim().length() > 0) {
            currentPhrase.setText(html(phrase));
            nextPhrase.setText(next != null && next.trim().length() > 0
                    ? html("Sigue: " + next)
                    : (total > 0 && index >= total ? "Última frase" : ""));
            slideTitleText.setText(slideTitle != null ? slideTitle : "");
        }

        if (total > 0) {
            if (slideCount > 1) {
                progressText.setText("Diapo " + slideIndex + "/" + slideCount + "  ·  Frase " + inSlide + "/" + ofSlide);
            } else {
                progressText.setText("Frase " + index + " / " + total);
            }
            progressBar.setProgress(Math.round(1000f * index / total));
        } else {
            progressText.setText("Listo");
            progressBar.setProgress(0);
        }

        updateTimer(intent.getLongExtra(ExpoPlaybackService.EXTRA_ELAPSED_MS, 0L),
                intent.getLongExtra(ExpoPlaybackService.EXTRA_TARGET_MS, 0L));
        statusText.setText(stateText(lastState));
        if (ExpoPlaybackService.STATE_STOPPED.equals(lastState) && pocketOverlay.getVisibility() == View.VISIBLE) {
            exitPocketMode();
        }
        updatePlayButton();
    }

    private CharSequence html(String raw) {
        String h = TextParser.toHtml(raw);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return Html.fromHtml(h, Html.FROM_HTML_MODE_LEGACY);
        }
        //noinspection deprecation
        return Html.fromHtml(h);
    }

    private void updateTimer(long elapsedMs, long targetMs) {
        String text = formatTime(elapsedMs);
        if (targetMs > 0) text = text + " / " + formatTime(targetMs);
        timerText.setText(text);
        if (targetMs > 0 && elapsedMs > targetMs) {
            timerText.setTextColor(getResources().getColor(R.color.warn_red));
        } else if (targetMs > 0 && elapsedMs > targetMs - 60_000L) {
            timerText.setTextColor(0xFFFFC857);
        } else {
            timerText.setTextColor(getResources().getColor(R.color.text_soft));
        }
    }

    private static String formatTime(long ms) {
        long totalSec = Math.max(0L, ms / 1000L);
        return String.format(Locale.US, "%02d:%02d", totalSec / 60, totalSec % 60);
    }

    private boolean practiceRunning() {
        return lastTotal > 0
                && !ExpoPlaybackService.STATE_STOPPED.equals(lastState)
                && !ExpoPlaybackService.STATE_ERROR.equals(lastState);
    }

    private void mainButtonAction() {
        if (practiceRunning()) {
            sendSimpleAction(ExpoPlaybackService.ACTION_TOGGLE);
        } else {
            startPractice();
        }
    }

    private void updatePlayButton() {
        if (playButton == null) return;
        boolean showPause;
        String description;
        if (!practiceRunning()) {
            showPause = false;
            description = "Iniciar";
        } else if (ExpoPlaybackService.STATE_WAITING.equals(lastState)) {
            boolean manual = ExpoPlaybackService.MODE_MANUAL.equals(settings.mode());
            showPause = !manual;
            description = manual ? "Continuar" : "Pausar";
        } else if (ExpoPlaybackService.STATE_PAUSED.equals(lastState)) {
            showPause = false;
            description = "Reanudar";
        } else {
            showPause = true;
            description = "Pausar";
        }
        playButton.setImageResource(showPause ? R.drawable.ic_pause : R.drawable.ic_play);
        playButton.setContentDescription(description);
    }

    private void startPractice() {
        flushTextSave();
        String text = inputText.getText().toString().trim();
        if (TextParser.parseItems(text).isEmpty()) {
            Toast.makeText(this, "Primero pega tu texto en la pestaña Textos.", Toast.LENGTH_SHORT).show();
            showTab(TAB_TEXTOS);
            return;
        }

        currentPhrase.setText("Preparando lectura...");
        nextPhrase.setText("");
        statusText.setText("Iniciando...");
        lastState = ExpoPlaybackService.STATE_PLAYING;
        lastTotal = 1;
        updatePlayButton();

        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(ExpoPlaybackService.ACTION_START);
        intent.putExtra(ExpoPlaybackService.EXTRA_TEXT, text);
        intent.putExtra(ExpoPlaybackService.EXTRA_SCRIPT_ID, currentScriptId);
        putSettingsExtras(intent);
        startServiceCompat(intent);
    }

    private void putSettingsExtras(Intent intent) {
        String mode = settings.mode();
        intent.putExtra(ExpoPlaybackService.EXTRA_MODE, mode);
        intent.putExtra(ExpoPlaybackService.EXTRA_SPEED, settings.speed());
        intent.putExtra(ExpoPlaybackService.EXTRA_PAUSE_MS,
                ExpoPlaybackService.MODE_MANUAL.equals(mode) ? -1 : settings.pauseMs());
        intent.putExtra(ExpoPlaybackService.EXTRA_SMART_FACTOR, settings.smartFactor());
        intent.putExtra(ExpoPlaybackService.EXTRA_CUE_TONE, settings.cueTone());
        intent.putExtra(ExpoPlaybackService.EXTRA_CUE_VOICE, settings.cueVoice());
        intent.putExtra(ExpoPlaybackService.EXTRA_VIBRATE, settings.vibrate());
        intent.putExtra(ExpoPlaybackService.EXTRA_TARGET_MIN, settings.targetMinutes());
        intent.putExtra(ExpoPlaybackService.EXTRA_HINT_READ, settings.hintRead());
        intent.putExtra(ExpoPlaybackService.EXTRA_MULTI_TAP, settings.multiTap());
    }

    private void sendSettingsUpdateIfRunning() {
        if (!practiceRunning()) return;
        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(ExpoPlaybackService.ACTION_UPDATE_SETTINGS);
        putSettingsExtras(intent);
        startServiceCompat(intent);
    }

    private void sendSimpleAction(String action) {
        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(action);
        startServiceCompat(intent);
    }

    private void startServiceCompat(Intent intent) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo iniciar el servicio de voz.", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------- Botones físicos

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int keyCode = event.getKeyCode();
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
                && event.getAction() == KeyEvent.ACTION_DOWN
                && event.getRepeatCount() == 0) {
            if (practiceRunning()) {
                if (PhysicalControlSettings.isConfigured(this)) {
                    int physicalMode = PhysicalControlSettings.getMode(this);
                    if (PhysicalControlSettings.usesVolume(physicalMode)) {
                        sendSimpleAction(ExpoPlaybackService.ACTION_PHYSICAL_TOGGLE);
                    }
                    // Modo bolsillo: el servicio recibe el volumen directamente.
                } else if (ExpoPlaybackService.MODE_MIXED.equals(settings.mode())) {
                    // Comportamiento original hasta que el usuario configure la opción.
                    sendSimpleAction(ExpoPlaybackService.ACTION_TOGGLE);
                }
            }
            return super.dispatchKeyEvent(event);
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_ASSIST
                || keyCode == KeyEvent.KEYCODE_VOICE_ASSIST
                || keyCode == KeyEvent.KEYCODE_HEADSETHOOK
                || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            sendSimpleAction(ExpoPlaybackService.ACTION_ASSIST_TOGGLE);
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        if (settingsOverlay.getVisibility() == View.VISIBLE) {
            closeSettings();
            return;
        }
        if (pocketOverlay.getVisibility() == View.VISIBLE) {
            Toast.makeText(this, "Mantén presionada la pantalla para salir del modo bolsillo.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (currentTab != TAB_EXPONER) {
            showTab(TAB_EXPONER);
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_VOICE_COMMAND.equals(action)) {
            sendSimpleAction(ExpoPlaybackService.ACTION_ASSIST_TOGGLE);
            return;
        }
        if (Intent.ACTION_SEND.equals(action)) {
            String shared = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (shared != null && shared.trim().length() > 0) {
                String subject = intent.getStringExtra(Intent.EXTRA_SUBJECT);
                ScriptStore.Script s = store.create(subject != null ? subject : null, shared.trim());
                loadScript(s.id);
                showTab(TAB_TEXTOS);
                Toast.makeText(this, "Texto recibido como nueva exposición.", Toast.LENGTH_SHORT).show();
            }
            // Evitar que se vuelva a importar al girar la pantalla.
            intent.setAction(Intent.ACTION_MAIN);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter();
        filter.addAction(ExpoPlaybackService.ACTION_STATUS);
        filter.addAction(ExpoPlaybackService.ACTION_TICK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(statusReceiver, filter);
        }
        sendSimpleAction(ExpoPlaybackService.ACTION_STATUS_REQUEST);
    }

    @Override
    protected void onResume() {
        super.onResume();
        navMemorizar.setSelected(false);
        if (currentTab == TAB_TEXTOS) updateScriptInfo();
    }

    @Override
    protected void onPause() {
        flushTextSave();
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            unregisterReceiver(statusReceiver);
        } catch (IllegalArgumentException ignored) {
        }
    }

    // ---------------------------------------------------------------- Textos

    private void setupTextos() {
        inputText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (bindingText) return;
                uiHandler.removeCallbacks(saveTextRunnable);
                uiHandler.postDelayed(saveTextRunnable, 500L);
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        findViewById(R.id.newScriptButton).setOnClickListener(v -> askNewScript());
        findViewById(R.id.pasteButton).setOnClickListener(v -> pasteFromClipboard());
        findViewById(R.id.scriptMenuButton).setOnClickListener(v -> showScriptMenu());
    }

    private void flushTextSave() {
        uiHandler.removeCallbacks(saveTextRunnable);
        if (store != null && inputText != null && !currentScriptId.isEmpty()) {
            store.updateText(currentScriptId, inputText.getText().toString());
        }
    }

    private void loadScript(String id) {
        flushTextSave();
        ScriptStore.Script s = store.find(id);
        if (s == null) s = store.current();
        store.select(s.id);
        currentScriptId = s.id;
        bindingText = true;
        inputText.setText(s.text);
        bindingText = false;
        scriptTitle.setText(s.name + " ▾");
        updateScriptInfo();
    }

    private void updateScriptInfo() {
        if (scriptInfo == null) return;
        String text = inputText.getText().toString();
        List<TextParser.Section> sections = TextParser.parseSections(text);
        int phrases = 0;
        int words = 0;
        for (TextParser.Section s : sections) {
            phrases += s.phrases.size();
            for (String p : s.phrases) words += TextParser.wordCount(p);
        }
        if (phrases == 0) {
            scriptInfo.setText("Sin texto todavía");
            return;
        }
        int minutes = Math.max(1, Math.round(words / 130f));
        StringBuilder info = new StringBuilder();
        info.append(sections.size()).append(sections.size() == 1 ? " diapositiva" : " diapositivas");
        info.append(" · ").append(phrases).append(" frases");
        info.append(" · ~").append(minutes).append(" min");
        int rehearsals = store.rehearsals(currentScriptId);
        if (rehearsals > 0) {
            info.append(" · Ensayos: ").append(rehearsals)
                    .append(" (último ").append(formatTime(store.lastDurationMs(currentScriptId))).append(")");
        }
        scriptInfo.setText(info.toString());
    }

    private void confirmStopIfRunning(Runnable then) {
        if (!practiceRunning()) {
            then.run();
            return;
        }
        sendSimpleAction(ExpoPlaybackService.ACTION_STOP);
        then.run();
    }

    private void showScriptPicker() {
        flushTextSave();
        final List<ScriptStore.Script> all = store.all();
        String[] names = new String[all.size() + 1];
        int checked = 0;
        for (int i = 0; i < all.size(); i++) {
            names[i] = all.get(i).name;
            if (all.get(i).id.equals(currentScriptId)) checked = i;
        }
        names[all.size()] = "+ Nueva exposición";
        new AlertDialog.Builder(this)
                .setTitle("Mis exposiciones")
                .setSingleChoiceItems(names, checked, (dialog, which) -> {
                    dialog.dismiss();
                    if (which == all.size()) {
                        askNewScript();
                    } else if (!all.get(which).id.equals(currentScriptId)) {
                        confirmStopIfRunning(() -> loadScript(all.get(which).id));
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void askNewScript() {
        final EditText name = new EditText(this);
        name.setHint("Nombre (ej. Charla SST)");
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        name.setSingleLine(true);
        LinearLayout box = new LinearLayout(this);
        int pad = Math.round(20 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(name, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle("Nueva exposición")
                .setView(box)
                .setPositiveButton("Crear", (d, w) -> confirmStopIfRunning(() -> {
                    flushTextSave();
                    ScriptStore.Script s = store.create(name.getText().toString(), "");
                    loadScript(s.id);
                    showTab(TAB_TEXTOS);
                }))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showScriptMenu() {
        String[] options = {"Cambiar de exposición", "Renombrar", "Copiar todo el texto", "Eliminar esta exposición"};
        new AlertDialog.Builder(this)
                .setItems(options, (dialog, which) -> {
                    if (which == 0) showScriptPicker();
                    else if (which == 1) askRename();
                    else if (which == 2) copyAllText();
                    else if (which == 3) askDelete();
                })
                .show();
    }

    private void askRename() {
        ScriptStore.Script s = store.find(currentScriptId);
        if (s == null) return;
        final EditText name = new EditText(this);
        name.setText(s.name);
        name.setSingleLine(true);
        name.setSelectAllOnFocus(true);
        LinearLayout box = new LinearLayout(this);
        int pad = Math.round(20 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(name, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle("Renombrar")
                .setView(box)
                .setPositiveButton("Guardar", (d, w) -> {
                    store.rename(currentScriptId, name.getText().toString());
                    ScriptStore.Script updated = store.find(currentScriptId);
                    if (updated != null) scriptTitle.setText(updated.name + " ▾");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void askDelete() {
        ScriptStore.Script s = store.find(currentScriptId);
        if (s == null) return;
        new AlertDialog.Builder(this)
                .setTitle("¿Eliminar «" + s.name + "»?")
                .setMessage("Se borrará el texto de esta exposición.")
                .setPositiveButton("Eliminar", (d, w) -> confirmStopIfRunning(() -> {
                    store.delete(currentScriptId);
                    currentScriptId = "";
                    loadScript(store.current().id);
                }))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void copyAllText() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("Exposición", inputText.getText().toString()));
                Toast.makeText(this, "Texto copiado.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ignored) {
        }
    }

    private void pasteFromClipboard() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip() == null
                    || cm.getPrimaryClip().getItemCount() == 0) {
                Toast.makeText(this, "El portapapeles está vacío.", Toast.LENGTH_SHORT).show();
                return;
            }
            CharSequence clip = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (clip == null || clip.toString().trim().isEmpty()) {
                Toast.makeText(this, "El portapapeles está vacío.", Toast.LENGTH_SHORT).show();
                return;
            }
            final String pasted = clip.toString();
            if (inputText.getText().toString().trim().isEmpty()) {
                inputText.setText(pasted);
                flushTextSave();
                updateScriptInfo();
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("Pegar texto")
                    .setItems(new String[]{"Reemplazar todo", "Agregar al final"}, (d, which) -> {
                        if (which == 0) {
                            inputText.setText(pasted);
                        } else {
                            inputText.append("\n\n" + pasted);
                        }
                        flushTextSave();
                        updateScriptInfo();
                    })
                    .show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo pegar.", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------- Memorizar

    private void openMemorizeMode() {
        flushTextSave();
        String text = inputText.getText().toString().trim();
        if (TextParser.parseItems(text).isEmpty()) {
            Toast.makeText(this, "Primero pega tu texto en la pestaña Textos.", Toast.LENGTH_SHORT).show();
            showTab(TAB_TEXTOS);
            return;
        }
        if (practiceRunning()) {
            sendSimpleAction(ExpoPlaybackService.ACTION_STOP);
        }
        Intent intent = new Intent(this, MemorizeActivity.class);
        intent.putExtra(MemorizeActivity.EXTRA_MEMORY_TEXT, text);
        startActivity(intent);
    }

    // ---------------------------------------------------------------- Ajustes

    private void setupSettingsSheet() {
        findViewById(R.id.settingsScrim).setOnClickListener(v -> closeSettings());
        findViewById(R.id.settingsClose).setOnClickListener(v -> closeSettings());

        RadioButton[] modes = {modeManual, modeAuto, modeMixed};
        String[] values = {ExpoPlaybackService.MODE_MANUAL, ExpoPlaybackService.MODE_AUTO, ExpoPlaybackService.MODE_MIXED};
        for (int i = 0; i < modes.length; i++) {
            final String value = values[i];
            modes[i].setOnClickListener(v -> {
                settings.setMode(value);
                syncSettingsUi();
                sendSettingsUpdateIfRunning();
                updatePlayButton();
            });
        }

        speedSeek.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                settings.setSpeedIndex(progress);
                syncSettingsUi();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                sendSettingsUpdateIfRunning();
            }
        });
        pauseSeek.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                settings.setPauseIndex(progress);
                syncSettingsUi();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                sendSettingsUpdateIfRunning();
            }
        });
        smartSeek.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                settings.setSmartIndex(progress);
                syncSettingsUi();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                sendSettingsUpdateIfRunning();
            }
        });
        targetSeek.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                settings.setTargetMinutes(progress);
                syncSettingsUi();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                sendSettingsUpdateIfRunning();
            }
        });

        switchCueTone.setOnCheckedChangeListener((b, checked) -> {
            if (syncingUi) return;
            settings.setCueTone(checked);
            sendSettingsUpdateIfRunning();
        });
        switchCueVoice.setOnCheckedChangeListener((b, checked) -> {
            if (syncingUi) return;
            settings.setCueVoice(checked);
            sendSettingsUpdateIfRunning();
        });
        switchVibrate.setOnCheckedChangeListener((b, checked) -> {
            if (syncingUi) return;
            settings.setVibrate(checked);
            sendSettingsUpdateIfRunning();
        });
        switchHintRead.setOnCheckedChangeListener((b, checked) -> {
            if (syncingUi) return;
            settings.setHintRead(checked);
            sendSettingsUpdateIfRunning();
        });
        switchMultiTap.setOnCheckedChangeListener((b, checked) -> {
            if (syncingUi) return;
            settings.setMultiTap(checked);
            sendSettingsUpdateIfRunning();
        });

        findViewById(R.id.physicalControlsButton).setOnClickListener(v -> showPhysicalControlsDialog());
        findViewById(R.id.prepareButton).setOnClickListener(v -> showPreparePhone());
        syncSettingsUi();
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar seekBar) {}
        @Override public void onStopTrackingTouch(SeekBar seekBar) {}
    }

    private void syncSettingsUi() {
        syncingUi = true;
        try {
            syncSettingsUiInternal();
        } finally {
            syncingUi = false;
        }
    }

    private void syncSettingsUiInternal() {
        String mode = settings.mode();
        modeManual.setChecked(ExpoPlaybackService.MODE_MANUAL.equals(mode));
        modeAuto.setChecked(ExpoPlaybackService.MODE_AUTO.equals(mode));
        modeMixed.setChecked(ExpoPlaybackService.MODE_MIXED.equals(mode));
        if (ExpoPlaybackService.MODE_MANUAL.equals(mode)) {
            modeHelp.setText("Lee una frase y espera a que toques ▶, power o el auricular.");
        } else if (ExpoPlaybackService.MODE_AUTO.equals(mode)) {
            modeHelp.setText("Avanza solo, con la pausa que elijas.");
        } else {
            modeHelp.setText("Avanza solo y puedes pausar con power, auricular o asistente.");
        }

        boolean manual = ExpoPlaybackService.MODE_MANUAL.equals(mode);
        speedSeek.setProgress(settings.speedIndex());
        speedLabel.setText("Velocidad de voz: " + ExpoSettings.SPEED_LABELS[settings.speedIndex()]);

        pauseSeek.setProgress(settings.pauseIndex());
        pauseSeek.setEnabled(!manual);
        pauseLabel.setText(manual
                ? "Pausa entre frases: (solo en Auto y Mixto)"
                : "Pausa entre frases: " + ExpoSettings.PAUSE_LABELS[settings.pauseIndex()]);

        boolean smart = !manual && settings.pauseMs() == ExpoSettings.PAUSE_SMART;
        smartBox.setVisibility(smart ? View.VISIBLE : View.GONE);
        smartSeek.setProgress(settings.smartIndex());
        smartLabel.setText("Tiempo para repetir: " + ExpoSettings.SMART_LABELS[settings.smartIndex()] + " lo que dura la frase");

        targetSeek.setProgress(settings.targetMinutes());
        targetLabel.setText(settings.targetMinutes() == 0
                ? "Tiempo objetivo: sin límite"
                : "Tiempo objetivo: " + settings.targetMinutes() + " min (aviso 1 min antes)");

        switchCueTone.setChecked(settings.cueTone());
        switchCueVoice.setChecked(settings.cueVoice());
        switchVibrate.setChecked(settings.vibrate());
        switchHintRead.setChecked(settings.hintRead());
        switchMultiTap.setChecked(settings.multiTap());
        refreshChips();
    }

    private void refreshChips() {
        if (chipMode == null) return;
        String mode = settings.mode();
        chipMode.setText(ExpoPlaybackService.MODE_AUTO.equals(mode) ? "Auto"
                : ExpoPlaybackService.MODE_MIXED.equals(mode) ? "Mixto" : "Manual");
        chipSpeed.setText(ExpoSettings.SPEED_LABELS[settings.speedIndex()]);
        if (ExpoPlaybackService.MODE_MANUAL.equals(mode)) {
            chipPause.setText(settings.hintRead() ? "Pista" : "Tú avanzas");
        } else if (settings.pauseMs() == ExpoSettings.PAUSE_SMART) {
            chipPause.setText("Pausa auto");
        } else {
            chipPause.setText("Pausa " + ExpoSettings.PAUSE_LABELS[settings.pauseIndex()]);
        }
    }

    private void openSettings() {
        hideKeyboard();
        syncSettingsUi();
        settingsOverlay.setVisibility(View.VISIBLE);
    }

    private void closeSettings() {
        settingsOverlay.setVisibility(View.GONE);
        refreshChips();
    }

    private void showPhysicalControlsDialog() {
        final String[] options = PhysicalControlSettings.LABELS;
        int selected = PhysicalControlSettings.getMode(this);
        final int[] pendingSelection = new int[]{selected};

        new AlertDialog.Builder(this)
                .setTitle("Botones para pausar / continuar")
                .setSingleChoiceItems(options, selected, (dialog, which) -> pendingSelection[0] = which)
                .setPositiveButton("Guardar", (dialog, which) -> {
                    PhysicalControlSettings.saveMode(this, pendingSelection[0]);
                    sendSettingsUpdateIfRunning();
                    String msg = "Guardado: " + options[pendingSelection[0]];
                    if (PhysicalControlSettings.usesPocketVolume(pendingSelection[0])) {
                        msg += ". Ajusta el volumen ANTES de iniciar: durante la práctica los botones solo pausan.";
                    }
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showPreparePhone() {
        String brand = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase(Locale.US);
        String tip;
        if (brand.contains("xiaomi") || brand.contains("redmi") || brand.contains("poco")) {
            tip = "Xiaomi/Redmi/POCO:\n• Batería: «Sin restricciones».\n• Activa «Inicio automático».\n• En Recientes, bloquea la app con el candado.";
        } else if (brand.contains("samsung")) {
            tip = "Samsung:\n• Batería > Límites de uso en segundo plano.\n• Agrega Geo Exponer a «Apps que nunca se suspenden».";
        } else if (brand.contains("huawei") || brand.contains("honor")) {
            tip = "Huawei/Honor:\n• Batería > Inicio de apps: gestionar manualmente y activa todo.";
        } else if (brand.contains("oppo") || brand.contains("realme") || brand.contains("oneplus") || brand.contains("vivo")) {
            tip = "OPPO/realme/OnePlus/vivo:\n• Batería: permitir actividad en segundo plano.\n• Permite inicio automático.";
        } else {
            tip = "• Batería: «Sin restricciones» para Geo Exponer.";
        }
        String status = isIgnoringBatteryOptimizations()
                ? "✓ Permiso de batería: permitido.\n\n"
                : "✗ Permiso de batería: falta.\n\n";
        new AlertDialog.Builder(this)
                .setTitle("Preparar mi celular")
                .setMessage(status + tip + "\n\nConsejo: activa «No molestar» al exponer para que ninguna notificación encienda la pantalla.")
                .setPositiveButton("Permiso de batería", (d, w) -> openBatteryPermissionScreen())
                .setNeutralButton("Ajustes de la app", (d, w) -> openAppSettings())
                .setNegativeButton("Cerrar", null)
                .show();
    }

    // ---------------------------------------------------------------- Modo bolsillo

    private void setupPocketMode() {
        findViewById(R.id.pocketButton).setOnClickListener(v -> enterPocketMode());
        pocketOverlay.setOnLongClickListener(v -> {
            exitPocketMode();
            return true;
        });
        pocketOverlay.setOnClickListener(v -> { /* bloquear toques accidentales */ });
    }

    private void enterPocketMode() {
        closeSettings();
        pocketOverlay.setVisibility(View.VISIBLE);
        try {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            savedBrightness = lp.screenBrightness;
            lp.screenBrightness = 0.01f;
            getWindow().setAttributes(lp);
        } catch (Exception ignored) {
        }
        if (!practiceRunning()) {
            Toast.makeText(this, "Modo bolsillo. Toca el auricular o mantén presionado para salir.", Toast.LENGTH_SHORT).show();
        }
    }

    private void exitPocketMode() {
        pocketOverlay.setVisibility(View.GONE);
        try {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = savedBrightness;
            getWindow().setAttributes(lp);
        } catch (Exception ignored) {
        }
    }

    // ---------------------------------------------------------------- Permisos

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
            }
        }
    }

    private void requestBatteryPermissionIfNeeded(boolean forcedByUser) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
        if (isIgnoringBatteryOptimizations()) {
            if (forcedByUser) Toast.makeText(this, "Permiso de batería ya permitido.", Toast.LENGTH_SHORT).show();
            return;
        }
        android.content.SharedPreferences prefs = getSharedPreferences(ScriptStore.PREFS, MODE_PRIVATE);
        boolean shownBefore = prefs.getBoolean(KEY_BATTERY_PROMPT_SHOWN, false);
        if (!forcedByUser && shownBefore) return;
        prefs.edit().putBoolean(KEY_BATTERY_PROMPT_SHOWN, true).apply();

        new AlertDialog.Builder(this)
                .setTitle("Permiso de batería")
                .setMessage("Para que Geo Exponer no se cierre con la pantalla apagada, toca Permitir. Luego revisa ⚙ > Preparar mi celular.")
                .setPositiveButton("Abrir permiso", (dialog, which) -> openBatteryPermissionScreen())
                .setNegativeButton("Luego", null)
                .show();
    }

    private boolean isIgnoringBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    private void openBatteryPermissionScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (isIgnoringBatteryOptimizations()) {
                Toast.makeText(this, "Permiso de batería ya permitido.", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                return;
            } catch (Exception ignored) {
            }
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                return;
            } catch (Exception ignored) {
            }
        }
        openAppSettings();
    }

    private void openAppSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception ignored) {
            Toast.makeText(this, "Hazlo manual desde Ajustes > Apps > Geo Exponer.", Toast.LENGTH_LONG).show();
        }
    }

    private String stateText(String state) {
        if (ExpoPlaybackService.STATE_PLAYING.equals(state)) return "Escucha…";
        if (ExpoPlaybackService.STATE_PAUSED.equals(state)) return "Pausado";
        if (ExpoPlaybackService.STATE_STOPPED.equals(state)) return "Detenido";
        if (ExpoPlaybackService.STATE_WAITING.equals(state)) {
            return ExpoPlaybackService.MODE_MANUAL.equals(settings.mode())
                    ? "Tu turno · toca ▶, power o auricular para seguir"
                    : "Tu turno · repite la frase";
        }
        if (ExpoPlaybackService.STATE_ERROR.equals(state)) return "Error de voz · revisa el motor de voz del teléfono";
        return "Listo";
    }
}
