package com.brian.geoexponer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.media.VolumeProvider;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.KeyEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ExpoPlaybackService extends Service {
    public static final String ACTION_START = "com.brian.geoexponer.START";
    public static final String ACTION_TOGGLE = "com.brian.geoexponer.TOGGLE";
    public static final String ACTION_PHYSICAL_TOGGLE = "com.brian.geoexponer.PHYSICAL_TOGGLE";
    public static final String ACTION_ASSIST_TOGGLE = "com.brian.geoexponer.ASSIST_TOGGLE";
    public static final String ACTION_REPEAT = "com.brian.geoexponer.REPEAT";
    public static final String ACTION_PREVIOUS = "com.brian.geoexponer.PREVIOUS";
    public static final String ACTION_NEXT = "com.brian.geoexponer.NEXT";
    public static final String ACTION_STOP = "com.brian.geoexponer.STOP";
    public static final String ACTION_UPDATE_SETTINGS = "com.brian.geoexponer.UPDATE_SETTINGS";
    public static final String ACTION_STATUS = "com.brian.geoexponer.STATUS";
    public static final String ACTION_TICK = "com.brian.geoexponer.TICK";
    public static final String ACTION_STATUS_REQUEST = "com.brian.geoexponer.STATUS_REQUEST";
    public static final String ACTION_PREVIOUS_SLIDE = "com.brian.geoexponer.PREVIOUS_SLIDE";
    public static final String ACTION_NEXT_SLIDE = "com.brian.geoexponer.NEXT_SLIDE";

    public static final String EXTRA_TEXT = "text";
    public static final String EXTRA_SCRIPT_ID = "script_id";
    public static final String EXTRA_SPEED = "speed";
    public static final String EXTRA_PAUSE_MS = "pause_ms";
    public static final String EXTRA_SMART_FACTOR = "smart_factor";
    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_CUE_TONE = "cue_tone";
    public static final String EXTRA_CUE_VOICE = "cue_voice";
    public static final String EXTRA_VIBRATE = "vibrate";
    public static final String EXTRA_TARGET_MIN = "target_min";
    public static final String EXTRA_HINT_READ = "hint_read";
    public static final String EXTRA_MULTI_TAP = "multi_tap";

    public static final String EXTRA_PHRASE = "phrase";
    public static final String EXTRA_NEXT_PHRASE = "next_phrase";
    public static final String EXTRA_SLIDE_TITLE = "slide_title";
    public static final String EXTRA_SLIDE_INDEX = "slide_index";
    public static final String EXTRA_SLIDE_COUNT = "slide_count";
    public static final String EXTRA_PHRASE_IN_SLIDE = "phrase_in_slide";
    public static final String EXTRA_PHRASES_IN_SLIDE = "phrases_in_slide";
    public static final String EXTRA_INDEX = "index";
    public static final String EXTRA_TOTAL = "total";
    public static final String EXTRA_STATE = "state";
    public static final String EXTRA_ELAPSED_MS = "elapsed_ms";
    public static final String EXTRA_TARGET_MS = "target_ms";

    public static final String STATE_PLAYING = "playing";
    public static final String STATE_WAITING = "waiting";
    public static final String STATE_PAUSED = "paused";
    public static final String STATE_STOPPED = "stopped";
    public static final String STATE_ERROR = "error";

    public static final String MODE_MANUAL = "manual";
    public static final String MODE_AUTO = "auto";
    public static final String MODE_MIXED = "mixed";

    private static final String CHANNEL_ID = "geo_exponer_playback";
    private static final int NOTIFICATION_ID = 2026;
    private static final String PHRASE_PREFIX = "geo_exponer_";
    private static final String CUE_PREFIX = "geo_cue_";
    private static final long TOGGLE_DEBOUNCE_MS = 350L;
    private static final long MULTI_TAP_WINDOW_MS = 450L;
    private static final int HINT_WORDS = 3;

    private final Handler handler = new Handler(Looper.getMainLooper());
    // Handlers separados: handler se limpia completo en cada frase.
    private final Handler timerHandler = new Handler(Looper.getMainLooper());
    private final Handler tapHandler = new Handler(Looper.getMainLooper());
    private final List<TextParser.Item> items = new ArrayList<>();

    private TextToSpeech tts;
    private MediaSession mediaSession;
    private boolean ttsReady = false;
    private boolean pendingStart = false;
    private boolean running = false;
    private boolean paused = false;
    private boolean pausedByScreen = false;
    private boolean pausedDuringWaiting = false;
    private boolean screenReceiverRegistered = false;
    private PowerManager.WakeLock wakeLock;
    private long lastScreenContinueMs = 0L;
    private long screenControlReadyMs = 0L;
    private int index = 0;
    private int pauseMs = 1000;
    private float smartFactor = 1.0f;
    private String playbackMode = MODE_MANUAL;
    private float speechRate = 1.0f;
    private String currentState = STATE_STOPPED;
    private int utteranceCounter = 0;
    private String activePhraseUtterance = null;
    private long phraseSpeakStartMs = 0L;
    private long lastPhraseDurationMs = 0L;
    private int lastCuedSlide = -1;

    private boolean cueTone = true;
    private boolean cueVoice = false;
    private boolean vibrateOnSlide = true;
    private int targetMinutes = 0;
    private boolean hintRead = false;
    private boolean multiTap = false;
    private String scriptId = "";

    private long practiceStartMs = 0L;
    private long pausedAccumMs = 0L;
    private long pauseStartedMs = 0L;
    private boolean warnedOneMinute = false;
    private boolean warnedTarget = false;

    private long lastToggleMs = 0L;
    private int tapCount = 0;
    private ToneGenerator toneGenerator;
    private boolean remoteVolumeActive = false;
    private long lastVolumeKeyMs = 0L;

    private final Runnable tapRunnable = new Runnable() {
        @Override
        public void run() {
            int taps = tapCount;
            tapCount = 0;
            pausedByScreen = false;
            if (taps >= 3) {
                repeatPhrase(true);
            } else if (taps == 2) {
                nextPhrase();
            } else {
                togglePlayback();
            }
        }
    };

    private final Runnable tickRunnable = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            long elapsed = elapsedMs();
            checkTargetAlerts(elapsed);
            Intent tick = new Intent(ACTION_TICK);
            tick.setPackage(getPackageName());
            tick.putExtra(EXTRA_ELAPSED_MS, elapsed);
            tick.putExtra(EXTRA_TARGET_MS, targetMinutes * 60_000L);
            sendBroadcast(tick);
            timerHandler.postDelayed(this, 1000L);
        }
    };

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || intent.getAction() == null) return;

            String action = intent.getAction();

            if (!Intent.ACTION_SCREEN_OFF.equals(action) && !Intent.ACTION_SCREEN_ON.equals(action)) return;
            if (!running) return;

            boolean customControlsConfigured = PhysicalControlSettings.isConfigured(ExpoPlaybackService.this);
            if (customControlsConfigured) {
                int physicalMode = PhysicalControlSettings.getMode(ExpoPlaybackService.this);
                if (!PhysicalControlSettings.usesScreen(physicalMode)) return;
            }

            long now = SystemClock.elapsedRealtime();
            if (now < screenControlReadyMs) return;
            if (now - lastScreenContinueMs < 700) return;
            lastScreenContinueMs = now;

            if (customControlsConfigured) {
                pausedByScreen = true;
                togglePhysicalPause();
                return;
            }

            if (manualMode() && STATE_WAITING.equals(currentState)) {
                pausedByScreen = false;
                pausedDuringWaiting = false;
                advanceToNextPhrase();
                return;
            }

            if (mixedMode()) {
                // Comportamiento original del modo mixto con power.
                if (STATE_WAITING.equals(currentState) && !paused) {
                    return;
                }
                pausedByScreen = true;
                togglePlayback();
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        registerScreenReceiver();
        setupMediaSession();
        setupTextToSpeech();
        setupWakeLock();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForegroundCompat();

        String action = intent != null ? intent.getAction() : null;
        if (ACTION_START.equals(action)) {
            startNewPractice(intent);
        } else if (ACTION_PHYSICAL_TOGGLE.equals(action)) {
            if (debounceToggle()) {
                pausedByScreen = false;
                togglePhysicalPause();
            }
        } else if (ACTION_TOGGLE.equals(action) || ACTION_ASSIST_TOGGLE.equals(action)) {
            if (debounceToggle()) {
                pausedByScreen = false;
                togglePlayback();
            }
        } else if (ACTION_REPEAT.equals(action)) {
            pausedByScreen = false;
            repeatPhrase(true);
        } else if (ACTION_PREVIOUS.equals(action)) {
            pausedByScreen = false;
            previousPhrase();
        } else if (ACTION_NEXT.equals(action)) {
            pausedByScreen = false;
            nextPhrase();
        } else if (ACTION_PREVIOUS_SLIDE.equals(action)) {
            pausedByScreen = false;
            jumpSlide(-1);
        } else if (ACTION_NEXT_SLIDE.equals(action)) {
            pausedByScreen = false;
            jumpSlide(1);
        } else if (ACTION_STOP.equals(action)) {
            stopPractice(false);
        } else if (ACTION_UPDATE_SETTINGS.equals(action)) {
            updateSettings(intent);
        } else if (ACTION_STATUS_REQUEST.equals(action)) {
            broadcastStatus(currentState);
            if (!running) {
                stopForeground(true);
                stopSelf();
                return START_NOT_STICKY;
            }
        } else {
            broadcastStatus(currentState);
        }

        return START_STICKY;
    }

    private void startForegroundCompat() {
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
                return;
            } catch (Exception ignored) {
                // Si el sistema rechaza el tipo, se intenta sin tipo.
            }
        }
        startForeground(NOTIFICATION_ID, notification);
    }

    private boolean debounceToggle() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastToggleMs < TOGGLE_DEBOUNCE_MS) return false;
        lastToggleMs = now;
        return true;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        if (running && !STATE_STOPPED.equals(currentState)) {
            refreshNotification();
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        timerHandler.removeCallbacksAndMessages(null);
        tapHandler.removeCallbacksAndMessages(null);
        unregisterScreenReceiver();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (mediaSession != null) {
            try {
                mediaSession.setPlaybackToLocal(mediaAudioAttributes());
            } catch (Exception ignored) {
            }
            mediaSession.setActive(false);
            mediaSession.release();
        }
        if (toneGenerator != null) {
            try {
                toneGenerator.release();
            } catch (Exception ignored) {
            }
            toneGenerator = null;
        }
        releaseWakeLock();
        super.onDestroy();
    }

    private void registerScreenReceiver() {
        if (screenReceiverRegistered) return;
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(screenReceiver, filter);
        }
        screenReceiverRegistered = true;
    }

    private void unregisterScreenReceiver() {
        if (!screenReceiverRegistered) return;
        try {
            unregisterReceiver(screenReceiver);
        } catch (IllegalArgumentException ignored) {
        }
        screenReceiverRegistered = false;
    }

    private void setupWakeLock() {
        try {
            PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (powerManager != null) {
                wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoExponer:PlaybackWakeLock");
                wakeLock.setReferenceCounted(false);
            }
        } catch (Exception ignored) {
            wakeLock = null;
        }
    }

    private void acquireWakeLock() {
        try {
            if (wakeLock != null && !wakeLock.isHeld()) {
                wakeLock.acquire(6 * 60 * 60 * 1000L);
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        } catch (Exception ignored) {
        }
    }

    private void setupTextToSpeech() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true;
                int languageResult = tts.setLanguage(new Locale("es", "ES"));
                if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.getDefault());
                }
                tts.setPitch(1.0f);
                try {
                    tts.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build());
                } catch (Exception ignored) {
                }
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                        handler.post(() -> {
                            if (utteranceId != null && utteranceId.equals(activePhraseUtterance)) {
                                phraseSpeakStartMs = SystemClock.elapsedRealtime();
                            }
                            if (!running || paused) return;
                            currentState = STATE_PLAYING;
                            updatePlaybackState();
                            broadcastStatus(STATE_PLAYING);
                            refreshNotification();
                        });
                    }

                    @Override
                    public void onDone(String utteranceId) {
                        handler.post(() -> {
                            if (utteranceId == null || !utteranceId.equals(activePhraseUtterance)) return;
                            if (phraseSpeakStartMs > 0L) {
                                lastPhraseDurationMs = SystemClock.elapsedRealtime() - phraseSpeakStartMs;
                            }
                            onSpeechDone();
                        });
                    }

                    @Override
                    public void onError(String utteranceId) {
                        handler.post(() -> {
                            if (utteranceId == null || !utteranceId.equals(activePhraseUtterance)) return;
                            currentState = STATE_ERROR;
                            updatePlaybackState();
                            broadcastStatus(STATE_ERROR);
                            refreshNotification();
                        });
                    }
                });

                if (pendingStart) {
                    pendingStart = false;
                    speakCurrentPhrase(false);
                }
            } else {
                currentState = STATE_ERROR;
                broadcastStatus(STATE_ERROR);
                refreshNotification();
            }
        });
    }

    private void setupMediaSession() {
        mediaSession = new MediaSession(this, "GeoExponerSession");
        mediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);

        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent sessionActivity = PendingIntent.getActivity(this, 1, openIntent, pendingFlags());
        mediaSession.setSessionActivity(sessionActivity);

        Intent mediaButtonIntent = new Intent(Intent.ACTION_MEDIA_BUTTON);
        mediaButtonIntent.setClass(this, ButtonIntentReceiver.class);
        PendingIntent mediaButtonPendingIntent = PendingIntent.getBroadcast(this, 2, mediaButtonIntent, mediaButtonPendingFlags());
        mediaSession.setMediaButtonReceiver(mediaButtonPendingIntent);

        mediaSession.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() {
                pausedByScreen = false;
                resumePlayback();
            }

            @Override
            public void onPause() {
                pausedByScreen = false;
                pausePlayback();
            }

            @Override
            public void onStop() {
                stopPractice(false);
            }

            @Override
            public void onSkipToNext() {
                pausedByScreen = false;
                nextPhrase();
            }

            @Override
            public void onSkipToPrevious() {
                pausedByScreen = false;
                repeatPhrase(true);
            }

            @Override
            public boolean onMediaButtonEvent(Intent mediaButtonIntent) {
                KeyEvent event = mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
                if (event == null || event.getAction() != KeyEvent.ACTION_UP) {
                    return true;
                }

                int code = event.getKeyCode();
                if (code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code == KeyEvent.KEYCODE_HEADSETHOOK
                        || code == KeyEvent.KEYCODE_ASSIST || code == KeyEvent.KEYCODE_VOICE_ASSIST) {
                    pausedByScreen = false;
                    boolean headsetButton = code == KeyEvent.KEYCODE_HEADSETHOOK || code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
                    if (multiTap && headsetButton && running) {
                        tapCount++;
                        tapHandler.removeCallbacks(tapRunnable);
                        tapHandler.postDelayed(tapRunnable, MULTI_TAP_WINDOW_MS);
                    } else if (debounceToggle()) {
                        togglePlayback();
                    }
                    return true;
                } else if (code == KeyEvent.KEYCODE_MEDIA_PLAY) {
                    pausedByScreen = false;
                    resumePlayback();
                    return true;
                } else if (code == KeyEvent.KEYCODE_MEDIA_PAUSE) {
                    pausedByScreen = false;
                    pausePlayback();
                    return true;
                } else if (code == KeyEvent.KEYCODE_MEDIA_NEXT) {
                    pausedByScreen = false;
                    nextPhrase();
                    return true;
                } else if (code == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
                    pausedByScreen = false;
                    previousPhrase();
                    return true;
                }
                return super.onMediaButtonEvent(mediaButtonIntent);
            }
        });

        mediaSession.setActive(true);
        updatePlaybackState();
    }

    /**
     * Volumen en el bolsillo: la sesión recibe los botones de volumen aunque la
     * pantalla esté apagada. Solo se activa si el usuario eligió esa opción.
     */
    private void applyVolumeControl() {
        if (mediaSession == null) return;
        int mode = PhysicalControlSettings.getMode(this);
        boolean want = running && PhysicalControlSettings.isConfigured(this)
                && PhysicalControlSettings.usesPocketVolume(mode);
        if (want == remoteVolumeActive) return;
        try {
            if (want) {
                mediaSession.setPlaybackToRemote(new VolumeProvider(VolumeProvider.VOLUME_CONTROL_RELATIVE, 100, 50) {
                    @Override
                    public void onAdjustVolume(int direction) {
                        if (direction == 0) return;
                        long now = SystemClock.elapsedRealtime();
                        // Mantener presionado envía repeticiones: solo cuenta una por pulsación.
                        if (now - lastVolumeKeyMs < 450L) {
                            lastVolumeKeyMs = now;
                            return;
                        }
                        lastVolumeKeyMs = now;
                        handler.post(() -> {
                            pausedByScreen = false;
                            togglePhysicalPause();
                        });
                    }
                });
            } else {
                mediaSession.setPlaybackToLocal(mediaAudioAttributes());
            }
            remoteVolumeActive = want;
        } catch (Exception ignored) {
            remoteVolumeActive = false;
        }
    }

    private static AudioAttributes mediaAudioAttributes() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build();
    }

    private void readSettings(Intent intent, boolean start) {
        if (intent == null) return;
        if (intent.hasExtra(EXTRA_PAUSE_MS)) {
            int newPause = intent.getIntExtra(EXTRA_PAUSE_MS, pauseMs);
            pauseMs = newPause;
        }
        if (intent.hasExtra(EXTRA_SMART_FACTOR)) {
            smartFactor = Math.max(0.5f, Math.min(2.0f, intent.getFloatExtra(EXTRA_SMART_FACTOR, 1.0f)));
        }
        if (intent.hasExtra(EXTRA_MODE)) {
            String newMode = intent.getStringExtra(EXTRA_MODE);
            if (!MODE_AUTO.equals(newMode) && !MODE_MIXED.equals(newMode)) newMode = MODE_MANUAL;
            boolean becameManual = !MODE_MANUAL.equals(playbackMode) && MODE_MANUAL.equals(newMode);
            playbackMode = newMode;
            if (!start && becameManual && STATE_WAITING.equals(currentState) && !paused) {
                // Cancelar el avance automático pendiente: ahora espera al usuario.
                handler.removeCallbacksAndMessages(null);
            }
        }
        cueTone = intent.getBooleanExtra(EXTRA_CUE_TONE, cueTone);
        cueVoice = intent.getBooleanExtra(EXTRA_CUE_VOICE, cueVoice);
        vibrateOnSlide = intent.getBooleanExtra(EXTRA_VIBRATE, vibrateOnSlide);
        int newTarget = intent.getIntExtra(EXTRA_TARGET_MIN, targetMinutes);
        if (newTarget != targetMinutes) {
            targetMinutes = Math.max(0, newTarget);
            warnedOneMinute = false;
            warnedTarget = false;
        }
        hintRead = intent.getBooleanExtra(EXTRA_HINT_READ, hintRead);
        multiTap = intent.getBooleanExtra(EXTRA_MULTI_TAP, multiTap);
    }

    private void updateSettings(Intent intent) {
        if (intent == null) return;
        readSettings(intent, false);
        applyVolumeControl();

        float newSpeechRate = intent.getFloatExtra(EXTRA_SPEED, speechRate);
        if (newSpeechRate < 0.25f) newSpeechRate = 0.25f;
        if (newSpeechRate > 1.50f) newSpeechRate = 1.50f;
        boolean speedChanged = Math.abs(newSpeechRate - speechRate) > 0.001f;
        speechRate = newSpeechRate;
        if (tts != null && ttsReady) {
            tts.setSpeechRate(speechRate);
        }

        // TTS no cambia la velocidad de una frase que ya está sonando:
        // se reinicia solo la frase actual para aplicar la nueva velocidad.
        if (speedChanged && running && !paused && STATE_PLAYING.equals(currentState)) {
            speakCurrentPhrase(false);
            return;
        }

        broadcastStatus(currentState);
        refreshNotification();
    }

    private void startNewPractice(Intent intent) {
        String text = intent.getStringExtra(EXTRA_TEXT);
        speechRate = intent.getFloatExtra(EXTRA_SPEED, 1.0f);
        String id = intent.getStringExtra(EXTRA_SCRIPT_ID);
        scriptId = id == null ? "" : id;
        playbackMode = MODE_MANUAL;
        pauseMs = 1000;
        readSettings(intent, true);
        if (MODE_MANUAL.equals(playbackMode)) {
            pauseMs = -1;
        } else if (pauseMs == -1) {
            pauseMs = 1000;
        }
        screenControlReadyMs = SystemClock.elapsedRealtime() + 1800L;

        items.clear();
        items.addAll(TextParser.parseItems(text));
        index = 0;
        paused = false;
        pausedByScreen = false;
        pausedDuringWaiting = false;
        lastCuedSlide = -1;
        lastPhraseDurationMs = 0L;
        running = items.size() > 0;
        handler.removeCallbacksAndMessages(null);
        timerHandler.removeCallbacksAndMessages(null);

        if (!running) {
            currentState = STATE_ERROR;
            broadcastStatus(STATE_ERROR);
            refreshNotification();
            return;
        }

        acquireWakeLock();
        practiceStartMs = SystemClock.elapsedRealtime();
        pausedAccumMs = 0L;
        pauseStartedMs = 0L;
        warnedOneMinute = false;
        warnedTarget = false;
        timerHandler.post(tickRunnable);
        applyVolumeControl();

        if (ttsReady) {
            speakCurrentPhrase(false);
        } else {
            pendingStart = true;
            currentState = STATE_WAITING;
            broadcastStatus(STATE_WAITING);
            refreshNotification();
        }
    }

    private void speakCurrentPhrase(boolean forceFull) {
        if (!running || paused || items.isEmpty()) return;

        if (index < 0) index = 0;
        if (index >= items.size()) {
            playEndCue();
            stopPractice(true);
            return;
        }

        handler.removeCallbacksAndMessages(null);
        currentState = STATE_PLAYING;
        updatePlaybackState();
        broadcastStatus(STATE_PLAYING);
        refreshNotification();

        if (tts == null || !ttsReady) return;

        TextParser.Item item = items.get(index);
        boolean newSlide = item.slideIndex != lastCuedSlide;
        boolean hasSlides = item.slideCount > 1;
        tts.stop();
        tts.setSpeechRate(speechRate);

        int queueMode = TextToSpeech.QUEUE_FLUSH;
        if (newSlide && hasSlides && lastCuedSlide >= 0) {
            // Aviso al cambiar de diapositiva (no en la primera).
            if (cueTone) playTone(ToneGenerator.TONE_PROP_BEEP, 120);
            if (vibrateOnSlide) vibrate(new long[]{0, 120});
            if (cueVoice) {
                String label = item.slideNumber.isEmpty()
                        ? "Siguiente parte"
                        : "Diapositiva " + item.slideNumber;
                tts.speak(label, TextToSpeech.QUEUE_FLUSH, new Bundle(), CUE_PREFIX + (++utteranceCounter));
                queueMode = TextToSpeech.QUEUE_ADD;
            }
        }
        lastCuedSlide = item.slideIndex;

        String toSpeak = item.spoken;
        if (hintRead && !forceFull) {
            toSpeak = firstWords(item.spoken, HINT_WORDS);
        }
        phraseSpeakStartMs = 0L;
        activePhraseUtterance = PHRASE_PREFIX + (++utteranceCounter);
        tts.speak(toSpeak, queueMode, new Bundle(), activePhraseUtterance);
    }

    private static String firstWords(String text, int count) {
        String[] words = text.trim().split("\\s+");
        if (words.length <= count) return text;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (i > 0) b.append(' ');
            b.append(words[i]);
        }
        return b.toString();
    }

    private long waitAfterPhraseMs() {
        if (pauseMs != ExpoSettings.PAUSE_SMART) return pauseMs;
        // Pausa inteligente: el tiempo que tardas en repetir la frase.
        long base;
        TextParser.Item item = (index >= 0 && index < items.size()) ? items.get(index) : null;
        if (hintRead && item != null) {
            // En modo pista la voz solo dice el inicio: calcular por palabras.
            int words = TextParser.wordCount(item.spoken);
            base = Math.round(words * 420L / Math.max(0.5f, speechRate));
        } else if (lastPhraseDurationMs > 200L) {
            base = lastPhraseDurationMs;
        } else {
            int words = item == null ? 8 : TextParser.wordCount(item.spoken);
            base = Math.round(words * 420L / Math.max(0.5f, speechRate));
        }
        long wait = Math.round(base * smartFactor) + 500L;
        return Math.max(800L, Math.min(30_000L, wait));
    }

    private void onSpeechDone() {
        if (!running || paused || items.isEmpty()) return;

        currentState = STATE_WAITING;
        updatePlaybackState();
        broadcastStatus(STATE_WAITING);
        refreshNotification();

        if (manualMode()) {
            return;
        }

        long wait = waitAfterPhraseMs();
        if (wait <= 0) {
            advanceToNextPhrase();
            return;
        }

        handler.postDelayed(() -> {
            if (!running || paused) return;
            advanceToNextPhrase();
        }, wait);
    }

    private void togglePhysicalPause() {
        if (!running || items.isEmpty()) {
            broadcastStatus(currentState);
            return;
        }

        if (paused) {
            resumePlayback();
        } else {
            pausePlayback();
        }
    }

    private void togglePlayback() {
        if (!running || items.isEmpty()) {
            broadcastStatus(currentState);
            return;
        }

        if (paused) {
            if (pausedDuringWaiting) {
                pausedDuringWaiting = false;
                endPauseTimer();
                advanceToNextPhrase();
            } else {
                resumePlayback();
            }
        } else if (STATE_WAITING.equals(currentState)) {
            if (manualMode()) {
                advanceToNextPhrase();
            } else {
                pausePlayback();
            }
        } else {
            pausePlayback();
        }
    }

    private void pausePlayback() {
        if (!running) return;
        if (paused) return;
        pausedDuringWaiting = STATE_WAITING.equals(currentState);
        paused = true;
        pauseStartedMs = SystemClock.elapsedRealtime();
        handler.removeCallbacksAndMessages(null);
        if (!STATE_WAITING.equals(currentState) && tts != null) tts.stop();
        currentState = STATE_PAUSED;
        updatePlaybackState();
        broadcastStatus(STATE_PAUSED);
        refreshNotification();
    }

    private void endPauseTimer() {
        if (pauseStartedMs > 0L) {
            pausedAccumMs += SystemClock.elapsedRealtime() - pauseStartedMs;
            pauseStartedMs = 0L;
        }
    }

    private void resumePlayback() {
        if (!running || items.isEmpty()) return;
        paused = false;
        endPauseTimer();
        if (pausedDuringWaiting) {
            pausedDuringWaiting = false;
            advanceToNextPhrase();
            return;
        }
        speakCurrentPhrase(false);
    }

    private void repeatPhrase(boolean forceFull) {
        if (!running || items.isEmpty()) return;
        paused = false;
        pausedDuringWaiting = false;
        endPauseTimer();
        speakCurrentPhrase(forceFull);
    }

    private void previousPhrase() {
        if (!running || items.isEmpty()) return;
        paused = false;
        pausedDuringWaiting = false;
        endPauseTimer();
        handler.removeCallbacksAndMessages(null);
        if (index > 0) {
            index--;
        }
        speakCurrentPhrase(false);
    }

    private void nextPhrase() {
        if (!running || items.isEmpty()) return;
        paused = false;
        pausedDuringWaiting = false;
        endPauseTimer();
        advanceToNextPhrase();
    }

    private void jumpSlide(int direction) {
        if (!running || items.isEmpty()) return;
        paused = false;
        pausedDuringWaiting = false;
        endPauseTimer();
        handler.removeCallbacksAndMessages(null);
        int current = items.get(Math.max(0, Math.min(index, items.size() - 1))).slideIndex;
        int target = current + direction;
        if (target < 0) target = 0;
        int newIndex = -1;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).slideIndex == target) {
                newIndex = i;
                break;
            }
        }
        if (newIndex < 0) {
            if (direction > 0) {
                newIndex = items.size() - 1;
            } else {
                newIndex = 0;
            }
        }
        index = newIndex;
        speakCurrentPhrase(false);
    }

    private void advanceToNextPhrase() {
        if (!running || items.isEmpty()) return;
        paused = false;
        pausedDuringWaiting = false;
        index++;
        speakCurrentPhrase(false);
    }

    private boolean manualMode() {
        return MODE_MANUAL.equals(playbackMode);
    }

    private boolean mixedMode() {
        return MODE_MIXED.equals(playbackMode);
    }

    private long elapsedMs() {
        if (practiceStartMs <= 0L) return 0L;
        long now = SystemClock.elapsedRealtime();
        long pausedNow = (paused && pauseStartedMs > 0L) ? now - pauseStartedMs : 0L;
        return Math.max(0L, now - practiceStartMs - pausedAccumMs - pausedNow);
    }

    private void checkTargetAlerts(long elapsed) {
        if (targetMinutes <= 0) return;
        long target = targetMinutes * 60_000L;
        if (targetMinutes >= 2 && !warnedOneMinute && elapsed >= target - 60_000L) {
            warnedOneMinute = true;
            playTone(ToneGenerator.TONE_PROP_BEEP2, 200);
            vibrate(new long[]{0, 150, 150, 150});
        }
        if (!warnedTarget && elapsed >= target) {
            warnedTarget = true;
            playTone(ToneGenerator.TONE_PROP_ACK, 300);
            vibrate(new long[]{0, 600});
        }
    }

    private void playEndCue() {
        if (cueTone) playTone(ToneGenerator.TONE_PROP_ACK, 250);
        if (vibrateOnSlide) vibrate(new long[]{0, 200, 120, 200});
    }

    private void playTone(int tone, int durationMs) {
        try {
            if (toneGenerator == null) {
                toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 55);
            }
            toneGenerator.startTone(tone, durationMs);
        } catch (Exception ignored) {
            toneGenerator = null;
        }
    }

    @SuppressWarnings("deprecation")
    private void vibrate(long[] pattern) {
        try {
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator == null || !vibrator.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1));
            } else {
                vibrator.vibrate(pattern, -1);
            }
        } catch (Exception ignored) {
        }
    }

    private void stopPractice(boolean finished) {
        boolean wasRunning = running;
        long duration = elapsedMs();
        running = false;
        paused = false;
        pausedByScreen = false;
        pausedDuringWaiting = false;
        pendingStart = false;
        handler.removeCallbacksAndMessages(null);
        timerHandler.removeCallbacksAndMessages(null);
        tapHandler.removeCallbacksAndMessages(null);
        tapCount = 0;
        if (tts != null) tts.stop();
        activePhraseUtterance = null;
        applyVolumeControl();
        if (wasRunning && (finished || duration >= 5000L)) {
            ScriptStore.recordRehearsal(this, scriptId, duration);
        }
        currentState = STATE_STOPPED;
        updatePlaybackState();
        broadcastStatus(STATE_STOPPED);
        releaseWakeLock();
        stopForeground(true);
        // El servicio queda "caliente" para que el siguiente inicio responda rápido.
    }

    private void broadcastStatus(String state) {
        Intent intent = new Intent(ACTION_STATUS);
        intent.setPackage(getPackageName());
        intent.putExtra(EXTRA_STATE, state);
        intent.putExtra(EXTRA_INDEX, items.isEmpty() ? 0 : Math.min(index, items.size() - 1) + 1);
        intent.putExtra(EXTRA_TOTAL, items.size());
        intent.putExtra(EXTRA_ELAPSED_MS, elapsedMs());
        intent.putExtra(EXTRA_TARGET_MS, targetMinutes * 60_000L);
        if (!items.isEmpty() && index >= 0 && index < items.size()) {
            TextParser.Item item = items.get(index);
            intent.putExtra(EXTRA_PHRASE, item.raw);
            intent.putExtra(EXTRA_SLIDE_TITLE, item.slideTitle);
            intent.putExtra(EXTRA_SLIDE_INDEX, item.slideIndex + 1);
            intent.putExtra(EXTRA_SLIDE_COUNT, item.slideCount);
            intent.putExtra(EXTRA_PHRASE_IN_SLIDE, item.phraseInSlide);
            intent.putExtra(EXTRA_PHRASES_IN_SLIDE, item.phrasesInSlide);
            intent.putExtra(EXTRA_NEXT_PHRASE, index + 1 < items.size() ? items.get(index + 1).raw : "");
        } else {
            intent.putExtra(EXTRA_PHRASE, "");
            intent.putExtra(EXTRA_NEXT_PHRASE, "");
        }
        sendBroadcast(intent);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Geo Exponer",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Controles de práctica de exposición");
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPendingIntent = PendingIntent.getActivity(this, 20, openIntent, pendingFlags());

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
            builder.setPriority(Notification.PRIORITY_LOW);
        }

        builder.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Geo Exponer")
                .setContentText(notificationText())
                .setContentIntent(openPendingIntent)
                .setShowWhen(false)
                .setOngoing(running && !STATE_STOPPED.equals(currentState))
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setCategory(Notification.CATEGORY_TRANSPORT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            builder.addAction(makeAction(ACTION_PREVIOUS, "Anterior", 31));
            builder.addAction(makeAction(ACTION_TOGGLE, paused ? "Reanudar" : "Pausar", 32));
            builder.addAction(makeAction(ACTION_NEXT, "Siguiente", 33));
            builder.addAction(makeAction(ACTION_STOP, "Detener", 34));
        }

        if (mediaSession != null) {
            builder.setStyle(new Notification.MediaStyle()
                    .setMediaSession(mediaSession.getSessionToken())
                    .setShowActionsInCompactView(0, 1, 2));
        }

        return builder.build();
    }

    private Notification.Action makeAction(String action, String title, int requestCode) {
        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(action);
        PendingIntent pendingIntent = PendingIntent.getService(this, requestCode, intent, pendingFlags());
        Icon icon = Icon.createWithResource(this, R.drawable.ic_notification);
        return new Notification.Action.Builder(icon, title, pendingIntent).build();
    }

    private void refreshNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(NOTIFICATION_ID, buildNotification());
        }
    }

    private String notificationText() {
        if (items.isEmpty() || index < 0 || index >= items.size()) {
            return "Listo para practicar";
        }
        String prefix;
        if (STATE_PAUSED.equals(currentState)) prefix = "Pausado";
        else if (STATE_WAITING.equals(currentState)) prefix = manualMode() ? "Clic power/asistente" : "Repite ahora";
        else if (STATE_PLAYING.equals(currentState)) prefix = "Escucha";
        else prefix = "Geo Exponer";

        String phrase = items.get(index).spoken;
        if (phrase.length() > 55) phrase = phrase.substring(0, 55) + "...";
        return prefix + ": " + phrase;
    }

    private void updatePlaybackState() {
        if (mediaSession == null) return;

        int playbackState;
        if (STATE_PLAYING.equals(currentState) || STATE_WAITING.equals(currentState)) {
            playbackState = PlaybackState.STATE_PLAYING;
        } else if (STATE_PAUSED.equals(currentState)) {
            playbackState = PlaybackState.STATE_PAUSED;
        } else {
            playbackState = PlaybackState.STATE_STOPPED;
        }

        long actions = PlaybackState.ACTION_PLAY
                | PlaybackState.ACTION_PAUSE
                | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_STOP
                | PlaybackState.ACTION_SKIP_TO_NEXT
                | PlaybackState.ACTION_SKIP_TO_PREVIOUS;

        PlaybackState state = new PlaybackState.Builder()
                .setActions(actions)
                .setState(playbackState, PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1.0f)
                .build();
        mediaSession.setPlaybackState(state);
    }

    private int pendingFlags() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return flags;
    }

    private int mediaButtonPendingFlags() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            flags |= PendingIntent.FLAG_MUTABLE;
        }
        return flags;
    }
}
