package com.brian.geoexponer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.Html;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Modo Memorizar (con micrófono). Independiente del modo Exponer:
 * no usa ExpoPlaybackService.
 */
public class MemorizeActivity extends Activity {
    public static final String EXTRA_MEMORY_TEXT = "memory_text";

    private static final int REQUEST_RECORD_AUDIO = 201;
    private static final int REQUEST_BT_CONNECT = 202;
    private static final String UTTERANCE_ID = "MEMORY_PHRASE";
    private static final long LISTENING_WINDOW_MS = 45_000L;
    private static final long LISTEN_RESTART_DELAY_MS = 350L;
    private static final long BUSY_RESTART_DELAY_MS = 900L;
    private static final long AUTO_REPLAY_DELAY_MS = 1_600L;
    private static final long AUTO_NEXT_DELAY_MS = 800L;
    private static final long EXAM_NEXT_DELAY_MS = 2_200L;
    private static final long NEXT_ROUND_DELAY_MS = 200L;
    private static final long MIC_START_DELAY_MS = 250L;
    private static final long BT_CONNECT_DELAY_MS = 1_100L;

    private static final String PROGRESS_PREFS = "memorize_progress";
    private static final String PREF_TEXT_HASH = "text_hash";
    private static final String PREF_SELECTED_SECTIONS = "selected_sections";
    private static final String PREF_CURRENT_INDEX = "current_index";
    private static final String PREF_EVALUATED_PHRASES = "evaluated_phrases";
    private static final String PREF_SCORE_SUM = "score_sum";
    private static final String PREF_ACTIVE_PROGRESS = "active_progress";

    private static final String SETTINGS_PREFS = "memorize_settings";
    private static final String S_RATE = "rate";
    private static final String S_PASS = "pass";
    private static final String S_EXAM = "exam";
    private static final String S_BT = "bt_mic";

    private static final float[] RATES = {0.75f, 1.0f, 1.25f, 1.5f};
    private static final String[] RATE_LABELS = {"0.75x", "1x", "1.25x", "1.5x"};
    private static final int[] PASSES = {70, 78, 85};
    private static final String[] PASS_LABELS = {"Suave (70%)", "Normal (78%)", "Exigente (85%)"};

    private static final class PracticePhrase {
        final String sectionTitle;
        final String raw;
        final String spoken;
        final int sectionPhraseIndex;
        final int sectionPhraseTotal;

        PracticePhrase(String sectionTitle, String raw, int sectionPhraseIndex, int sectionPhraseTotal) {
            this.sectionTitle = sectionTitle;
            this.raw = raw;
            this.spoken = TextParser.clean(raw);
            this.sectionPhraseIndex = sectionPhraseIndex;
            this.sectionPhraseTotal = sectionPhraseTotal;
        }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<TextParser.Section> sections = new ArrayList<>();
    private final ArrayList<CheckBox> sectionChecks = new ArrayList<>();
    private final ArrayList<PracticePhrase> phrases = new ArrayList<>();

    private LinearLayout resumePanel;
    private TextView resumeSummary;
    private Button resumeReviewButton;
    private LinearLayout selectionPanel;
    private LinearLayout sectionList;
    private LinearLayout practicePanel;
    private TextView titleText;
    private TextView settingsSummary;
    private TextView selectionStatus;
    private Button reviewButton;
    private Button startSelectedButton;
    private TextView selectAllButton;
    private TextView clearSelectionButton;
    private TextView phraseCounter;
    private ProgressBar progressBar;
    private TextView phraseText;
    private TextView instructionText;
    private TextView heardText;
    private TextView scoreText;
    private TextView missingText;
    private TextView micLevelText;
    private Button actionButton;
    private Button pauseButton;
    private Button listenAgainButton;
    private Button hintButton;
    private Button saidItRightButton;
    private Button previousButton;
    private Button nextButton;

    private TextToSpeech textToSpeech;
    private SpeechRecognizer speechRecognizer;
    private Intent recognitionIntent;
    private boolean recognitionAvailable = false;
    private BtMic btMic;
    private boolean btTriedThisSession = false;

    private SharedPreferences progressPreferences;
    private SharedPreferences settingsPreferences;
    private MemoryStats stats;
    private String sourceTextHash = "";

    private int currentIndex = 0;
    private boolean ttsReady = false;
    private boolean sessionFinished = false;
    private boolean pendingStartAfterPermission = false;
    private boolean recognitionExpected = false;
    private boolean practiceStarted = false;
    private boolean paused = false;
    private boolean reviewMode = false;
    private boolean interruptedByLeaving = false;
    private boolean waitingPermissionDialog = false;
    private int roundToken = 0;
    private String activeUtteranceId = null;
    private int evaluatedPhrases = 0;
    private int scoreSum = 0;
    private int failedInSession = 0;
    private long listeningDeadlineMs = 0L;
    private boolean speechStartedInWindow = false;
    private boolean partialAccepted = false;

    // Estado de la frase actual
    private int hintLevel = 0;
    private int attemptsThisPhrase = 0;
    private boolean struggleRecorded = false;
    private boolean forceReadThisRound = false;
    private boolean phraseHidden = false;

    private final Runnable autoNextRunnable = () -> {
        if (!isFinishing() && practiceStarted && !sessionFinished && !paused) {
            moveToPhrase(currentIndex + 1, true);
        }
    };

    private final Runnable pendingListenRunnable = this::startListeningWindow;

    private final Runnable restartListeningRunnable = this::startListeningCycle;

    private final Runnable listeningWindowTimeoutRunnable = () -> {
        if (!practiceStarted || paused || sessionFinished || isFinishing()) return;
        if (speechStartedInWindow) return;
        cancelCurrentRecognitionOnly();
        listeningDeadlineMs = 0L;
        showRecognitionFailure("No detecté tu voz en 45 segundos. Toca Reintentar cuando estés listo.");
    };

    private final Runnable autoReplayRunnable = () -> {
        if (!isFinishing() && practiceStarted && !sessionFinished && !paused) {
            beginCurrentRound();
        }
    };

    private final Runnable beginRoundRunnable = this::beginCurrentRound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memorize);

        resumePanel = findViewById(R.id.memoryResumePanel);
        resumeSummary = findViewById(R.id.memoryResumeSummary);
        resumeReviewButton = findViewById(R.id.memoryResumeReviewButton);
        selectionPanel = findViewById(R.id.memorySelectionPanel);
        sectionList = findViewById(R.id.memorySectionList);
        practicePanel = findViewById(R.id.memoryPracticePanel);
        titleText = findViewById(R.id.memoryTitle);
        settingsSummary = findViewById(R.id.memorySettingsSummary);
        selectionStatus = findViewById(R.id.memorySelectionStatus);
        reviewButton = findViewById(R.id.memoryReviewButton);
        startSelectedButton = findViewById(R.id.memoryStartSelectedButton);
        selectAllButton = findViewById(R.id.memorySelectAllButton);
        clearSelectionButton = findViewById(R.id.memoryClearSelectionButton);
        phraseCounter = findViewById(R.id.memoryPhraseCounter);
        progressBar = findViewById(R.id.memoryProgressBar);
        phraseText = findViewById(R.id.memoryPhraseText);
        instructionText = findViewById(R.id.memoryInstructionText);
        heardText = findViewById(R.id.memoryHeardText);
        scoreText = findViewById(R.id.memoryScoreText);
        missingText = findViewById(R.id.memoryMissingText);
        micLevelText = findViewById(R.id.memoryMicLevelText);
        actionButton = findViewById(R.id.memoryActionButton);
        pauseButton = findViewById(R.id.memoryPauseButton);
        listenAgainButton = findViewById(R.id.memoryListenAgainButton);
        hintButton = findViewById(R.id.memoryHintButton);
        saidItRightButton = findViewById(R.id.memorySaidItRightButton);
        previousButton = findViewById(R.id.memoryPreviousButton);
        nextButton = findViewById(R.id.memoryNextButton);

        String text = getIntent().getStringExtra(EXTRA_MEMORY_TEXT);
        sourceTextHash = calculateTextHash(text);
        progressPreferences = getSharedPreferences(PROGRESS_PREFS, MODE_PRIVATE);
        settingsPreferences = getSharedPreferences(SETTINGS_PREFS, MODE_PRIVATE);
        stats = new MemoryStats(this, sourceTextHash);
        btMic = new BtMic(this);
        sections.addAll(TextParser.parseSections(text));
        buildSectionSelection();

        selectAllButton.setOnClickListener(v -> setAllSectionsChecked(true));
        clearSelectionButton.setOnClickListener(v -> setAllSectionsChecked(false));
        startSelectedButton.setOnClickListener(v -> startSelectedPractice());
        reviewButton.setOnClickListener(v -> startReview());
        resumeReviewButton.setOnClickListener(v -> startReview());
        findViewById(R.id.memoryChangeSelectionButton).setOnClickListener(v -> showSelectionScreen());
        pauseButton.setOnClickListener(v -> togglePause());
        findViewById(R.id.memoryResumeContinueButton).setOnClickListener(v -> continueSavedPractice());
        findViewById(R.id.memoryResumeChangeSelectionButton).setOnClickListener(v -> showSelectionScreen());
        findViewById(R.id.memoryResumeRestartButton).setOnClickListener(v -> restartSavedPractice());
        findViewById(R.id.memorySettingsButton).setOnClickListener(v -> showSettingsDialog());

        actionButton.setOnClickListener(v -> {
            if (sessionFinished) {
                if (reviewMode) {
                    startReview();
                    return;
                }
                currentIndex = 0;
                evaluatedPhrases = 0;
                scoreSum = 0;
                failedInSession = 0;
                sessionFinished = false;
                paused = false;
                enterPracticeScreen();
                saveProgress();
                beginCurrentRound();
            } else {
                beginCurrentRound();
            }
        });
        listenAgainButton.setOnClickListener(v -> {
            if (isExamMode()) {
                // En examen, escuchar la frase cuenta como ayuda.
                markStruggle();
                forceReadThisRound = true;
            }
            beginCurrentRound();
        });
        hintButton.setOnClickListener(v -> showNextHint());
        saidItRightButton.setOnClickListener(v -> moveToPhrase(currentIndex + 1, true));
        previousButton.setOnClickListener(v -> moveToPhrase(currentIndex - 1, false));
        nextButton.setOnClickListener(v -> moveToPhrase(currentIndex + 1, false));
        findViewById(R.id.memoryCloseButton).setOnClickListener(v -> {
            saveProgress();
            cancelVoiceOperations();
            finish();
        });

        updateSettingsSummary();
        showInitialScreen();
        initializeTextToSpeech();
        buildRecognitionIntent();
    }

    // ================================================================ Ajustes

    private float speechRate() {
        float r = settingsPreferences.getFloat(S_RATE, -1f);
        if (r < 0f) {
            // Compatibilidad: la versión anterior guardaba la velocidad en el progreso.
            r = progressPreferences.getFloat("speech_rate", 1.0f);
        }
        return Math.max(0.5f, Math.min(1.5f, r));
    }

    private int passScore() {
        int p = settingsPreferences.getInt(S_PASS, 78);
        return Math.max(50, Math.min(95, p));
    }

    private boolean isExamMode() {
        return settingsPreferences.getBoolean(S_EXAM, false);
    }

    private boolean useBtMic() {
        return settingsPreferences.getBoolean(S_BT, false);
    }

    private void updateSettingsSummary() {
        String rate = RATE_LABELS[1];
        for (int i = 0; i < RATES.length; i++) {
            if (Math.abs(RATES[i] - speechRate()) < 0.01f) rate = RATE_LABELS[i];
        }
        settingsSummary.setText((isExamMode() ? "Examen" : "Aprender")
                + "  ·  Voz " + rate
                + "  ·  Exigencia " + passScore() + "%"
                + "  ·  Mic: " + (useBtMic() ? "auricular" : "celular"));
    }

    private void showSettingsDialog() {
        String rate = RATE_LABELS[1];
        for (int i = 0; i < RATES.length; i++) {
            if (Math.abs(RATES[i] - speechRate()) < 0.01f) rate = RATE_LABELS[i];
        }
        String[] items = {
                "Modo: " + (isExamMode() ? "Examen (sin leer la frase)" : "Aprender (te lee la frase)"),
                "Velocidad de voz: " + rate,
                "Exigencia: " + passScore() + "%",
                "Micrófono: " + (useBtMic() ? "auricular Bluetooth (beta)" : "del celular"),
                "Borrar historial de frases difíciles"
        };
        new AlertDialog.Builder(this)
                .setTitle("Ajustes de Memorizar")
                .setItems(items, (d, which) -> {
                    if (which == 0) chooseMode();
                    else if (which == 1) chooseRate();
                    else if (which == 2) choosePass();
                    else if (which == 3) chooseMic();
                    else if (which == 4) confirmClearStats();
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void chooseMode() {
        String[] modes = {"Aprender: te lee la frase y la repites", "Examen: la dices de memoria, sin ayuda"};
        new AlertDialog.Builder(this)
                .setTitle("Modo")
                .setSingleChoiceItems(modes, isExamMode() ? 1 : 0, (d, which) -> {
                    settingsPreferences.edit().putBoolean(S_EXAM, which == 1).apply();
                    d.dismiss();
                    updateSettingsSummary();
                    if (practiceStarted && !sessionFinished) {
                        cancelVoiceOperations();
                        prepareCurrentPhrase();
                    }
                })
                .show();
    }

    private void chooseRate() {
        int checked = 1;
        for (int i = 0; i < RATES.length; i++) {
            if (Math.abs(RATES[i] - speechRate()) < 0.01f) checked = i;
        }
        new AlertDialog.Builder(this)
                .setTitle("Velocidad de voz")
                .setSingleChoiceItems(RATE_LABELS, checked, (d, which) -> {
                    settingsPreferences.edit().putFloat(S_RATE, RATES[which]).apply();
                    if (textToSpeech != null && ttsReady) textToSpeech.setSpeechRate(RATES[which]);
                    d.dismiss();
                    updateSettingsSummary();
                })
                .show();
    }

    private void choosePass() {
        int checked = 1;
        for (int i = 0; i < PASSES.length; i++) {
            if (PASSES[i] == passScore()) checked = i;
        }
        new AlertDialog.Builder(this)
                .setTitle("Exigencia para pasar")
                .setSingleChoiceItems(PASS_LABELS, checked, (d, which) -> {
                    settingsPreferences.edit().putInt(S_PASS, PASSES[which]).apply();
                    d.dismiss();
                    updateSettingsSummary();
                })
                .show();
    }

    private void chooseMic() {
        String[] options = {"Micrófono del celular (recomendado)", "Micrófono del auricular Bluetooth (beta)"};
        new AlertDialog.Builder(this)
                .setTitle("Micrófono")
                .setSingleChoiceItems(options, useBtMic() ? 1 : 0, (d, which) -> {
                    d.dismiss();
                    if (which == 1) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                                && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                            waitingPermissionDialog = true;
                            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_BT_CONNECT);
                            return;
                        }
                        settingsPreferences.edit().putBoolean(S_BT, true).apply();
                        btTriedThisSession = false;
                        Toast.makeText(this, "Si tu auricular no lo permite, se usará el micrófono del celular.", Toast.LENGTH_LONG).show();
                    } else {
                        settingsPreferences.edit().putBoolean(S_BT, false).apply();
                        btMic.disable();
                    }
                    updateSettingsSummary();
                })
                .show();
    }

    private void confirmClearStats() {
        new AlertDialog.Builder(this)
                .setTitle("¿Borrar historial?")
                .setMessage("Se olvidarán las frases difíciles y dominadas de esta exposición.")
                .setPositiveButton("Borrar", (d, w) -> {
                    stats.clear();
                    buildSectionSelection();
                    refreshReviewButtons();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ================================================================ Selección

    private void buildSectionSelection() {
        boolean[] previous = new boolean[sectionChecks.size()];
        for (int i = 0; i < sectionChecks.size(); i++) previous[i] = sectionChecks.get(i).isChecked();
        boolean keepPrevious = previous.length == sections.size() && previous.length > 0;

        sectionList.removeAllViews();
        sectionChecks.clear();

        if (sections.isEmpty()) {
            selectionStatus.setText("No hay frases para practicar.");
            startSelectedButton.setEnabled(false);
            return;
        }

        for (int s = 0; s < sections.size(); s++) {
            TextParser.Section section = sections.get(s);
            int mastered = 0;
            int difficult = 0;
            for (String p : section.phrases) {
                String spoken = TextParser.clean(p);
                if (stats.isMastered(spoken)) mastered++;
                if (stats.isDifficult(spoken)) difficult++;
            }
            StringBuilder label = new StringBuilder(section.title);
            label.append("\n").append(section.phrases.size()).append(section.phrases.size() == 1 ? " frase" : " frases");
            if (mastered > 0) label.append("  ·  ✓ ").append(mastered).append("/").append(section.phrases.size());
            if (difficult > 0) label.append("  ·  ").append(difficult).append(difficult == 1 ? " difícil" : " difíciles");

            CheckBox checkBox = new CheckBox(this);
            checkBox.setText(label.toString());
            checkBox.setTextColor(getResources().getColor(R.color.text_main));
            checkBox.setTextSize(15f);
            checkBox.setChecked(keepPrevious ? previous[s] : true);
            checkBox.setPadding(dp(6), dp(8), dp(6), dp(8));
            checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> updateSelectionStatus());

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            sectionList.addView(checkBox, params);
            sectionChecks.add(checkBox);
        }
        updateSelectionStatus();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void setAllSectionsChecked(boolean checked) {
        for (CheckBox checkBox : sectionChecks) checkBox.setChecked(checked);
        updateSelectionStatus();
    }

    private void updateSelectionStatus() {
        int selectedSections = 0;
        int selectedPhrases = 0;
        for (int i = 0; i < sectionChecks.size(); i++) {
            if (sectionChecks.get(i).isChecked()) {
                selectedSections++;
                selectedPhrases += sections.get(i).phrases.size();
            }
        }
        if (selectedSections == 0) {
            selectionStatus.setText("Marca al menos una");
            startSelectedButton.setEnabled(false);
        } else {
            selectionStatus.setText(selectedSections + (selectedSections == 1 ? " diapo · " : " diapos · ")
                    + selectedPhrases + (selectedPhrases == 1 ? " frase" : " frases"));
            startSelectedButton.setEnabled(true);
        }
        refreshReviewButtons();
    }

    private void refreshReviewButtons() {
        int difficult = countDifficultInText();
        String label = "Repasar difíciles (" + difficult + ")";
        reviewButton.setText(label);
        resumeReviewButton.setText(label);
        reviewButton.setVisibility(difficult > 0 ? View.VISIBLE : View.GONE);
        resumeReviewButton.setVisibility(difficult > 0 ? View.VISIBLE : View.GONE);
    }

    private int countDifficultInText() {
        int count = 0;
        for (TextParser.Section s : sections) {
            for (String p : s.phrases) {
                if (stats.isDifficult(TextParser.clean(p))) count++;
            }
        }
        return count;
    }

    private void startSelectedPractice() {
        cancelVoiceOperations();
        reviewMode = false;
        buildPracticePhrasesFromChecks();
        if (phrases.isEmpty()) {
            Toast.makeText(this, "Marca al menos una diapositiva.", Toast.LENGTH_SHORT).show();
            return;
        }
        currentIndex = 0;
        evaluatedPhrases = 0;
        scoreSum = 0;
        failedInSession = 0;
        enterPracticeScreen();
        saveProgress();
    }

    private void startReview() {
        cancelVoiceOperations();
        phrases.clear();
        for (TextParser.Section section : sections) {
            for (int j = 0; j < section.phrases.size(); j++) {
                String raw = section.phrases.get(j);
                if (stats.isDifficult(TextParser.clean(raw))) {
                    phrases.add(new PracticePhrase(section.title, raw, j + 1, section.phrases.size()));
                }
            }
        }
        if (phrases.isEmpty()) {
            Toast.makeText(this, "¡No tienes frases difíciles pendientes!", Toast.LENGTH_SHORT).show();
            reviewMode = false;
            showSelectionScreen();
            return;
        }
        reviewMode = true;
        currentIndex = 0;
        evaluatedPhrases = 0;
        scoreSum = 0;
        failedInSession = 0;
        enterPracticeScreen();
    }

    private void buildPracticePhrasesFromChecks() {
        phrases.clear();
        for (int i = 0; i < sectionChecks.size(); i++) {
            if (!sectionChecks.get(i).isChecked()) continue;
            TextParser.Section section = sections.get(i);
            for (int j = 0; j < section.phrases.size(); j++) {
                String raw = section.phrases.get(j);
                if (TextParser.clean(raw).isEmpty()) continue;
                phrases.add(new PracticePhrase(section.title, raw, j + 1, section.phrases.size()));
            }
        }
    }

    private void enterPracticeScreen() {
        sessionFinished = false;
        practiceStarted = true;
        paused = false;
        interruptedByLeaving = false;
        btTriedThisSession = false;
        titleText.setText(reviewMode ? "Repaso de difíciles" : "Memorizar");
        resumePanel.setVisibility(View.GONE);
        selectionPanel.setVisibility(View.GONE);
        practicePanel.setVisibility(View.VISIBLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prepareCurrentPhrase();
    }

    private void leavePracticeScreen() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        btMic.disable();
    }

    private void showSelectionScreen() {
        saveProgress();
        cancelVoiceOperations();
        leavePracticeScreen();
        practiceStarted = false;
        sessionFinished = false;
        paused = false;
        reviewMode = false;
        titleText.setText("Memorizar");
        phrases.clear();
        buildSectionSelection();
        resumePanel.setVisibility(View.GONE);
        practicePanel.setVisibility(View.GONE);
        selectionPanel.setVisibility(View.VISIBLE);
        updateSelectionStatus();
    }

    private void showInitialScreen() {
        restoreSavedSelection();
        if (hasRestorableProgress() && prepareSavedPracticePhrases()) {
            int savedIndex = progressPreferences.getInt(PREF_CURRENT_INDEX, 0);
            savedIndex = Math.max(0, Math.min(savedIndex, phrases.size() - 1));
            PracticePhrase phrase = phrases.get(savedIndex);
            resumeSummary.setText(phrase.sectionTitle
                    + "\nFrase " + phrase.sectionPhraseIndex + " de " + phrase.sectionPhraseTotal
                    + "  ·  Avance " + (savedIndex + 1) + " de " + phrases.size());
            practiceStarted = false;
            sessionFinished = false;
            paused = false;
            selectionPanel.setVisibility(View.GONE);
            practicePanel.setVisibility(View.GONE);
            resumePanel.setVisibility(View.VISIBLE);
            refreshReviewButtons();
        } else {
            phrases.clear();
            resumePanel.setVisibility(View.GONE);
            practicePanel.setVisibility(View.GONE);
            selectionPanel.setVisibility(View.VISIBLE);
            updateSelectionStatus();
        }
    }

    private void continueSavedPractice() {
        reviewMode = false;
        if (!prepareSavedPracticePhrases()) {
            clearSavedProgress();
            showSelectionScreen();
            return;
        }
        currentIndex = progressPreferences.getInt(PREF_CURRENT_INDEX, 0);
        currentIndex = Math.max(0, Math.min(currentIndex, phrases.size() - 1));
        evaluatedPhrases = Math.max(0, progressPreferences.getInt(PREF_EVALUATED_PHRASES, 0));
        scoreSum = Math.max(0, progressPreferences.getInt(PREF_SCORE_SUM, 0));
        failedInSession = 0;
        enterPracticeScreen();
        instructionText.setText("Sigues donde lo dejaste. Toca Comenzar.");
        saveProgress();
    }

    private void restartSavedPractice() {
        reviewMode = false;
        if (!prepareSavedPracticePhrases()) {
            clearSavedProgress();
            showSelectionScreen();
            return;
        }
        currentIndex = 0;
        evaluatedPhrases = 0;
        scoreSum = 0;
        failedInSession = 0;
        enterPracticeScreen();
        saveProgress();
    }

    private boolean prepareSavedPracticePhrases() {
        if (!applySavedSectionSelection()) return false;
        buildPracticePhrasesFromChecks();
        return !phrases.isEmpty();
    }

    // ================================================================ Voz (TTS)

    private void initializeTextToSpeech() {
        textToSpeech = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                ttsReady = false;
                if (practiceStarted) instructionText.setText("No se pudo iniciar la voz del teléfono.");
                return;
            }

            int result = textToSpeech.setLanguage(new Locale("es", "PE"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                result = textToSpeech.setLanguage(new Locale("es", "ES"));
            }
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                ttsReady = false;
                if (practiceStarted) instructionText.setText("El motor de voz no tiene español instalado.");
                return;
            }

            textToSpeech.setSpeechRate(speechRate());
            textToSpeech.setPitch(1.0f);
            textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onStart(String utteranceId) {
                    if (utteranceId == null || !utteranceId.equals(activeUtteranceId)) return;
                    runOnUiThread(() -> {
                        if (paused || !practiceStarted) return;
                        instructionText.setText("Escucha la frase…");
                        setRoundButtonsEnabled(false);
                    });
                }

                @Override
                public void onDone(String utteranceId) {
                    if (utteranceId == null || !utteranceId.equals(activeUtteranceId)) return;
                    runOnUiThread(() -> {
                        if (sessionFinished || isFinishing() || paused || !practiceStarted) return;
                        hidePhrase();
                        instructionText.setText("Ahora repítela sin mirar.");
                        handler.postDelayed(pendingListenRunnable, MIC_START_DELAY_MS);
                    });
                }

                @Override
                public void onError(String utteranceId) {
                    if (utteranceId == null || !utteranceId.equals(activeUtteranceId)) return;
                    runOnUiThread(() -> {
                        if (paused || !practiceStarted) return;
                        instructionText.setText("No se pudo reproducir la frase. Toca Reintentar.");
                        restoreAfterListening();
                    });
                }
            });
            ttsReady = true;
            if (practiceStarted && !paused && !phrases.isEmpty() && !sessionFinished) {
                actionButton.setEnabled(true);
            }
        });
    }

    private void applyTtsAudioRoute() {
        if (textToSpeech == null) return;
        try {
            int usage = btMic.isActive() ? AudioAttributes.USAGE_VOICE_COMMUNICATION : AudioAttributes.USAGE_MEDIA;
            textToSpeech.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(usage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
        } catch (Exception ignored) {
        }
    }

    // ================================================================ Reconocimiento

    private void buildRecognitionIntent() {
        recognitionAvailable = SpeechRecognizer.isRecognitionAvailable(this);
        recognitionIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE");
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE");
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L);
    }

    /** Crea un reconocedor nuevo en cada intento: evita los errores "ocupado" y "cliente". */
    private void createFreshRecognizer() {
        destroyRecognizer();
        if (!recognitionAvailable) return;
        try {
            SpeechRecognizer recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new Listener(recognizer));
            speechRecognizer = recognizer;
        } catch (Exception e) {
            speechRecognizer = null;
        }
    }

    private void destroyRecognizer() {
        SpeechRecognizer old = speechRecognizer;
        speechRecognizer = null;
        if (old != null) {
            try {
                old.cancel();
            } catch (Exception ignored) {
            }
            try {
                old.destroy();
            } catch (Exception ignored) {
            }
        }
    }

    private final class Listener implements RecognitionListener {
        private final SpeechRecognizer owner;

        Listener(SpeechRecognizer owner) {
            this.owner = owner;
        }

        private boolean ignore() {
            return owner != speechRecognizer || !recognitionExpected || paused || !practiceStarted || isFinishing();
        }

        @Override
        public void onReadyForSpeech(Bundle params) {
            if (ignore()) return;
            micLevelText.setVisibility(View.VISIBLE);
            micLevelText.setText("● Te escucho");
            actionButton.setText("Escuchando…");
        }

        @Override
        public void onBeginningOfSpeech() {
            if (ignore()) return;
            speechStartedInWindow = true;
            handler.removeCallbacks(listeningWindowTimeoutRunnable);
        }

        @Override
        public void onRmsChanged(float rmsdB) {
            if (ignore()) return;
            int bars = Math.max(1, Math.min(8, Math.round((rmsdB + 2f) / 2f)));
            StringBuilder level = new StringBuilder("● ");
            for (int i = 0; i < bars; i++) level.append("▮");
            micLevelText.setText(level.toString());
        }

        @Override
        public void onBufferReceived(byte[] buffer) {
        }

        @Override
        public void onEndOfSpeech() {
            if (ignore()) return;
            micLevelText.setText("Comparando…");
        }

        @Override
        public void onError(int error) {
            if (ignore()) return;
            recognitionExpected = false;
            micLevelText.setVisibility(View.GONE);

            if (partialAccepted && error == SpeechRecognizer.ERROR_NO_MATCH) {
                // Ya aceptado por resultado parcial.
                return;
            }

            boolean silenceError = error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    || (error == SpeechRecognizer.ERROR_NO_MATCH && !speechStartedInWindow);

            if (silenceError && hasListeningTimeRemaining()) {
                scheduleListeningRestart(LISTEN_RESTART_DELAY_MS);
                return;
            }

            boolean busyOrClient = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY
                    || error == SpeechRecognizer.ERROR_CLIENT;
            if (busyOrClient && hasListeningTimeRemaining()) {
                scheduleListeningRestart(BUSY_RESTART_DELAY_MS);
                return;
            }

            handler.removeCallbacks(listeningWindowTimeoutRunnable);
            listeningDeadlineMs = 0L;

            if (error == SpeechRecognizer.ERROR_NO_MATCH && speechStartedInWindow) {
                handleFailedAttempt(null, "No entendí bien. Otra vez.");
                return;
            }

            String message;
            switch (error) {
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                    message = "No detecté tu voz. Toca Reintentar.";
                    break;
                case SpeechRecognizer.ERROR_AUDIO:
                    message = "Problema con el micrófono. Toca Reintentar.";
                    break;
                case SpeechRecognizer.ERROR_NETWORK:
                case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                    message = "Sin conexión para reconocer la voz. Revisa internet o descarga el español sin conexión en Google.";
                    break;
                case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                    message = "Falta el permiso del micrófono.";
                    break;
                default:
                    message = "No pude reconocer tu voz. Toca Reintentar.";
                    break;
            }
            showRecognitionFailure(message);
        }

        @Override
        public void onResults(Bundle results) {
            if (owner != speechRecognizer || paused || !practiceStarted || isFinishing()) return;
            if (!recognitionExpected && !partialAccepted) return;
            recognitionExpected = false;
            clearListeningWindowState();
            micLevelText.setVisibility(View.GONE);
            ArrayList<String> candidates = results == null ? null
                    : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            evaluateCandidates(candidates);
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
            if (ignore() || partialAccepted || phrases.isEmpty()) return;
            ArrayList<String> partial = partialResults == null ? null
                    : partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (partial == null || partial.isEmpty() || partial.get(0) == null) return;
            String heard = partial.get(0).trim();
            if (heard.isEmpty()) return;
            heardText.setVisibility(View.VISIBLE);
            heardText.setText("… " + heard);
            PhraseMatcher.Result r = PhraseMatcher.compare(phrases.get(currentIndex).spoken, heard, passScore());
            if (r.passed && r.missing.isEmpty()) {
                // Ya lo dijiste completo: terminar la escucha para avanzar más rápido.
                partialAccepted = true;
                try {
                    owner.stopListening();
                } catch (Exception ignored) {
                }
            }
        }

        @Override
        public void onEvent(int eventType, Bundle params) {
        }
    }

    // ================================================================ Rondas

    private void beginCurrentRound() {
        handler.removeCallbacks(autoNextRunnable);
        handler.removeCallbacks(beginRoundRunnable);
        if (!practiceStarted || paused || phrases.isEmpty() || sessionFinished) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingStartAfterPermission = true;
            waitingPermissionDialog = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
            return;
        }
        if (!recognitionAvailable) {
            showRecognitionFailure("Este teléfono no tiene reconocimiento de voz (instala o activa Google).");
            return;
        }

        // Micrófono Bluetooth (opcional): conectar antes de hablar.
        if (useBtMic() && !btMic.isActive() && !btTriedThisSession) {
            btTriedThisSession = true;
            if (btMic.enable()) {
                instructionText.setText("Conectando el micrófono del auricular…");
                setRoundButtonsEnabled(false);
                handler.postDelayed(beginRoundRunnable, BT_CONNECT_DELAY_MS);
                return;
            } else {
                Toast.makeText(this, "No encontré auricular Bluetooth: uso el micrófono del celular.", Toast.LENGTH_SHORT).show();
            }
        }

        boolean exam = isExamMode() && !forceReadThisRound;
        forceReadThisRound = false;

        if (!exam && !ttsReady) {
            Toast.makeText(this, "La voz todavía se está preparando.", Toast.LENGTH_SHORT).show();
            return;
        }

        cancelVoiceOperations();
        clearEvaluation();
        PracticePhrase phrase = phrases.get(currentIndex);
        setRoundButtonsEnabled(false);
        saidItRightButton.setEnabled(attemptsThisPhrase > 0);

        if (exam) {
            hidePhrase();
            instructionText.setText("Examen: dila de memoria.");
            handler.postDelayed(pendingListenRunnable, MIC_START_DELAY_MS);
            return;
        }

        phraseHidden = false;
        phraseText.setText(html(phrase.raw));
        instructionText.setText("Escucha la frase…");
        actionButton.setText("Escucha…");

        roundToken++;
        activeUtteranceId = UTTERANCE_ID + "_" + roundToken;
        applyTtsAudioRoute();
        textToSpeech.setSpeechRate(speechRate());
        int speakResult = textToSpeech.speak(phrase.spoken, TextToSpeech.QUEUE_FLUSH, new Bundle(), activeUtteranceId);
        if (speakResult == TextToSpeech.ERROR) {
            instructionText.setText("No se pudo reproducir la frase. Toca Reintentar.");
            restoreAfterListening();
        }
    }

    private void setRoundButtonsEnabled(boolean enabled) {
        actionButton.setEnabled(enabled && !paused);
        listenAgainButton.setEnabled(enabled && !paused);
    }

    private void hidePhrase() {
        phraseHidden = true;
        showHintText();
    }

    private void showHintText() {
        if (phrases.isEmpty()) return;
        String spoken = phrases.get(currentIndex).spoken;
        if (hintLevel <= 0) {
            phraseText.setText("🎤  Tu turno");
        } else {
            phraseText.setText(hintFor(spoken, hintLevel));
        }
    }

    /** Pistas progresivas: rayas → primeras letras → primeras palabras → frase completa. */
    private static String hintFor(String spoken, int level) {
        String[] words = spoken.trim().split("\\s+");
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            String w = words[i];
            if (i > 0) b.append(' ');
            if (level >= 4 || (level == 3 && i < 3)) {
                b.append(w);
            } else if (level >= 2) {
                int letters = 0;
                StringBuilder masked = new StringBuilder();
                for (int k = 0; k < w.length(); k++) {
                    char c = w.charAt(k);
                    if (Character.isLetterOrDigit(c)) {
                        masked.append(letters == 0 ? c : '_');
                        letters++;
                    } else {
                        masked.append(c);
                    }
                }
                b.append(masked);
            } else {
                for (int k = 0; k < w.length(); k++) {
                    b.append(Character.isLetterOrDigit(w.charAt(k)) ? '_' : w.charAt(k));
                }
            }
        }
        return b.toString();
    }

    private void showNextHint() {
        if (!practiceStarted || sessionFinished || phrases.isEmpty()) return;
        if (hintLevel < 4) hintLevel++;
        markStruggle();
        if (phraseHidden) {
            showHintText();
        } else {
            phraseText.setText(hintFor(phrases.get(currentIndex).spoken, hintLevel));
        }
        String[] names = {"", "Pista: número de palabras", "Pista: primeras letras", "Pista: primeras palabras", "Frase completa"};
        instructionText.setText(names[hintLevel]);
    }

    private void markStruggle() {
        if (phrases.isEmpty() || struggleRecorded) return;
        struggleRecorded = true;
        stats.recordStruggle(phrases.get(currentIndex).spoken);
    }

    private void startListeningWindow() {
        if (!practiceStarted || paused || sessionFinished || isFinishing()) return;
        listeningDeadlineMs = SystemClock.elapsedRealtime() + LISTENING_WINDOW_MS;
        speechStartedInWindow = false;
        handler.removeCallbacks(restartListeningRunnable);
        handler.removeCallbacks(listeningWindowTimeoutRunnable);
        handler.postDelayed(listeningWindowTimeoutRunnable, LISTENING_WINDOW_MS);
        startListeningCycle();
    }

    private void startListeningCycle() {
        if (!practiceStarted || paused || sessionFinished || isFinishing()) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            clearListeningWindowState();
            showRecognitionFailure("Falta el permiso del micrófono.");
            return;
        }
        if (!hasListeningTimeRemaining() && !speechStartedInWindow) {
            listeningWindowTimeoutRunnable.run();
            return;
        }

        createFreshRecognizer();
        if (speechRecognizer == null) {
            clearListeningWindowState();
            showRecognitionFailure("No se pudo activar el reconocimiento de voz. Toca Reintentar.");
            return;
        }

        try {
            recognitionExpected = true;
            partialAccepted = false;
            actionButton.setText("Escuchando…");
            actionButton.setEnabled(false);
            micLevelText.setVisibility(View.VISIBLE);
            micLevelText.setText("● Preparando micrófono…");
            speechRecognizer.startListening(recognitionIntent);
        } catch (Exception error) {
            recognitionExpected = false;
            if (hasListeningTimeRemaining()) {
                scheduleListeningRestart(BUSY_RESTART_DELAY_MS);
            } else {
                clearListeningWindowState();
                showRecognitionFailure("No se pudo activar el micrófono. Toca Reintentar.");
            }
        }
    }

    private boolean hasListeningTimeRemaining() {
        return listeningDeadlineMs > SystemClock.elapsedRealtime();
    }

    private void scheduleListeningRestart(long delayMs) {
        if (!practiceStarted || paused || sessionFinished || isFinishing()) return;
        long remaining = listeningDeadlineMs - SystemClock.elapsedRealtime();
        if (remaining <= 0L) {
            listeningWindowTimeoutRunnable.run();
            return;
        }
        micLevelText.setVisibility(View.VISIBLE);
        micLevelText.setText("● Esperando tu voz…");
        actionButton.setText("Escuchando…");
        actionButton.setEnabled(false);
        handler.removeCallbacks(restartListeningRunnable);
        handler.postDelayed(restartListeningRunnable, Math.min(delayMs, remaining));
    }

    private void clearListeningWindowState() {
        handler.removeCallbacks(restartListeningRunnable);
        handler.removeCallbacks(listeningWindowTimeoutRunnable);
        listeningDeadlineMs = 0L;
        speechStartedInWindow = false;
        recognitionExpected = false;
    }

    private void cancelCurrentRecognitionOnly() {
        recognitionExpected = false;
        destroyRecognizer();
        if (micLevelText != null) micLevelText.setVisibility(View.GONE);
    }

    // ================================================================ Evaluación

    private void evaluateCandidates(ArrayList<String> candidates) {
        if (!practiceStarted || paused || phrases.isEmpty()) return;
        partialAccepted = false;
        if (candidates == null || candidates.isEmpty()) {
            handleFailedAttempt(null, "No entendí bien. Otra vez.");
            return;
        }

        PracticePhrase phrase = phrases.get(currentIndex);
        PhraseMatcher.Result best = null;
        String bestCandidate = candidates.get(0);
        for (String candidate : candidates) {
            if (candidate == null) continue;
            PhraseMatcher.Result r = PhraseMatcher.compare(phrase.spoken, candidate, passScore());
            if (best == null || r.score > best.score || (r.passed && !best.passed)) {
                best = r;
                bestCandidate = candidate;
            }
        }
        if (best == null) {
            handleFailedAttempt(null, "No entendí bien. Otra vez.");
            return;
        }

        attemptsThisPhrase++;
        evaluatedPhrases++;
        scoreSum += best.score;

        phraseHidden = false;
        phraseText.setText(html(phrase.raw));
        heardText.setVisibility(View.VISIBLE);
        heardText.setText("Entendí: «" + bestCandidate + "»");
        scoreText.setVisibility(View.VISIBLE);
        showMissing(best.missing);
        actionButton.setText("Reintentar");
        actionButton.setEnabled(true);
        listenAgainButton.setEnabled(true);
        saidItRightButton.setEnabled(true);

        if (best.passed) {
            scoreText.setTextColor(getResources().getColor(R.color.ok_green));
            scoreText.setText("✓ " + best.score + "%");
            if (!struggleRecorded && attemptsThisPhrase == 1 && hintLevel == 0) {
                stats.recordClean(phrase.spoken);
            }
            instructionText.setText("¡Bien! Siguiente…");
            handler.postDelayed(autoNextRunnable, isExamMode() ? EXAM_NEXT_DELAY_MS : AUTO_NEXT_DELAY_MS);
        } else {
            scoreText.setTextColor(getResources().getColor(R.color.warn_red));
            scoreText.setText("✗ " + best.score + "%");
            handleFailedAttempt(best, null);
        }
    }

    private void showMissing(List<String> missing) {
        if (missing == null || missing.isEmpty()) {
            missingText.setVisibility(View.GONE);
            return;
        }
        StringBuilder b = new StringBuilder("Faltó: ");
        int shown = Math.min(8, missing.size());
        for (int i = 0; i < shown; i++) {
            if (i > 0) b.append(", ");
            b.append(missing.get(i));
        }
        if (missing.size() > shown) b.append("…");
        missingText.setText(b.toString());
        missingText.setVisibility(View.VISIBLE);
    }

    /** Intento fallido: en Aprender vuelve a leer la frase; en Examen pasa a la siguiente. */
    private void handleFailedAttempt(PhraseMatcher.Result result, String message) {
        clearListeningWindowState();
        markStruggle();
        if (!phrases.isEmpty()) {
            phraseHidden = false;
            phraseText.setText(html(phrases.get(currentIndex).raw));
        }
        if (result == null) {
            heardText.setVisibility(View.VISIBLE);
            heardText.setText("No se pudo evaluar este intento.");
            scoreText.setVisibility(View.GONE);
        }
        restoreAfterListening();
        saidItRightButton.setEnabled(true);

        if (isExamMode()) {
            failedInSession++;
            instructionText.setText(message != null ? message : "Anotada para repasar. Siguiente…");
            handler.removeCallbacks(autoNextRunnable);
            handler.postDelayed(autoNextRunnable, EXAM_NEXT_DELAY_MS);
        } else {
            instructionText.setText(message != null ? message
                    : "Te faltó una parte. La escucharás otra vez. Si la dijiste bien, toca ✓ Bien.");
            handler.removeCallbacks(autoReplayRunnable);
            handler.postDelayed(autoReplayRunnable, AUTO_REPLAY_DELAY_MS);
        }
    }

    private void showRecognitionFailure(String message) {
        clearListeningWindowState();
        if (!phrases.isEmpty()) {
            phraseHidden = false;
            phraseText.setText(html(phrases.get(currentIndex).raw));
        }
        instructionText.setText(message);
        heardText.setVisibility(View.GONE);
        scoreText.setVisibility(View.GONE);
        restoreAfterListening();
        saidItRightButton.setEnabled(true);
    }

    private void restoreAfterListening() {
        micLevelText.setVisibility(View.GONE);
        actionButton.setText("Reintentar");
        actionButton.setEnabled(!paused);
        listenAgainButton.setEnabled(!paused);
    }

    private CharSequence html(String raw) {
        String h = TextParser.toHtml(raw);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return Html.fromHtml(h, Html.FROM_HTML_MODE_LEGACY);
        }
        //noinspection deprecation
        return Html.fromHtml(h);
    }

    // ================================================================ Navegación

    private void moveToPhrase(int newIndex, boolean fromResult) {
        if (!practiceStarted || paused) return;
        handler.removeCallbacks(autoNextRunnable);
        cancelVoiceOperations();

        if (newIndex >= phrases.size()) {
            finishSession();
            return;
        }
        if (newIndex < 0) newIndex = 0;

        currentIndex = newIndex;
        sessionFinished = false;
        prepareCurrentPhrase();
        saveProgress();
        if (fromResult) {
            handler.postDelayed(beginRoundRunnable, NEXT_ROUND_DELAY_MS);
        }
    }

    private void prepareCurrentPhrase() {
        if (phrases.isEmpty()) return;
        PracticePhrase phrase = phrases.get(currentIndex);
        hintLevel = 0;
        attemptsThisPhrase = 0;
        struggleRecorded = false;
        forceReadThisRound = false;
        phraseHidden = false;
        clearEvaluation();
        phraseCounter.setText(phrase.sectionTitle
                + "  ·  Frase " + phrase.sectionPhraseIndex + "/" + phrase.sectionPhraseTotal
                + "  ·  " + (currentIndex + 1) + " de " + phrases.size());
        progressBar.setProgress(Math.round(1000f * currentIndex / Math.max(1, phrases.size())));
        if (isExamMode()) {
            phraseHidden = true;
            phraseText.setText("🎤  Frase " + phrase.sectionPhraseIndex + " de " + phrase.sectionTitle);
            instructionText.setText("Examen: toca Comenzar y dila de memoria.");
        } else {
            phraseText.setText(html(phrase.raw));
            instructionText.setText("Toca Comenzar: la escuchas y luego la repites sin verla.");
        }
        actionButton.setText("Comenzar");
        actionButton.setEnabled((ttsReady || isExamMode()) && !paused);
        pauseButton.setText(paused ? "Seguir" : "Pausa");
        pauseButton.setEnabled(true);
        listenAgainButton.setEnabled(!paused);
        hintButton.setEnabled(!paused);
        saidItRightButton.setEnabled(false);
        previousButton.setEnabled(!paused && currentIndex > 0);
        nextButton.setEnabled(!paused && currentIndex < phrases.size() - 1);
    }

    private void togglePause() {
        if (!practiceStarted || sessionFinished || phrases.isEmpty()) return;

        if (!paused) {
            paused = true;
            cancelVoiceOperations();
            phraseHidden = false;
            phraseText.setText(html(phrases.get(currentIndex).raw));
            instructionText.setText("En pausa. Tu avance quedó guardado.");
            pauseButton.setText("Seguir");
            actionButton.setEnabled(false);
            listenAgainButton.setEnabled(false);
            hintButton.setEnabled(false);
            saidItRightButton.setEnabled(false);
            previousButton.setEnabled(false);
            nextButton.setEnabled(false);
            saveProgress();
        } else {
            paused = false;
            pauseButton.setText("Pausa");
            prepareCurrentPhrase();
            instructionText.setText("Continuando…");
            saveProgress();
            handler.postDelayed(beginRoundRunnable, NEXT_ROUND_DELAY_MS);
        }
    }

    private void finishSession() {
        sessionFinished = true;
        paused = false;
        cancelVoiceOperations();
        leavePracticeScreen();
        phraseCounter.setText(reviewMode ? "Repaso terminado" : "Práctica terminada");
        progressBar.setProgress(1000);
        phraseText.setText("¡Completaste todas las frases!");
        int average = evaluatedPhrases > 0 ? Math.round((float) scoreSum / evaluatedPhrases) : 0;
        StringBuilder summary = new StringBuilder();
        if (evaluatedPhrases > 0) summary.append("Promedio: ").append(average).append("%");
        int difficult = countDifficultInText();
        if (difficult > 0) {
            if (summary.length() > 0) summary.append("  ·  ");
            summary.append(difficult).append(difficult == 1 ? " frase por repasar" : " frases por repasar");
        }
        instructionText.setText(summary.length() > 0 ? summary.toString() : "Puedes practicar otra vez.");
        heardText.setVisibility(View.GONE);
        scoreText.setVisibility(View.GONE);
        missingText.setVisibility(View.GONE);
        micLevelText.setVisibility(View.GONE);
        actionButton.setText(reviewMode ? "Repasar otra vez" : "Practicar de nuevo");
        actionButton.setEnabled(true);
        pauseButton.setText("Pausa");
        pauseButton.setEnabled(false);
        listenAgainButton.setEnabled(false);
        hintButton.setEnabled(false);
        saidItRightButton.setEnabled(false);
        previousButton.setEnabled(false);
        nextButton.setEnabled(false);
        if (!reviewMode) markProgressCompleted();
    }

    private void clearEvaluation() {
        heardText.setText("");
        heardText.setVisibility(View.GONE);
        scoreText.setText("");
        scoreText.setVisibility(View.GONE);
        missingText.setText("");
        missingText.setVisibility(View.GONE);
        micLevelText.setVisibility(View.GONE);
    }

    private void cancelVoiceOperations() {
        handler.removeCallbacks(autoNextRunnable);
        handler.removeCallbacks(pendingListenRunnable);
        handler.removeCallbacks(beginRoundRunnable);
        handler.removeCallbacks(restartListeningRunnable);
        handler.removeCallbacks(listeningWindowTimeoutRunnable);
        handler.removeCallbacks(autoReplayRunnable);
        activeUtteranceId = null;
        listeningDeadlineMs = 0L;
        speechStartedInWindow = false;
        recognitionExpected = false;
        partialAccepted = false;
        if (textToSpeech != null) textToSpeech.stop();
        destroyRecognizer();
        if (micLevelText != null) micLevelText.setVisibility(View.GONE);
    }

    // ================================================================ Permisos y ciclo de vida

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        waitingPermissionDialog = false;
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;

        if (requestCode == REQUEST_BT_CONNECT) {
            settingsPreferences.edit().putBoolean(S_BT, granted).apply();
            btTriedThisSession = false;
            updateSettingsSummary();
            if (!granted) {
                Toast.makeText(this, "Sin permiso de Bluetooth se usa el micrófono del celular.", Toast.LENGTH_LONG).show();
            }
            return;
        }

        if (requestCode != REQUEST_RECORD_AUDIO) return;
        if (granted && pendingStartAfterPermission) {
            pendingStartAfterPermission = false;
            if (!paused && practiceStarted) handler.postDelayed(beginRoundRunnable, NEXT_ROUND_DELAY_MS);
        } else {
            pendingStartAfterPermission = false;
            if (practiceStarted) {
                instructionText.setText("Sin permiso de micrófono no puedo comprobar lo que repites.");
                saidItRightButton.setEnabled(true);
            }
        }
    }

    @Override
    protected void onPause() {
        saveProgress();
        super.onPause();
        if (waitingPermissionDialog || pendingStartAfterPermission) return;
        if (!practiceStarted || paused || sessionFinished) return;

        cancelVoiceOperations();
        btMic.disable();
        interruptedByLeaving = true;
        if (!phrases.isEmpty()) {
            phraseHidden = false;
            phraseText.setText(html(phrases.get(currentIndex).raw));
            instructionText.setText("Se detuvo al salir. Continuará al volver.");
            restoreAfterListening();
            saidItRightButton.setEnabled(true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (interruptedByLeaving && practiceStarted && !paused && !sessionFinished && !phrases.isEmpty()) {
            interruptedByLeaving = false;
            btTriedThisSession = false;
            instructionText.setText("Continuando…");
            handler.removeCallbacks(beginRoundRunnable);
            handler.postDelayed(beginRoundRunnable, 700L);
        }
    }

    @Override
    protected void onDestroy() {
        saveProgress();
        handler.removeCallbacksAndMessages(null);
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        destroyRecognizer();
        btMic.disable();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        saveProgress();
        cancelVoiceOperations();
        super.onBackPressed();
    }

    // ================================================================ Progreso guardado

    private void restoreSavedSelection() {
        String savedHash = progressPreferences.getString(PREF_TEXT_HASH, "");
        if (!sourceTextHash.equals(savedHash)) {
            clearSavedProgress();
            return;
        }
        applySavedSectionSelection();
    }

    private boolean hasRestorableProgress() {
        if (progressPreferences == null || sourceTextHash.isEmpty()) return false;
        return progressPreferences.getBoolean(PREF_ACTIVE_PROGRESS, false)
                && sourceTextHash.equals(progressPreferences.getString(PREF_TEXT_HASH, ""))
                && !progressPreferences.getString(PREF_SELECTED_SECTIONS, "").isEmpty();
    }

    private boolean applySavedSectionSelection() {
        if (progressPreferences == null) return false;
        if (!sourceTextHash.equals(progressPreferences.getString(PREF_TEXT_HASH, ""))) return false;

        String encoded = progressPreferences.getString(PREF_SELECTED_SECTIONS, "");
        if (encoded == null || encoded.isEmpty()) return false;

        boolean[] selected = new boolean[sectionChecks.size()];
        int validCount = 0;
        for (String part : encoded.split(",")) {
            try {
                int index = Integer.parseInt(part.trim());
                if (index >= 0 && index < selected.length && !selected[index]) {
                    selected[index] = true;
                    validCount++;
                }
            } catch (NumberFormatException ignored) {
            }
        }
        if (validCount == 0) return false;

        for (int i = 0; i < sectionChecks.size(); i++) {
            sectionChecks.get(i).setChecked(selected[i]);
        }
        updateSelectionStatus();
        return true;
    }

    private String encodeSelectedSections() {
        StringBuilder encoded = new StringBuilder();
        for (int i = 0; i < sectionChecks.size(); i++) {
            if (!sectionChecks.get(i).isChecked()) continue;
            if (encoded.length() > 0) encoded.append(',');
            encoded.append(i);
        }
        return encoded.toString();
    }

    private void saveProgress() {
        if (progressPreferences == null || sourceTextHash.isEmpty()) return;
        if (!practiceStarted || phrases.isEmpty() || sessionFinished || reviewMode) return;

        String selected = encodeSelectedSections();
        if (selected.isEmpty()) return;

        progressPreferences.edit()
                .putString(PREF_TEXT_HASH, sourceTextHash)
                .putString(PREF_SELECTED_SECTIONS, selected)
                .putInt(PREF_CURRENT_INDEX, Math.max(0, Math.min(currentIndex, phrases.size() - 1)))
                .putInt(PREF_EVALUATED_PHRASES, Math.max(0, evaluatedPhrases))
                .putInt(PREF_SCORE_SUM, Math.max(0, scoreSum))
                .putBoolean(PREF_ACTIVE_PROGRESS, true)
                .apply();
    }

    private void markProgressCompleted() {
        if (progressPreferences == null) return;
        progressPreferences.edit()
                .putBoolean(PREF_ACTIVE_PROGRESS, false)
                .putInt(PREF_CURRENT_INDEX, 0)
                .putInt(PREF_EVALUATED_PHRASES, 0)
                .putInt(PREF_SCORE_SUM, 0)
                .apply();
    }

    private void clearSavedProgress() {
        if (progressPreferences == null) return;
        float oldRate = progressPreferences.getFloat("speech_rate", -1f);
        progressPreferences.edit().clear().apply();
        if (oldRate > 0f && settingsPreferences != null && !settingsPreferences.contains(S_RATE)) {
            settingsPreferences.edit().putFloat(S_RATE, oldRate).apply();
        }
    }

    private static String calculateTextHash(String text) {
        String value = text == null ? "" : text.replace("\r\n", "\n").replace('\r', '\n').trim();
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder hash = new StringBuilder();
            for (byte item : bytes) hash.append(String.format(Locale.US, "%02x", item));
            return hash.toString();
        } catch (Exception ignored) {
            return value.length() + ":" + value.hashCode();
        }
    }
}
