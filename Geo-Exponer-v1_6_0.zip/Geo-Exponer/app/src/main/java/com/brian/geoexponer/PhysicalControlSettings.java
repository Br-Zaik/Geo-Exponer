package com.brian.geoexponer;

import android.content.Context;
import android.content.SharedPreferences;

final class PhysicalControlSettings {
    static final String PREFS_NAME = "geo_exponer_prefs";
    static final String KEY_CONFIGURED = "physical_pause_configured";
    static final String KEY_MODE = "physical_pause_mode";

    static final int MODE_DISABLED = 0;
    static final int MODE_VOLUME = 1;
    static final int MODE_SCREEN = 2;
    static final int MODE_VOLUME_AND_SCREEN = 3;
    /** Volumen también con la pantalla apagada (celular en el bolsillo). */
    static final int MODE_POCKET_VOLUME = 4;
    static final int MODE_POCKET_VOLUME_AND_SCREEN = 5;

    static final String[] LABELS = {
            "Desactivado",
            "Botones de volumen (pantalla encendida)",
            "Encender/apagar pantalla (power)",
            "Volumen + power",
            "Volumen en el bolsillo (pantalla apagada)",
            "Volumen en el bolsillo + power"
    };

    private PhysicalControlSettings() {
    }

    static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    static boolean isConfigured(Context context) {
        return preferences(context).getBoolean(KEY_CONFIGURED, false);
    }

    static int getMode(Context context) {
        int mode = preferences(context).getInt(KEY_MODE, MODE_DISABLED);
        if (mode < MODE_DISABLED || mode > MODE_POCKET_VOLUME_AND_SCREEN) return MODE_DISABLED;
        return mode;
    }

    static void saveMode(Context context, int mode) {
        preferences(context).edit()
                .putBoolean(KEY_CONFIGURED, true)
                .putInt(KEY_MODE, mode)
                .apply();
    }

    /** Volumen capturado por la pantalla (solo con la app abierta). */
    static boolean usesVolume(int mode) {
        return mode == MODE_VOLUME || mode == MODE_VOLUME_AND_SCREEN;
    }

    /** Volumen capturado por el servicio (funciona con pantalla apagada). */
    static boolean usesPocketVolume(int mode) {
        return mode == MODE_POCKET_VOLUME || mode == MODE_POCKET_VOLUME_AND_SCREEN;
    }

    static boolean usesScreen(int mode) {
        return mode == MODE_SCREEN || mode == MODE_VOLUME_AND_SCREEN || mode == MODE_POCKET_VOLUME_AND_SCREEN;
    }
}
