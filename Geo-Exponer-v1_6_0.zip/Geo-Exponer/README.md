# Geo Exponer 1.6.0

App Android (Java, sin librerías extra) para practicar exposiciones con auriculares.

## Pestañas
- Exponer: la app te dice la frase y tú la repites. Sin micrófono.
- Textos: varias exposiciones guardadas (Nueva, Pegar, Opciones).
- Memorizar: con micrófono, te evalúa frase por frase.

## Formato del texto
Diapo 1. Portada.
Buenos días ingeniero, compañeros.

Diapo 2. Comunicación del peligro.
El *IPERC* identifica peligros y riesgos.

- Los títulos "Diapo N" y "Frase final" ya NO se leen en voz alta.
- *palabra* = palabra clave (se ve resaltada).
- También puedes compartir texto desde otra app hacia Geo Exponer.

## Exponer (novedades)
- Botón grande ▶/⏸, ◀ ▶ para frase anterior/siguiente.
- Mantén presionado ◀ o ▶ = saltar diapositiva completa.
- Pausa inteligente: espera según lo que dura cada frase.
- Pitido / vibración / voz "Diapositiva N" al cambiar de diapositiva.
- Cronómetro y tiempo objetivo (aviso 1 minuto antes y al cumplir).
- Modo pista: solo lee las primeras 3 palabras (Repetir lee la frase completa).
- Auricular: 2 toques = siguiente, 3 = repetir (opcional, en ⚙).
- Modo bolsillo: pantalla negra, mantener presionado para salir.
- Controles físicos (⚙): nuevo "Volumen en el bolsillo" funciona con la
  pantalla apagada. Ajusta el volumen ANTES de iniciar: durante la práctica
  los botones de volumen solo pausan/continúan. Depende del teléfono.
- Controles que ya funcionaban se conservan: volumen, power, asistente y
  botón del auricular.

## Memorizar (novedades)
- Ya no se corta al apagarse la pantalla: la pantalla queda encendida y, si sales
  y vuelves, continúa solo.
- Resultado en vivo mientras hablas; avanza apenas dices la frase completa.
- Comparación mejorada: tildes, números ("20" = "veinte"), muletillas y errores
  pequeños del reconocedor. Muestra las palabras que faltaron.
- Pistas en 4 niveles: rayas, primeras letras, primeras palabras, frase completa.
- Frases difíciles: se guardan y puedes "Repasar difíciles".
- Dominio por diapositiva (✓ 3/5).
- Modo Examen: no te lee la frase, la dices de memoria.
- Exigencia 70 / 78 / 85 %.
- Micrófono del auricular Bluetooth (beta): no todos los auriculares lo permiten.

## Preparar el celular
⚙ > Preparar mi celular: permiso de batería y pasos según la marca.

## Compilar
Igual que antes (Gradle, compileSdk 35, minSdk 23). versionCode 160.
