package com.brian.geoexponer;

import android.content.Context;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.Build;

import java.util.List;

/**
 * Usa el micrófono del auricular Bluetooth para el reconocimiento de voz (experimental).
 * Android 12+: setCommunicationDevice. Android 11 o menos: Bluetooth SCO.
 * No todos los teléfonos/auriculares lo permiten; si falla, se usa el micrófono del celular.
 */
final class BtMic {
    private final AudioManager audioManager;
    private boolean active = false;
    private int previousMode = AudioManager.MODE_NORMAL;

    BtMic(Context context) {
        audioManager = (AudioManager) context.getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
    }

    boolean isActive() {
        return active;
    }

    /** @return true si se encontró un auricular Bluetooth y se activó su micrófono. */
    @SuppressWarnings("deprecation")
    boolean enable() {
        if (audioManager == null) return false;
        if (active) return true;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                List<AudioDeviceInfo> devices = audioManager.getAvailableCommunicationDevices();
                AudioDeviceInfo target = null;
                for (AudioDeviceInfo d : devices) {
                    int t = d.getType();
                    if (t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || t == AudioDeviceInfo.TYPE_BLE_HEADSET) {
                        target = d;
                        break;
                    }
                }
                if (target == null) return false;
                previousMode = audioManager.getMode();
                audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                active = audioManager.setCommunicationDevice(target);
                if (!active) audioManager.setMode(previousMode);
                return active;
            } else {
                if (!audioManager.isBluetoothScoAvailableOffCall()) return false;
                previousMode = audioManager.getMode();
                audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                audioManager.startBluetoothSco();
                audioManager.setBluetoothScoOn(true);
                active = true;
                return true;
            }
        } catch (Exception e) {
            disable();
            return false;
        }
    }

    @SuppressWarnings("deprecation")
    void disable() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                audioManager.clearCommunicationDevice();
            } else {
                audioManager.setBluetoothScoOn(false);
                audioManager.stopBluetoothSco();
            }
        } catch (Exception ignored) {
        }
        try {
            if (active) audioManager.setMode(previousMode == AudioManager.MODE_IN_COMMUNICATION
                    ? AudioManager.MODE_NORMAL : previousMode);
        } catch (Exception ignored) {
        }
        active = false;
    }
}
