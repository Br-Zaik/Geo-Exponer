package com.brian.geoexponer;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Compara la frase original con lo que entendió el reconocedor de voz.
 * Sin IA: normaliza tildes, números y muletillas, y compara palabra por palabra
 * con tolerancia a pequeños errores del reconocedor.
 */
final class PhraseMatcher {

    static final class Result {
        final int score;                 // 0..100
        final boolean passed;
        final List<String> missing;      // palabras de la frase que no se escucharon

        Result(int score, boolean passed, List<String> missing) {
            this.score = score;
            this.passed = passed;
            this.missing = missing;
        }
    }

    private static final Set<String> FILLERS = new HashSet<>();

    static {
        String[] f = {"eh", "ehh", "em", "emm", "mm", "mmm", "este", "o sea", "ah", "ahh", "uh", "um"};
        for (String s : f) FILLERS.add(s);
    }

    private PhraseMatcher() {
    }

    static Result compare(String expected, String spoken, int passScore) {
        String[] exp = words(expected, false);
        String[] got = words(spoken, true);
        if (exp.length == 0 || got.length == 0) {
            return new Result(0, false, new ArrayList<>(asList(words(expected, false))));
        }

        int distance = wordEditDistance(exp, got);
        int score = Math.round(100f * Math.max(0f, 1f - (float) distance / exp.length));
        score = Math.max(0, Math.min(100, score));

        boolean passed = score >= passScore;
        // Frases cortas: un solo error baja mucho el porcentaje; se permite 1 error.
        if (!passed && exp.length <= 5 && distance <= 1 && got.length >= exp.length - 1) {
            passed = true;
        }
        return new Result(score, passed, missingWords(exp, got));
    }

    private static List<String> asList(String[] a) {
        ArrayList<String> l = new ArrayList<>();
        for (String s : a) l.add(s);
        return l;
    }

    static String[] words(String value, boolean removeFillers) {
        String n = normalize(value);
        if (n.isEmpty()) return new String[0];
        String[] raw = n.split(" ");
        ArrayList<String> out = new ArrayList<>();
        for (String w : raw) {
            if (w.isEmpty()) continue;
            if (removeFillers && FILLERS.contains(w)) continue;
            out.add(w);
        }
        return out.toArray(new String[0]);
    }

    static String normalize(String value) {
        if (value == null) return "";
        String v = TextParser.clean(value).toLowerCase(new Locale("es", "PE"));
        v = v.replace("%", " por ciento ");
        v = v.replace("°", " grados ");
        v = Normalizer.normalize(v, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        // Números: 1.80 -> "1 punto 80"; 5000 -> "cinco mil". Así da igual si el
        // reconocedor escribe "20" o "veinte".
        v = v.replaceAll("(\\d)[.,](\\d)", "$1 punto $2");
        v = v.replaceAll("[^a-z0-9]+", " ").trim().replaceAll("\\s+", " ");
        if (v.isEmpty()) return v;
        StringBuilder out = new StringBuilder();
        for (String token : v.split(" ")) {
            if (out.length() > 0) out.append(' ');
            if (token.matches("\\d{1,9}")) {
                try {
                    out.append(normalize(numberToWords(Long.parseLong(token))));
                } catch (Exception e) {
                    out.append(token);
                }
            } else {
                out.append(token);
            }
        }
        return out.toString().trim().replaceAll("\\s+", " ");
    }

    private static int wordEditDistance(String[] a, String[] b) {
        int[] prev = new int[b.length + 1];
        int[] cur = new int[b.length + 1];
        for (int j = 0; j <= b.length; j++) prev[j] = j;
        for (int i = 1; i <= a.length; i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length; j++) {
                int cost = equivalent(a[i - 1], b[j - 1]) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length];
    }

    private static List<String> missingWords(String[] exp, String[] got) {
        int[][] t = new int[exp.length + 1][got.length + 1];
        for (int i = 1; i <= exp.length; i++) {
            for (int j = 1; j <= got.length; j++) {
                if (equivalent(exp[i - 1], got[j - 1])) t[i][j] = t[i - 1][j - 1] + 1;
                else t[i][j] = Math.max(t[i - 1][j], t[i][j - 1]);
            }
        }
        boolean[] found = new boolean[exp.length];
        int i = exp.length;
        int j = got.length;
        while (i > 0 && j > 0) {
            if (equivalent(exp[i - 1], got[j - 1]) && t[i][j] == t[i - 1][j - 1] + 1) {
                found[i - 1] = true;
                i--;
                j--;
            } else if (t[i - 1][j] >= t[i][j - 1]) {
                i--;
            } else {
                j--;
            }
        }
        ArrayList<String> missing = new ArrayList<>();
        for (int k = 0; k < exp.length; k++) {
            if (!found[k]) missing.add(exp[k]);
        }
        return missing;
    }

    static boolean equivalent(String a, String b) {
        if (a.equals(b)) return true;
        int longest = Math.max(a.length(), b.length());
        if (longest < 4) return false;
        int allowed = longest > 7 ? 2 : 1;
        if (Math.abs(a.length() - b.length()) > allowed) return false;
        return letterDistance(a, b) <= allowed;
    }

    private static int letterDistance(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length()];
    }

    // ------------------------------------------------------------ números en palabras

    private static final String[] UNITS = {"cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete",
            "ocho", "nueve", "diez", "once", "doce", "trece", "catorce", "quince", "dieciseis",
            "diecisiete", "dieciocho", "diecinueve", "veinte", "veintiuno", "veintidos", "veintitres",
            "veinticuatro", "veinticinco", "veintiseis", "veintisiete", "veintiocho", "veintinueve"};
    private static final String[] TENS = {"", "", "", "treinta", "cuarenta", "cincuenta", "sesenta",
            "setenta", "ochenta", "noventa"};
    private static final String[] HUNDREDS = {"", "ciento", "doscientos", "trescientos", "cuatrocientos",
            "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos"};

    static String numberToWords(long n) {
        if (n < 0) return "menos " + numberToWords(-n);
        if (n < 30) return UNITS[(int) n];
        if (n < 100) {
            int t = (int) (n / 10);
            int u = (int) (n % 10);
            return u == 0 ? TENS[t] : TENS[t] + " y " + UNITS[u];
        }
        if (n == 100) return "cien";
        if (n < 1000) {
            int h = (int) (n / 100);
            long rest = n % 100;
            return rest == 0 ? HUNDREDS[h] : HUNDREDS[h] + " " + numberToWords(rest);
        }
        if (n < 1_000_000) {
            long thousands = n / 1000;
            long rest = n % 1000;
            String head = thousands == 1 ? "mil" : numberToWords(thousands) + " mil";
            return rest == 0 ? head : head + " " + numberToWords(rest);
        }
        long millions = n / 1_000_000;
        long rest = n % 1_000_000;
        String head = millions == 1 ? "un millon" : numberToWords(millions) + " millones";
        return rest == 0 ? head : head + " " + numberToWords(rest);
    }
}
