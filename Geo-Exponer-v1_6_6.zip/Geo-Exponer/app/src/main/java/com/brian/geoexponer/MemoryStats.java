package com.brian.geoexponer;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.util.Iterator;

/**
 * Recuerda qué frases te cuestan (difíciles) y cuáles ya dominas,
 * por cada texto de exposición. Se guarda en el teléfono.
 */
final class MemoryStats {
    private static final String PREFS = "memorize_stats";

    private final SharedPreferences prefs;
    private final String key;
    private JSONObject data;

    MemoryStats(Context context, String textHash) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        key = "t_" + textHash;
        try {
            data = new JSONObject(prefs.getString(key, "{}"));
        } catch (Exception e) {
            data = new JSONObject();
        }
    }

    static String phraseKey(String phrase) {
        return Integer.toHexString(PhraseMatcher.normalize(phrase).hashCode());
    }

    private JSONObject entry(String phrase) {
        String k = phraseKey(phrase);
        JSONObject e = data.optJSONObject(k);
        if (e == null) {
            e = new JSONObject();
            try {
                data.put(k, e);
            } catch (Exception ignored) {
            }
        }
        return e;
    }

    /** Frase dicha bien al primer intento y sin pista. */
    void recordClean(String phrase) {
        JSONObject e = entry(phrase);
        try {
            e.put("f", Math.max(0, e.optInt("f", 0) - 1));
            e.put("c", true);
        } catch (Exception ignored) {
        }
        save();
    }

    /** Frase fallada, o que necesitó pista / repetición. */
    void recordStruggle(String phrase) {
        JSONObject e = entry(phrase);
        try {
            e.put("f", Math.min(9, e.optInt("f", 0) + 1));
            e.put("c", false);
        } catch (Exception ignored) {
        }
        save();
    }

    boolean isDifficult(String phrase) {
        JSONObject e = data.optJSONObject(phraseKey(phrase));
        return e != null && e.optInt("f", 0) > 0;
    }

    boolean isMastered(String phrase) {
        JSONObject e = data.optJSONObject(phraseKey(phrase));
        return e != null && e.optBoolean("c", false) && e.optInt("f", 0) == 0;
    }

    int difficultCount() {
        int count = 0;
        Iterator<String> keys = data.keys();
        while (keys.hasNext()) {
            JSONObject e = data.optJSONObject(keys.next());
            if (e != null && e.optInt("f", 0) > 0) count++;
        }
        return count;
    }

    void clear() {
        data = new JSONObject();
        save();
    }

    private void save() {
        prefs.edit().putString(key, data.toString()).apply();
    }
}
