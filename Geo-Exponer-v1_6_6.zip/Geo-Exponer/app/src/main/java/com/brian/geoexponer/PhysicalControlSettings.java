package com.brian.geoexponer;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Botones físicos para pausar/continuar, elegidos con casillas:
 * volumen (pantalla encendida), volumen con pantalla apagada, power y auricular.
 */
final class PhysicalControlSettings {
    static final String PREFS_NAME = "geo_exponer_prefs";
    static final String KEY_CONFIGURED = "physical_pause_configured";
    static final String KEY_MODE = "physical_pause_mode"; // versión anterior (0-5)

    private static final String K_VOL = "pc_volume_screen_on";
    private static final String K_VOL_POCKET = "pc_volume_pocket";
    private static final String K_POWER = "pc_power";
    private static final String K_HEADSET = "pc_headset";
    private static final String K_MIGRATED = "pc_migrated_v160";

    private PhysicalControlSettings() {
    }

    static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    private static SharedPreferences migrated(Context context) {
        SharedPreferences p = preferences(context);
        if (!p.getBoolean(K_MIGRATED, false)) {
            SharedPreferences.Editor e = p.edit().putBoolean(K_MIGRATED, true);
            if (p.getBoolean(KEY_CONFIGURED, false)) {
                int mode = p.getInt(KEY_MODE, 0);
                e.putBoolean(K_VOL, mode == 1 || mode == 3);
                e.putBoolean(K_POWER, mode == 2 || mode == 3 || mode == 5);
                e.putBoolean(K_VOL_POCKET, mode == 4 || mode == 5);
            }
            e.apply();
        }
        return p;
    }

    /** false = el usuario nunca tocó las casillas: se usa el comportamiento original. */
    static boolean isConfigured(Context context) {
        return migrated(context).getBoolean(KEY_CONFIGURED, false);
    }

    static boolean volume(Context context) {
        return migrated(context).getBoolean(K_VOL, false);
    }

    static boolean volumePocket(Context context) {
        return migrated(context).getBoolean(K_VOL_POCKET, false);
    }

    static boolean power(Context context) {
        return migrated(context).getBoolean(K_POWER, false);
    }

    /** El botón del auricular funciona siempre salvo que se desmarque. */
    static boolean headset(Context context) {
        return migrated(context).getBoolean(K_HEADSET, true);
    }

    static void set(Context context, boolean volume, boolean volumePocket, boolean power, boolean headset) {
        migrated(context).edit()
                .putBoolean(KEY_CONFIGURED, true)
                .putBoolean(K_VOL, volume)
                .putBoolean(K_VOL_POCKET, volumePocket)
                .putBoolean(K_POWER, power)
                .putBoolean(K_HEADSET, headset)
                .apply();
    }
}
