# Geo Exponer 1.6.7

App Android (Java, sin librerías extra) para practicar exposiciones con auriculares.

## Pestañas
- Exponer: la app te dice la frase y tú la repites. Sin micrófono.
- Textos: varias exposiciones guardadas (Nueva, Pegar, Opciones).
- Memorizar: con micrófono, te evalúa frase por frase.

## Formato del texto
Diapo 1. Portada.
Buenos días ingeniero, compañeros.

Diapo 2. Comunicación del peligro.
El *IPERC* identifica peligros y riesgos.

- Los títulos "Diapo N" y "Frase final" ya NO se leen en voz alta.
- *palabra* = palabra clave (se ve resaltada).
- También puedes compartir texto desde otra app hacia Geo Exponer.

## Exponer
- Arriba 3 cajitas: [Modo ▾] [x1.0 ▾] [⏱ 1s ▾]. Al tocar una se abre un cuadro
  con los valores grandes para elegir (como el menú de velocidad de un video).
  En Manual el tiempo entre frases se ve apagado (tú avanzas).
- Cuadro 1: texto completo; la frase actual se resalta y avanza sola.
  Toca cualquier frase para empezar o saltar ahí.
- Cuadro 2: la frase actual en grande.
- ✎ en la esquina del cuadro 1: el editor se abre justo en la frase donde vas.
  Al editar se esconden los botones y el editor usa toda la pantalla sobre
  el teclado. Desliza arriba/abajo, escribe o borra. ✓ guarda. Si estaba reproduciendo,
  se detiene para editar.
- Mantén presionado ◀ o ▶ = saltar diapositiva completa.
- ⚙ solo tiene lo que no está arriba: avisos, tiempo objetivo, modo pista,
  toques del auricular, botones físicos (casillas) y batería.

## Botones físicos (casillas en ⚙)
- Botón del auricular
- Volumen (pantalla encendida)
- Volumen con pantalla apagada: ajusta el volumen ANTES de iniciar.
- Power (encender/apagar pantalla)

## Modo bolsillo 🔒
- La pantalla se ve igual, pero no responde al toque.
- Solo funcionan auricular, volumen y power.
- Usa "Fijar pantalla" de Android: inicio y recientes no te sacan.
  (Si tu celular pregunta "¿Fijar app?", acepta. Si no aparece, activa
  "Fijar apps" en Ajustes > Seguridad.)
- Salir: atrás ◁ 3 veces rápido > "¿Deseas salir del modo bolsillo?" > Salir.

## Memorizar
- Arriba 2 cajitas: [Aprender ▾] [x1.0 ▾], con el mismo cuadro para elegir.
- Cuadro 1: texto completo con la frase actual resaltada (se tapa cuando te toca
  decirla; en Examen también se tapan las siguientes).
- Cuadro 2: la frase, tu porcentaje y las palabras que faltaron.
- ✎ en el cuadro 1: el editor se abre en la frase actual. ✓ guarda y el cambio también
  aparece en Exponer y Textos. La práctica queda en pausa: toca Seguir.
- ⚙: exigencia, micrófono y borrar historial.
- Ya no se corta al apagarse la pantalla: la pantalla queda encendida y, si sales
  y vuelves, continúa solo.
- Resultado en vivo mientras hablas; avanza apenas dices la frase completa.
- Comparación mejorada: tildes, números ("20" = "veinte"), muletillas y errores
  pequeños del reconocedor. Muestra las palabras que faltaron.
- Pistas en 4 niveles: rayas, primeras letras, primeras palabras, frase completa.
- Frases difíciles: se guardan y puedes "Repasar difíciles".
- Dominio por diapositiva (✓ 3/5).
- Modo Examen: no te lee la frase, la dices de memoria.
- Exigencia 70 / 78 / 85 %.
- Micrófono del auricular Bluetooth (beta): no todos los auriculares lo permiten.

## Preparar el celular
⚙ > Preparar mi celular: permiso de batería y pasos según la marca.

## Compilar
Igual que antes (Gradle, compileSdk 35, minSdk 23). versionCode 167.
