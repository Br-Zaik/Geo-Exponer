# Geo Exponer v2.0

Version estable para lectura corrida.

Cambios:
- Lectura corrida normal sin pausas aleatorias.
- Se desactivo el control automatico con pantalla ON/OFF porque Android puede enviar esos eventos por bloqueo automatico, AOD o notificaciones.
- Pausa/reanuda con boton multimedia del auricular/asistente si Android lo entrega.
- Pausa/reanuda desde notificacion tipo reproductor.
- Mantiene audio multimedia y servicio en segundo plano.
- Velocidades: 0.25x, 0.50x, 0.75x, 1x, 1.25x, 1.50x.

Uso recomendado:
1. Pegar texto.
2. Seleccionar Corrido.
3. Iniciar practica.
4. Bloquear pantalla.
5. Para pausar/reanudar usar auricular/asistente o notificacion.


## v2.1
- Agregado control con botones de volumen del celular para auriculares Bluetooth sin botón.
- Volumen + o Volumen - pausa/reanuda durante la práctica.
- La app intenta restaurar el volumen para que el botón funcione como control, no como cambio permanente de volumen.
- Se mantiene lectura corrida normal, segundo plano, notificación y TTS por audio multimedia.
