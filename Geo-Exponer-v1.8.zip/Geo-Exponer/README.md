# Geo Exponer v1.8

APK sencilla para practicar exposiciones con audio por auriculares Bluetooth.

Cambios v1.8:
- Lectura corrida normal por defecto.
- Al iniciar, puedes apagar la pantalla inmediatamente sin cortar la primera frase.
- Después del primer bloqueo, el botón power alterna pausar/reanudar.
- Botón de asistente/auricular intenta pausar/reanudar si Android lo entrega a la app.
- Mantiene servicio en primer plano, WAKE_LOCK y permiso de batería para trabajar con pantalla bloqueada.
