# Geo Exponer

APK sencilla para practicar exposiciones con voz Android.

## Funcionamiento principal

- Pegar texto largo.
- Guardar texto automaticamente.
- Dividir el texto en frases.
- Leer con Text To Speech de Android.
- Audio por auriculares Bluetooth si estan conectados.
- Funcionar en segundo plano con servicio en primer plano.
- Notificacion tipo reproductor.
- WAKE_LOCK para reducir cierres con pantalla apagada.

## Modos

### Manual
Lee una frase y espera. El boton power o asistente continua con la siguiente frase cuando la app esta esperando.

### Automatico
Lee las frases automaticamente usando el tiempo elegido: 0s, 1s, 2s, 3s, 5s, 8s o 10s.

### Mixto
Combina automatico y manual: lee automaticamente con el tiempo elegido y tambien permite pausar/reanudar con el boton power o asistente cuando Android entregue esa senal.

## Version 1.5.4

Cambios:
- Se agrego el modo Mixto: automatico + power/asistente.
- El modo Mixto permite elegir 1s u otro tiempo y pausar/reanudar sin depender de la pantalla tactil.
- Se mantienen Anterior, Siguiente, Repetir, Pausar/Reanudar y Detener.
