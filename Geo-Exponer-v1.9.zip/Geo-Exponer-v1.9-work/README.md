# Geo Exponer v1.9

APK sencilla para practicar exposiciones con audio por auriculares Bluetooth.

Cambios v1.9:
- Corrige problema de audio mudo al bloquear pantalla después de iniciar.
- El primer apagado de pantalla solo bloquea el celular y deja seguir la lectura.
- Después del primer bloqueo, el botón power alterna pausar/reanudar.
- Fuerza Text To Speech por audio multimedia usando AudioAttributes y STREAM_MUSIC.
- Solicita foco de audio para evitar que Android silencie la voz.
- Mantiene servicio en primer plano, WAKE_LOCK, notificación y permiso de batería.
- Mantiene botón de asistente/auricular para intentar pausar/reanudar si Android lo permite.
