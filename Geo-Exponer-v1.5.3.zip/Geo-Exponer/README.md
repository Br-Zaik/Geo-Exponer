# Geo Exponer

APK sencilla para practicar exposiciones con audio por auriculares Bluetooth.

## Versión 1.5.3

Cambios principales:

- El cuadro para pegar texto ahora es más grande y desplazable para editar, borrar o agregar texto con más facilidad.
- Se agregó botón Anterior para retroceder una frase.
- Se mantiene botón Siguiente para avanzar una frase.
- Se separó el modo de avance:
  - Manual: lee una frase y espera.
  - Automático: avanza solo según el tiempo elegido.
- En automático puedes elegir 0s, 1s, 2s, 3s, 5s, 8s o 10s.
- En ambos modos se puede pausar, reanudar, repetir, avanzar, retroceder y detener.
- Se agregó permiso WAKE_LOCK para reducir cierres con pantalla apagada.
- Se mantiene servicio en primer plano y notificación tipo reproductor.
- El permiso de batería se solicita automáticamente cuando falta, sin mostrar bloque extra en la pantalla principal.

## Uso recomendado

1. Pega tu texto.
2. Elige velocidad.
3. Elige Manual o Automático.
4. Si eliges Automático, selecciona el tiempo entre frases.
5. Presiona Iniciar práctica.

En Manual, el botón power puede continuar cuando la app está esperando la siguiente frase.
En Automático, la lectura avanza sola con el tiempo elegido.
