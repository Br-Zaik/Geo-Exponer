package com.brian.geoexponer;

import android.content.Context;
import android.content.SharedPreferences;

final class PhysicalControlSettings {
    static final String PREFS_NAME = "geo_exponer_prefs";
    static final String KEY_CONFIGURED = "physical_pause_configured";
    static final String KEY_MODE = "physical_pause_mode";

    static final int MODE_DISABLED = 0;
    static final int MODE_VOLUME = 1;
    static final int MODE_SCREEN = 2;
    static final int MODE_VOLUME_AND_SCREEN = 3;

    private PhysicalControlSettings() {
    }

    static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    static boolean isConfigured(Context context) {
        return preferences(context).getBoolean(KEY_CONFIGURED, false);
    }

    static int getMode(Context context) {
        return preferences(context).getInt(KEY_MODE, MODE_DISABLED);
    }

    static void saveMode(Context context, int mode) {
        preferences(context).edit()
                .putBoolean(KEY_CONFIGURED, true)
                .putInt(KEY_MODE, mode)
                .apply();
    }

    static boolean usesVolume(int mode) {
        return mode == MODE_VOLUME || mode == MODE_VOLUME_AND_SCREEN;
    }

    static boolean usesScreen(int mode) {
        return mode == MODE_SCREEN || mode == MODE_VOLUME_AND_SCREEN;
    }
}
