package com.brian.geoexponer;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Independent memorization mode. It does not reuse or change ExpoPlaybackService,
 * so the normal Manual, Automatic and Mixed modes keep their existing behavior.
 */
public class MemorizeActivity extends Activity {
    public static final String EXTRA_MEMORY_TEXT = "memory_text";

    private static final int REQUEST_RECORD_AUDIO = 201;
    private static final String UTTERANCE_ID = "MEMORY_PHRASE";
    private static final int PASS_SCORE = 78;
    private static final long LISTENING_WINDOW_MS = 45_000L;
    private static final long LISTEN_RESTART_DELAY_MS = 700L;
    private static final long BUSY_RESTART_DELAY_MS = 1_100L;
    private static final long AUTO_REPLAY_DELAY_MS = 650L;
    private static final long AUTO_NEXT_DELAY_MS = 500L;
    private static final long NEXT_ROUND_DELAY_MS = 150L;
    private static final long MIC_START_DELAY_MS = 200L;

    private static final String PROGRESS_PREFS = "memorize_progress";
    private static final String PREF_TEXT_HASH = "text_hash";
    private static final String PREF_SELECTED_SECTIONS = "selected_sections";
    private static final String PREF_CURRENT_INDEX = "current_index";
    private static final String PREF_SPEECH_RATE = "speech_rate";
    private static final String PREF_EVALUATED_PHRASES = "evaluated_phrases";
    private static final String PREF_SCORE_SUM = "score_sum";
    private static final String PREF_ACTIVE_PROGRESS = "active_progress";

    private static final Pattern SLIDE_HEADING = Pattern.compile(
            "(?i)^\\s*diapo(?:sitiva)?\\s*(\\d+)\\s*(?:[.\\-–—:]\\s*)?(.*)$"
    );
    private static final Pattern FINAL_HEADING = Pattern.compile(
            "(?i)^\\s*frase(?:\\s+final)?\\s*[.\\-–—:]?\\s*$"
    );

    private static final class MemorySection {
        final String title;
        final ArrayList<String> phrases = new ArrayList<>();

        MemorySection(String title) {
            this.title = title;
        }
    }

    private static final class PracticePhrase {
        final String sectionTitle;
        final String text;
        final int sectionPhraseIndex;
        final int sectionPhraseTotal;

        PracticePhrase(String sectionTitle, String text, int sectionPhraseIndex, int sectionPhraseTotal) {
            this.sectionTitle = sectionTitle;
            this.text = text;
            this.sectionPhraseIndex = sectionPhraseIndex;
            this.sectionPhraseTotal = sectionPhraseTotal;
        }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<MemorySection> sections = new ArrayList<>();
    private final ArrayList<CheckBox> sectionChecks = new ArrayList<>();
    private final ArrayList<PracticePhrase> phrases = new ArrayList<>();

    private LinearLayout resumePanel;
    private TextView resumeSummary;
    private Button resumeContinueButton;
    private Button resumeChangeSelectionButton;
    private Button resumeRestartButton;
    private LinearLayout selectionPanel;
    private LinearLayout sectionList;
    private LinearLayout practicePanel;
    private TextView selectionStatus;
    private TextView phraseCounter;
    private TextView phraseText;
    private TextView instructionText;
    private TextView heardText;
    private TextView scoreText;
    private TextView micLevelText;
    private Button selectAllButton;
    private Button clearSelectionButton;
    private Button startSelectedButton;
    private RadioButton memorySpeed075;
    private RadioButton memorySpeed100;
    private RadioButton memorySpeed125;
    private RadioButton memorySpeed150;
    private Button actionButton;
    private Button pauseButton;
    private Button listenAgainButton;
    private Button saidItRightButton;
    private Button previousButton;
    private Button nextButton;
    private Button changeSelectionButton;

    private TextToSpeech textToSpeech;
    private SpeechRecognizer speechRecognizer;
    private Intent recognitionIntent;

    private int currentIndex = 0;
    private boolean ttsReady = false;
    private boolean listening = false;
    private boolean sessionFinished = false;
    private boolean pendingStartAfterPermission = false;
    private boolean recognitionExpected = false;
    private boolean practiceStarted = false;
    private boolean paused = false;
    private int roundToken = 0;
    private String activeUtteranceId = null;
    private int evaluatedPhrases = 0;
    private int scoreSum = 0;
    private long listeningDeadlineMs = 0L;
    private boolean speechStartedInWindow = false;
    private float memorySpeechRate = 1.0f;
    private SharedPreferences progressPreferences;
    private String sourceTextHash = "";

    private final Runnable autoNextRunnable = new Runnable() {
        @Override
        public void run() {
            if (!isFinishing() && practiceStarted && !sessionFinished && !paused) {
                moveToPhrase(currentIndex + 1, true);
            }
        }
    };

    private final Runnable pendingListenRunnable = new Runnable() {
        @Override
        public void run() {
            startListeningWindow();
        }
    };

    private final Runnable restartListeningRunnable = new Runnable() {
        @Override
        public void run() {
            startListeningCycle();
        }
    };

    private final Runnable listeningWindowTimeoutRunnable = new Runnable() {
        @Override
        public void run() {
            if (!practiceStarted || paused || sessionFinished || isFinishing()) return;
            if (speechStartedInWindow) return;
            cancelCurrentRecognitionOnly();
            listeningDeadlineMs = 0L;
            showRecognitionFailure(
                    "No detecté tu voz durante 45 segundos. Toca REINTENTAR cuando estés listo."
            );
        }
    };

    private final Runnable autoReplayRunnable = new Runnable() {
        @Override
        public void run() {
            if (!isFinishing() && practiceStarted && !sessionFinished && !paused) {
                beginCurrentRound();
            }
        }
    };

    private final Runnable beginRoundRunnable = new Runnable() {
        @Override
        public void run() {
            beginCurrentRound();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memorize);

        resumePanel = findViewById(R.id.memoryResumePanel);
        resumeSummary = findViewById(R.id.memoryResumeSummary);
        resumeContinueButton = findViewById(R.id.memoryResumeContinueButton);
        resumeChangeSelectionButton = findViewById(R.id.memoryResumeChangeSelectionButton);
        resumeRestartButton = findViewById(R.id.memoryResumeRestartButton);
        selectionPanel = findViewById(R.id.memorySelectionPanel);
        sectionList = findViewById(R.id.memorySectionList);
        practicePanel = findViewById(R.id.memoryPracticePanel);
        selectionStatus = findViewById(R.id.memorySelectionStatus);
        phraseCounter = findViewById(R.id.memoryPhraseCounter);
        phraseText = findViewById(R.id.memoryPhraseText);
        instructionText = findViewById(R.id.memoryInstructionText);
        heardText = findViewById(R.id.memoryHeardText);
        scoreText = findViewById(R.id.memoryScoreText);
        micLevelText = findViewById(R.id.memoryMicLevelText);
        selectAllButton = findViewById(R.id.memorySelectAllButton);
        clearSelectionButton = findViewById(R.id.memoryClearSelectionButton);
        startSelectedButton = findViewById(R.id.memoryStartSelectedButton);
        memorySpeed075 = findViewById(R.id.memorySpeed075);
        memorySpeed100 = findViewById(R.id.memorySpeed100);
        memorySpeed125 = findViewById(R.id.memorySpeed125);
        memorySpeed150 = findViewById(R.id.memorySpeed150);
        actionButton = findViewById(R.id.memoryActionButton);
        pauseButton = findViewById(R.id.memoryPauseButton);
        listenAgainButton = findViewById(R.id.memoryListenAgainButton);
        saidItRightButton = findViewById(R.id.memorySaidItRightButton);
        previousButton = findViewById(R.id.memoryPreviousButton);
        nextButton = findViewById(R.id.memoryNextButton);
        changeSelectionButton = findViewById(R.id.memoryChangeSelectionButton);
        Button closeButton = findViewById(R.id.memoryCloseButton);

        String text = getIntent().getStringExtra(EXTRA_MEMORY_TEXT);
        sourceTextHash = calculateTextHash(text);
        progressPreferences = getSharedPreferences(PROGRESS_PREFS, MODE_PRIVATE);
        sections.addAll(parseSections(text));
        buildSectionSelection();

        selectAllButton.setOnClickListener(v -> setAllSectionsChecked(true));
        clearSelectionButton.setOnClickListener(v -> setAllSectionsChecked(false));
        startSelectedButton.setOnClickListener(v -> startSelectedPractice());
        changeSelectionButton.setOnClickListener(v -> showSelectionScreen());
        pauseButton.setOnClickListener(v -> togglePause());
        resumeContinueButton.setOnClickListener(v -> continueSavedPractice());
        resumeChangeSelectionButton.setOnClickListener(v -> showSelectionScreen());
        resumeRestartButton.setOnClickListener(v -> restartSavedPractice());
        setupMemorySpeedButtons();
        restoreSavedOptions();
        showInitialScreen();

        actionButton.setOnClickListener(v -> {
            if (sessionFinished) {
                currentIndex = 0;
                evaluatedPhrases = 0;
                scoreSum = 0;
                sessionFinished = false;
                paused = false;
                prepareCurrentPhrase();
                saveProgress();
                beginCurrentRound();
            } else {
                beginCurrentRound();
            }
        });
        listenAgainButton.setOnClickListener(v -> beginCurrentRound());
        saidItRightButton.setOnClickListener(v -> moveToPhrase(currentIndex + 1, true));
        previousButton.setOnClickListener(v -> moveToPhrase(currentIndex - 1, false));
        nextButton.setOnClickListener(v -> moveToPhrase(currentIndex + 1, false));
        closeButton.setOnClickListener(v -> {
            saveProgress();
            cancelVoiceOperations();
            finish();
        });

        initializeTextToSpeech();
        initializeSpeechRecognizer();
    }

    private void setupMemorySpeedButtons() {
        RadioButton[] speeds = new RadioButton[]{
                memorySpeed075, memorySpeed100, memorySpeed125, memorySpeed150
        };
        for (RadioButton button : speeds) {
            button.setOnClickListener(v -> {
                for (RadioButton item : speeds) {
                    item.setChecked(item == v);
                }
                if (memorySpeed075.isChecked()) memorySpeechRate = 0.75f;
                else if (memorySpeed125.isChecked()) memorySpeechRate = 1.25f;
                else if (memorySpeed150.isChecked()) memorySpeechRate = 1.50f;
                else memorySpeechRate = 1.0f;

                if (textToSpeech != null && ttsReady) {
                    textToSpeech.setSpeechRate(memorySpeechRate);
                }
                saveProgressOptionsOnly();
            });
        }
        memorySpeed100.setChecked(true);
        memorySpeechRate = 1.0f;
    }

    private void buildSectionSelection() {
        sectionList.removeAllViews();
        sectionChecks.clear();

        if (sections.isEmpty()) {
            selectionStatus.setText("No se encontraron frases para practicar.");
            startSelectedButton.setEnabled(false);
            selectAllButton.setEnabled(false);
            clearSelectionButton.setEnabled(false);
            return;
        }

        for (MemorySection section : sections) {
            CheckBox checkBox = new CheckBox(this);
            String countLabel = section.phrases.size() == 1 ? "1 frase" : section.phrases.size() + " frases";
            checkBox.setText(section.title + " — " + countLabel);
            checkBox.setTextColor(getResources().getColor(R.color.text_main));
            checkBox.setTextSize(15f);
            checkBox.setChecked(true);
            checkBox.setPadding(dp(6), dp(6), dp(6), dp(6));
            checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> updateSelectionStatus());

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            sectionList.addView(checkBox, params);
            sectionChecks.add(checkBox);
        }
        updateSelectionStatus();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void setAllSectionsChecked(boolean checked) {
        for (CheckBox checkBox : sectionChecks) {
            checkBox.setChecked(checked);
        }
        updateSelectionStatus();
    }

    private void updateSelectionStatus() {
        int selectedSections = 0;
        int selectedPhrases = 0;
        for (int i = 0; i < sectionChecks.size(); i++) {
            if (sectionChecks.get(i).isChecked()) {
                selectedSections++;
                selectedPhrases += sections.get(i).phrases.size();
            }
        }

        if (selectedSections == 0) {
            selectionStatus.setText("Selecciona al menos una diapositiva.");
            startSelectedButton.setEnabled(false);
        } else {
            String sectionLabel = selectedSections == 1 ? "1 bloque" : selectedSections + " bloques";
            String phraseLabel = selectedPhrases == 1 ? "1 frase" : selectedPhrases + " frases";
            selectionStatus.setText("Seleccionados: " + sectionLabel + " · " + phraseLabel);
            startSelectedButton.setEnabled(true);
        }
    }

    private void startSelectedPractice() {
        cancelVoiceOperations();
        buildPracticePhrasesFromChecks();

        if (phrases.isEmpty()) {
            Toast.makeText(this, "Selecciona al menos una diapositiva.", Toast.LENGTH_SHORT).show();
            return;
        }

        currentIndex = 0;
        evaluatedPhrases = 0;
        scoreSum = 0;
        enterPracticeScreen();
        saveProgress();
    }

    private void buildPracticePhrasesFromChecks() {
        phrases.clear();
        for (int i = 0; i < sectionChecks.size(); i++) {
            if (!sectionChecks.get(i).isChecked()) continue;
            MemorySection section = sections.get(i);
            for (int j = 0; j < section.phrases.size(); j++) {
                phrases.add(new PracticePhrase(
                        section.title,
                        section.phrases.get(j),
                        j + 1,
                        section.phrases.size()
                ));
            }
        }
    }

    private void enterPracticeScreen() {
        sessionFinished = false;
        practiceStarted = true;
        paused = false;
        pauseButton.setText("PAUSAR");
        resumePanel.setVisibility(View.GONE);
        selectionPanel.setVisibility(View.GONE);
        practicePanel.setVisibility(View.VISIBLE);
        prepareCurrentPhrase();
    }

    private void showSelectionScreen() {
        saveProgress();
        cancelVoiceOperations();
        practiceStarted = false;
        sessionFinished = false;
        paused = false;
        phrases.clear();
        resumePanel.setVisibility(View.GONE);
        practicePanel.setVisibility(View.GONE);
        selectionPanel.setVisibility(View.VISIBLE);
        updateSelectionStatus();
    }

    private void showInitialScreen() {
        if (hasRestorableProgress() && prepareSavedPracticePhrases()) {
            int savedIndex = progressPreferences.getInt(PREF_CURRENT_INDEX, 0);
            savedIndex = Math.max(0, Math.min(savedIndex, phrases.size() - 1));
            PracticePhrase phrase = phrases.get(savedIndex);
            resumeSummary.setText(
                    "Continuar en:\n" + phrase.sectionTitle
                            + " · Frase " + phrase.sectionPhraseIndex + " de " + phrase.sectionPhraseTotal
                            + "\nAvance total " + (savedIndex + 1) + " de " + phrases.size()
            );
            practiceStarted = false;
            sessionFinished = false;
            paused = false;
            selectionPanel.setVisibility(View.GONE);
            practicePanel.setVisibility(View.GONE);
            resumePanel.setVisibility(View.VISIBLE);
        } else {
            phrases.clear();
            resumePanel.setVisibility(View.GONE);
            practicePanel.setVisibility(View.GONE);
            selectionPanel.setVisibility(View.VISIBLE);
        }
    }

    private void continueSavedPractice() {
        if (!prepareSavedPracticePhrases()) {
            clearSavedProgress();
            showSelectionScreen();
            return;
        }
        currentIndex = progressPreferences.getInt(PREF_CURRENT_INDEX, 0);
        currentIndex = Math.max(0, Math.min(currentIndex, phrases.size() - 1));
        evaluatedPhrases = Math.max(0, progressPreferences.getInt(PREF_EVALUATED_PHRASES, 0));
        scoreSum = Math.max(0, progressPreferences.getInt(PREF_SCORE_SUM, 0));
        enterPracticeScreen();
        instructionText.setText("Continuaste desde la frase donde lo dejaste. Toca COMENZAR cuando estés listo.");
        saveProgress();
    }

    private void restartSavedPractice() {
        if (!prepareSavedPracticePhrases()) {
            clearSavedProgress();
            showSelectionScreen();
            return;
        }
        currentIndex = 0;
        evaluatedPhrases = 0;
        scoreSum = 0;
        enterPracticeScreen();
        instructionText.setText("La práctica comenzó nuevamente desde la primera frase seleccionada.");
        saveProgress();
    }

    private boolean prepareSavedPracticePhrases() {
        if (!applySavedSectionSelection()) return false;
        buildPracticePhrasesFromChecks();
        return !phrases.isEmpty();
    }

    private void initializeTextToSpeech() {
        textToSpeech = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                ttsReady = false;
                if (practiceStarted) instructionText.setText("No se pudo iniciar la voz del teléfono.");
                return;
            }

            int result = textToSpeech.setLanguage(new Locale("es", "PE"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                result = textToSpeech.setLanguage(new Locale("es", "ES"));
            }
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                ttsReady = false;
                if (practiceStarted) instructionText.setText("El motor de voz no tiene español instalado.");
                return;
            }

            textToSpeech.setSpeechRate(memorySpeechRate);
            textToSpeech.setPitch(1.0f);
            textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onStart(String utteranceId) {
                    if (!utteranceId.equals(activeUtteranceId)) return;
                    runOnUiThread(() -> {
                        if (paused || !practiceStarted) return;
                        instructionText.setText("Escucha la frase completa.");
                        actionButton.setEnabled(false);
                        listenAgainButton.setEnabled(false);
                    });
                }

                @Override
                public void onDone(String utteranceId) {
                    if (!utteranceId.equals(activeUtteranceId)) return;
                    runOnUiThread(() -> {
                        if (sessionFinished || isFinishing() || paused || !practiceStarted) return;
                        phraseText.setText("Ahora repítela sin mirar…");
                        instructionText.setText("El micrófono se activará. Habla claro y cerca del teléfono o del auricular.");
                        handler.postDelayed(pendingListenRunnable, MIC_START_DELAY_MS);
                    });
                }

                @Override
                public void onError(String utteranceId) {
                    if (!utteranceId.equals(activeUtteranceId)) return;
                    runOnUiThread(() -> {
                        if (paused || !practiceStarted) return;
                        instructionText.setText("No se pudo reproducir la frase. Toca Reintentar.");
                        restoreAfterListening();
                    });
                }
            });
            ttsReady = true;
            if (practiceStarted && !paused && !phrases.isEmpty()) {
                actionButton.setEnabled(true);
            }
        });
    }

    private void initializeSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            recognitionIntent = null;
            speechRecognizer = null;
            return;
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                if (!recognitionExpected || paused || !practiceStarted) return;
                listening = true;
                micLevelText.setVisibility(View.VISIBLE);
                micLevelText.setText("Micrófono activo");
                instructionText.setText(
                        "Habla cuando estés listo. Si Google cierra la escucha, la app la reactivará hasta completar 45 segundos."
                );
                actionButton.setText("ESPERANDO TU VOZ…");
            }

            @Override
            public void onBeginningOfSpeech() {
                if (!recognitionExpected || paused || !practiceStarted) return;
                speechStartedInWindow = true;
                handler.removeCallbacks(listeningWindowTimeoutRunnable);
                instructionText.setText("Te estoy escuchando…");
                actionButton.setText("ESCUCHANDO…");
            }

            @Override
            public void onRmsChanged(float rmsdB) {
                if (!recognitionExpected || paused || !practiceStarted) return;
                int bars = Math.max(1, Math.min(8, Math.round((rmsdB + 2f) / 2f)));
                StringBuilder level = new StringBuilder("Voz: ");
                for (int i = 0; i < bars; i++) level.append("▮");
                micLevelText.setText(level.toString());
            }

            @Override
            public void onBufferReceived(byte[] buffer) {
            }

            @Override
            public void onEndOfSpeech() {
                if (!recognitionExpected || paused || !practiceStarted) return;
                listening = false;
                micLevelText.setText("Analizando voz…");
                instructionText.setText("Comparando lo que dijiste con la frase original.");
            }

            @Override
            public void onError(int error) {
                if (!recognitionExpected || paused || !practiceStarted) return;
                recognitionExpected = false;
                listening = false;
                micLevelText.setVisibility(View.GONE);

                boolean silenceError = error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                        || (error == SpeechRecognizer.ERROR_NO_MATCH && !speechStartedInWindow);

                if (silenceError && hasListeningTimeRemaining()) {
                    scheduleListeningRestart(
                            LISTEN_RESTART_DELAY_MS,
                            "Sigo esperando tu voz… el micrófono se reactivará automáticamente."
                    );
                    return;
                }

                if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY && hasListeningTimeRemaining()) {
                    recreateSpeechRecognizer();
                    scheduleListeningRestart(
                            BUSY_RESTART_DELAY_MS,
                            "El reconocedor se está preparando otra vez. No necesitas tocar ningún botón."
                    );
                    return;
                }

                handler.removeCallbacks(listeningWindowTimeoutRunnable);
                listeningDeadlineMs = 0L;

                if (error == SpeechRecognizer.ERROR_NO_MATCH && speechStartedInWindow) {
                    showRecognitionFailureWithReplay(
                            "No entendí suficientes palabras. Volveré a leer la frase completa para que la intentes otra vez."
                    );
                    return;
                }

                String message;
                switch (error) {
                    case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                        message = "No detecté tu voz durante el tiempo de espera.";
                        break;
                    case SpeechRecognizer.ERROR_AUDIO:
                        message = "Hubo un problema con el micrófono.";
                        break;
                    case SpeechRecognizer.ERROR_NETWORK:
                    case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                        message = "El reconocimiento de voz tuvo un problema de conexión.";
                        break;
                    case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                        message = "Falta el permiso del micrófono.";
                        break;
                    case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                        message = "El reconocedor continuó ocupado. Toca REINTENTAR.";
                        break;
                    default:
                        message = "No pude reconocer tu voz. Toca REINTENTAR.";
                        break;
                }
                showRecognitionFailure(message);
            }

            @Override
            public void onResults(Bundle results) {
                if (!recognitionExpected || paused || !practiceStarted) return;
                clearListeningWindowState();
                micLevelText.setVisibility(View.GONE);
                ArrayList<String> candidates = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                evaluateCandidates(candidates);
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
            }

            @Override
            public void onEvent(int eventType, Bundle params) {
            }
        });

        recognitionIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE");
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PE");
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L);
        recognitionIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L);
    }

    private void beginCurrentRound() {
        handler.removeCallbacks(autoNextRunnable);
        if (!practiceStarted || paused || phrases.isEmpty() || sessionFinished) return;
        if (!ttsReady) {
            Toast.makeText(this, "La voz todavía se está preparando.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingStartAfterPermission = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
            return;
        }
        if (speechRecognizer == null || recognitionIntent == null) {
            showRecognitionFailure("Este teléfono no tiene reconocimiento de voz disponible.");
            return;
        }

        cancelVoiceOperations();
        clearEvaluation();
        PracticePhrase phrase = phrases.get(currentIndex);
        phraseText.setText(phrase.text);
        instructionText.setText("Escucha. Cuando termine, la frase se ocultará y deberás repetirla.");
        actionButton.setText("ESCUCHA…");
        actionButton.setEnabled(false);
        listenAgainButton.setEnabled(false);
        saidItRightButton.setEnabled(false);

        Bundle params = new Bundle();
        roundToken++;
        activeUtteranceId = UTTERANCE_ID + "_" + roundToken;
        textToSpeech.setSpeechRate(memorySpeechRate);
        int speakResult = textToSpeech.speak(
                phrase.text,
                TextToSpeech.QUEUE_FLUSH,
                params,
                activeUtteranceId
        );
        if (speakResult == TextToSpeech.ERROR) {
            instructionText.setText("No se pudo reproducir la frase. Toca REINTENTAR.");
            restoreAfterListening();
        }
    }

    private void startListeningWindow() {
        if (!practiceStarted || paused || sessionFinished || isFinishing()) return;
        listeningDeadlineMs = SystemClock.elapsedRealtime() + LISTENING_WINDOW_MS;
        speechStartedInWindow = false;
        handler.removeCallbacks(restartListeningRunnable);
        handler.removeCallbacks(listeningWindowTimeoutRunnable);
        handler.postDelayed(listeningWindowTimeoutRunnable, LISTENING_WINDOW_MS);
        startListeningCycle();
    }

    private void startListeningCycle() {
        if (!practiceStarted || paused || sessionFinished || isFinishing()) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            clearListeningWindowState();
            showRecognitionFailure("Falta el permiso del micrófono.");
            return;
        }
        if (speechRecognizer == null || recognitionIntent == null) {
            clearListeningWindowState();
            showRecognitionFailure("Este teléfono no tiene reconocimiento de voz disponible.");
            return;
        }
        if (!hasListeningTimeRemaining() && !speechStartedInWindow) {
            listeningWindowTimeoutRunnable.run();
            return;
        }

        try {
            recognitionExpected = true;
            listening = false;
            actionButton.setText("ESPERANDO TU VOZ…");
            actionButton.setEnabled(false);
            speechRecognizer.startListening(recognitionIntent);
        } catch (Exception error) {
            recognitionExpected = false;
            listening = false;
            if (hasListeningTimeRemaining()) {
                recreateSpeechRecognizer();
                scheduleListeningRestart(
                        BUSY_RESTART_DELAY_MS,
                        "El micrófono se está preparando otra vez. No necesitas tocar ningún botón."
                );
            } else {
                clearListeningWindowState();
                showRecognitionFailure("No se pudo activar el micrófono. Toca REINTENTAR.");
            }
        }
    }

    private boolean hasListeningTimeRemaining() {
        return listeningDeadlineMs > SystemClock.elapsedRealtime();
    }

    private void scheduleListeningRestart(long delayMs, String message) {
        if (!practiceStarted || paused || sessionFinished || isFinishing()) return;
        long remaining = listeningDeadlineMs - SystemClock.elapsedRealtime();
        if (remaining <= 0L) {
            listeningWindowTimeoutRunnable.run();
            return;
        }

        instructionText.setText(message);
        micLevelText.setVisibility(View.VISIBLE);
        micLevelText.setText("Esperando voz…");
        actionButton.setText("ESPERANDO TU VOZ…");
        actionButton.setEnabled(false);
        handler.removeCallbacks(restartListeningRunnable);
        handler.postDelayed(restartListeningRunnable, Math.min(delayMs, remaining));
    }

    private void clearListeningWindowState() {
        handler.removeCallbacks(restartListeningRunnable);
        handler.removeCallbacks(listeningWindowTimeoutRunnable);
        listeningDeadlineMs = 0L;
        speechStartedInWindow = false;
        recognitionExpected = false;
        listening = false;
    }

    private void cancelCurrentRecognitionOnly() {
        recognitionExpected = false;
        listening = false;
        if (speechRecognizer != null) {
            try {
                speechRecognizer.cancel();
            } catch (Exception ignored) {
            }
        }
        if (micLevelText != null) micLevelText.setVisibility(View.GONE);
    }

    private void recreateSpeechRecognizer() {
        if (speechRecognizer != null) {
            try {
                speechRecognizer.cancel();
            } catch (Exception ignored) {
            }
            try {
                speechRecognizer.destroy();
            } catch (Exception ignored) {
            }
            speechRecognizer = null;
        }
        initializeSpeechRecognizer();
    }

    private void evaluateCandidates(ArrayList<String> candidates) {
        if (!practiceStarted || paused || phrases.isEmpty()) return;
        if (candidates == null || candidates.isEmpty()) {
            showRecognitionFailureWithReplay(
                    "No entendí suficientes palabras. Volveré a leer la frase completa para que la intentes otra vez."
            );
            return;
        }

        String expected = phrases.get(currentIndex).text;
        String bestCandidate = candidates.get(0);
        int bestScore = 0;
        for (String candidate : candidates) {
            int score = similarityScore(expected, candidate);
            if (score > bestScore) {
                bestScore = score;
                bestCandidate = candidate;
            }
        }

        evaluatedPhrases++;
        scoreSum += bestScore;
        heardText.setVisibility(View.VISIBLE);
        heardText.setText("La app entendió:\n“" + bestCandidate + "”");
        scoreText.setVisibility(View.VISIBLE);
        scoreText.setText("Coincidencia: " + bestScore + "%");
        actionButton.setText("REINTENTAR");
        actionButton.setEnabled(true);
        listenAgainButton.setEnabled(true);
        saidItRightButton.setEnabled(true);

        if (bestScore >= PASS_SCORE) {
            phraseText.setText(expected);
            instructionText.setText("Bien. Pasando a la siguiente frase…");
            scoreText.setText("✓ Coincidencia: " + bestScore + "%");
            handler.postDelayed(autoNextRunnable, AUTO_NEXT_DELAY_MS);
        } else {
            phraseText.setText(expected);
            instructionText.setText(
                    "Te faltó una parte. Volveré a leer la frase completa. "
                            + "Si tú la dijiste bien pero el teléfono falló, toca “YO LO DIJE BIEN”."
            );
            handler.removeCallbacks(autoReplayRunnable);
            handler.postDelayed(autoReplayRunnable, AUTO_REPLAY_DELAY_MS);
        }
    }

    private void showRecognitionFailureWithReplay(String message) {
        clearListeningWindowState();
        if (!phrases.isEmpty()) phraseText.setText(phrases.get(currentIndex).text);
        instructionText.setText(message);
        heardText.setVisibility(View.VISIBLE);
        heardText.setText("No se pudo evaluar este intento.");
        scoreText.setVisibility(View.GONE);
        restoreAfterListening();
        saidItRightButton.setEnabled(true);
        handler.removeCallbacks(autoReplayRunnable);
        handler.postDelayed(autoReplayRunnable, AUTO_REPLAY_DELAY_MS);
    }

    private void showRecognitionFailure(String message) {
        clearListeningWindowState();
        if (!phrases.isEmpty()) phraseText.setText(phrases.get(currentIndex).text);
        instructionText.setText(message);
        heardText.setVisibility(View.VISIBLE);
        heardText.setText("No se pudo evaluar este intento.");
        scoreText.setVisibility(View.GONE);
        restoreAfterListening();
        saidItRightButton.setEnabled(true);
    }

    private void restoreAfterListening() {
        listening = false;
        micLevelText.setVisibility(View.GONE);
        actionButton.setText("REINTENTAR");
        actionButton.setEnabled(!paused);
        listenAgainButton.setEnabled(!paused);
    }

    private void moveToPhrase(int newIndex, boolean fromResult) {
        if (!practiceStarted || paused) return;
        handler.removeCallbacks(autoNextRunnable);
        cancelVoiceOperations();

        if (newIndex >= phrases.size()) {
            finishSession();
            return;
        }
        if (newIndex < 0) newIndex = 0;

        currentIndex = newIndex;
        sessionFinished = false;
        prepareCurrentPhrase();
        saveProgress();
        if (fromResult) {
            handler.postDelayed(beginRoundRunnable, NEXT_ROUND_DELAY_MS);
        }
    }

    private void prepareCurrentPhrase() {
        if (phrases.isEmpty()) return;
        PracticePhrase phrase = phrases.get(currentIndex);
        clearEvaluation();
        phraseCounter.setText(
                phrase.sectionTitle
                        + "\nFrase " + phrase.sectionPhraseIndex + " de " + phrase.sectionPhraseTotal
                        + "  ·  Total " + (currentIndex + 1) + " de " + phrases.size()
        );
        phraseText.setText(phrase.text);
        instructionText.setText("Toca COMENZAR. Escucharás la frase y luego la repetirás sin verla.");
        actionButton.setText("COMENZAR");
        actionButton.setEnabled(ttsReady && !paused);
        pauseButton.setText(paused ? "REANUDAR" : "PAUSAR");
        pauseButton.setEnabled(true);
        listenAgainButton.setEnabled(!paused);
        saidItRightButton.setEnabled(false);
        previousButton.setEnabled(!paused && currentIndex > 0);
        nextButton.setEnabled(!paused && currentIndex < phrases.size() - 1);
    }

    private void togglePause() {
        if (!practiceStarted || sessionFinished || phrases.isEmpty()) return;

        if (!paused) {
            paused = true;
            cancelVoiceOperations();
            phraseText.setText(phrases.get(currentIndex).text);
            instructionText.setText("Práctica pausada. La frase actual quedó guardada.");
            pauseButton.setText("REANUDAR");
            actionButton.setEnabled(false);
            listenAgainButton.setEnabled(false);
            saidItRightButton.setEnabled(false);
            previousButton.setEnabled(false);
            nextButton.setEnabled(false);
            saveProgress();
        } else {
            paused = false;
            pauseButton.setText("PAUSAR");
            prepareCurrentPhrase();
            instructionText.setText("Reanudando desde la misma frase…");
            saveProgress();
            handler.postDelayed(beginRoundRunnable, NEXT_ROUND_DELAY_MS);
        }
    }

    private void finishSession() {
        sessionFinished = true;
        paused = false;
        cancelVoiceOperations();
        phraseCounter.setText("Práctica terminada");
        phraseText.setText("¡Completaste todas las frases seleccionadas!");
        int average = evaluatedPhrases > 0 ? Math.round((float) scoreSum / evaluatedPhrases) : 0;
        instructionText.setText(evaluatedPhrases > 0
                ? "Promedio de coincidencia de los intentos evaluados: " + average + "%"
                : "Puedes volver a practicar desde el inicio.");
        heardText.setVisibility(View.GONE);
        scoreText.setVisibility(View.GONE);
        micLevelText.setVisibility(View.GONE);
        actionButton.setText("PRACTICAR DE NUEVO");
        actionButton.setEnabled(true);
        pauseButton.setText("PAUSAR");
        pauseButton.setEnabled(false);
        listenAgainButton.setEnabled(false);
        saidItRightButton.setEnabled(false);
        previousButton.setEnabled(!phrases.isEmpty());
        nextButton.setEnabled(false);
        markProgressCompleted();
    }

    private void clearEvaluation() {
        heardText.setText("");
        heardText.setVisibility(View.GONE);
        scoreText.setText("");
        scoreText.setVisibility(View.GONE);
        micLevelText.setVisibility(View.GONE);
    }

    private void cancelVoiceOperations() {
        handler.removeCallbacks(autoNextRunnable);
        handler.removeCallbacks(pendingListenRunnable);
        handler.removeCallbacks(beginRoundRunnable);
        handler.removeCallbacks(restartListeningRunnable);
        handler.removeCallbacks(listeningWindowTimeoutRunnable);
        handler.removeCallbacks(autoReplayRunnable);
        activeUtteranceId = null;
        listeningDeadlineMs = 0L;
        speechStartedInWindow = false;
        recognitionExpected = false;
        if (textToSpeech != null) textToSpeech.stop();
        if (speechRecognizer != null) {
            try {
                speechRecognizer.cancel();
            } catch (Exception ignored) {
            }
        }
        listening = false;
        if (micLevelText != null) micLevelText.setVisibility(View.GONE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_RECORD_AUDIO) return;

        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (granted && pendingStartAfterPermission) {
            pendingStartAfterPermission = false;
            if (!paused && practiceStarted) beginCurrentRound();
        } else {
            pendingStartAfterPermission = false;
            if (practiceStarted) {
                instructionText.setText("Sin permiso de micrófono no se puede comprobar lo que repites.");
                saidItRightButton.setEnabled(true);
            }
        }
    }

    @Override
    protected void onPause() {
        saveProgress();
        super.onPause();
        if (!practiceStarted || paused || sessionFinished) return;

        cancelVoiceOperations();
        if (!pendingStartAfterPermission && !phrases.isEmpty()) {
            phraseText.setText(phrases.get(currentIndex).text);
            instructionText.setText("La escucha se detuvo al salir de la pantalla. Toca REINTENTAR para continuar.");
            restoreAfterListening();
            saidItRightButton.setEnabled(true);
        }
    }

    @Override
    protected void onDestroy() {
        saveProgress();
        handler.removeCallbacksAndMessages(null);
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        super.onDestroy();
    }

    private void restoreSavedOptions() {
        String savedHash = progressPreferences.getString(PREF_TEXT_HASH, "");
        if (!sourceTextHash.equals(savedHash)) {
            clearSavedProgress();
            return;
        }

        applySavedSectionSelection();
        float savedRate = progressPreferences.getFloat(PREF_SPEECH_RATE, 1.0f);
        setMemorySpeechRate(savedRate);
    }

    private void setMemorySpeechRate(float rate) {
        if (Math.abs(rate - 0.75f) < 0.01f) {
            memorySpeechRate = 0.75f;
            memorySpeed075.setChecked(true);
        } else if (Math.abs(rate - 1.25f) < 0.01f) {
            memorySpeechRate = 1.25f;
            memorySpeed125.setChecked(true);
        } else if (Math.abs(rate - 1.50f) < 0.01f) {
            memorySpeechRate = 1.50f;
            memorySpeed150.setChecked(true);
        } else {
            memorySpeechRate = 1.0f;
            memorySpeed100.setChecked(true);
        }
        memorySpeed075.setChecked(memorySpeechRate == 0.75f);
        memorySpeed100.setChecked(memorySpeechRate == 1.0f);
        memorySpeed125.setChecked(memorySpeechRate == 1.25f);
        memorySpeed150.setChecked(memorySpeechRate == 1.50f);
    }

    private boolean hasRestorableProgress() {
        if (progressPreferences == null || sourceTextHash.isEmpty()) return false;
        return progressPreferences.getBoolean(PREF_ACTIVE_PROGRESS, false)
                && sourceTextHash.equals(progressPreferences.getString(PREF_TEXT_HASH, ""))
                && !progressPreferences.getString(PREF_SELECTED_SECTIONS, "").isEmpty();
    }

    private boolean applySavedSectionSelection() {
        if (progressPreferences == null) return false;
        if (!sourceTextHash.equals(progressPreferences.getString(PREF_TEXT_HASH, ""))) return false;

        String encoded = progressPreferences.getString(PREF_SELECTED_SECTIONS, "");
        if (encoded.isEmpty()) return false;

        boolean[] selected = new boolean[sectionChecks.size()];
        int validCount = 0;
        String[] parts = encoded.split(",");
        for (String part : parts) {
            try {
                int index = Integer.parseInt(part.trim());
                if (index >= 0 && index < selected.length && !selected[index]) {
                    selected[index] = true;
                    validCount++;
                }
            } catch (NumberFormatException ignored) {
            }
        }
        if (validCount == 0) return false;

        for (int i = 0; i < sectionChecks.size(); i++) {
            sectionChecks.get(i).setChecked(selected[i]);
        }
        updateSelectionStatus();
        return true;
    }

    private String encodeSelectedSections() {
        StringBuilder encoded = new StringBuilder();
        for (int i = 0; i < sectionChecks.size(); i++) {
            if (!sectionChecks.get(i).isChecked()) continue;
            if (encoded.length() > 0) encoded.append(',');
            encoded.append(i);
        }
        return encoded.toString();
    }

    private void saveProgressOptionsOnly() {
        if (progressPreferences == null || sourceTextHash.isEmpty()) return;
        SharedPreferences.Editor editor = progressPreferences.edit()
                .putString(PREF_TEXT_HASH, sourceTextHash)
                .putFloat(PREF_SPEECH_RATE, memorySpeechRate);
        String selected = encodeSelectedSections();
        if (!selected.isEmpty()) editor.putString(PREF_SELECTED_SECTIONS, selected);
        editor.apply();
    }

    private void saveProgress() {
        if (progressPreferences == null || sourceTextHash.isEmpty()) return;
        if (!practiceStarted || phrases.isEmpty() || sessionFinished) return;

        String selected = encodeSelectedSections();
        if (selected.isEmpty()) return;

        progressPreferences.edit()
                .putString(PREF_TEXT_HASH, sourceTextHash)
                .putString(PREF_SELECTED_SECTIONS, selected)
                .putInt(PREF_CURRENT_INDEX, Math.max(0, Math.min(currentIndex, phrases.size() - 1)))
                .putFloat(PREF_SPEECH_RATE, memorySpeechRate)
                .putInt(PREF_EVALUATED_PHRASES, Math.max(0, evaluatedPhrases))
                .putInt(PREF_SCORE_SUM, Math.max(0, scoreSum))
                .putBoolean(PREF_ACTIVE_PROGRESS, true)
                .apply();
    }

    private void markProgressCompleted() {
        if (progressPreferences == null) return;
        progressPreferences.edit()
                .putBoolean(PREF_ACTIVE_PROGRESS, false)
                .putInt(PREF_CURRENT_INDEX, 0)
                .putInt(PREF_EVALUATED_PHRASES, 0)
                .putInt(PREF_SCORE_SUM, 0)
                .apply();
    }

    private void clearSavedProgress() {
        if (progressPreferences == null) return;
        progressPreferences.edit().clear().apply();
    }

    private static String calculateTextHash(String text) {
        String value = text == null ? "" : text.replace("\r\n", "\n").replace('\r', '\n').trim();
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder hash = new StringBuilder();
            for (byte item : bytes) hash.append(String.format(Locale.US, "%02x", item));
            return hash.toString();
        } catch (Exception ignored) {
            return value.length() + ":" + value.hashCode();
        }
    }

    private static List<MemorySection> parseSections(String source) {
        ArrayList<MemorySection> parsed = new ArrayList<>();
        if (source == null) return parsed;

        String clean = source.replace("\r\n", "\n").replace('\r', '\n').trim();
        if (clean.isEmpty()) return parsed;

        MemorySection current = null;
        String[] lines = clean.split("\\n");
        for (String rawLine : lines) {
            String line = rawLine.replaceAll("[\\t ]+", " ").trim();
            if (line.isEmpty()) continue;

            Matcher slideMatcher = SLIDE_HEADING.matcher(line);
            if (slideMatcher.matches()) {
                String number = slideMatcher.group(1);
                String subtitle = cleanHeadingSubtitle(slideMatcher.group(2));
                String title = "Diapo " + number + (subtitle.isEmpty() ? "" : " · " + subtitle);
                current = new MemorySection(title);
                parsed.add(current);
                continue;
            }

            if (FINAL_HEADING.matcher(line).matches()) {
                current = new MemorySection("Frase final");
                parsed.add(current);
                continue;
            }

            if (current == null) {
                current = new MemorySection("Todo el texto");
                parsed.add(current);
            }
            current.phrases.addAll(splitContentIntoPhrases(line));
        }

        for (int i = parsed.size() - 1; i >= 0; i--) {
            if (parsed.get(i).phrases.isEmpty()) parsed.remove(i);
        }
        return parsed;
    }

    private static String cleanHeadingSubtitle(String subtitle) {
        if (subtitle == null) return "";
        return subtitle.trim()
                .replaceAll("^[.\\-–—:\\s]+", "")
                .replaceAll("[.\\-–—:\\s]+$", "")
                .trim();
    }

    private static List<String> splitContentIntoPhrases(String source) {
        ArrayList<String> result = new ArrayList<>();
        if (source == null) return result;

        String clean = source.replaceAll("[\\t ]+", " ").trim();
        if (clean.isEmpty()) return result;

        // Match the normal playback mode: keep each sentence complete until
        // a period, question mark or exclamation mark.
        String[] sentenceCuts = clean.split("(?<=[.!?])\\s+");
        for (String cut : sentenceCuts) {
            addReadableMemoryChunks(result, cut.trim());
        }

        if (result.isEmpty()) result.add(clean);
        return result;
    }

    private static void addReadableMemoryChunks(List<String> result, String text) {
        if (text.isEmpty()) return;

        // Normal sentences remain intact. Only exceptionally long sentences
        // are split at natural pauses, as in the existing normal mode.
        if (text.length() <= 220) {
            result.add(text);
            return;
        }

        String[] pauseCuts = text.split("(?<=[,;:])\\s+");
        StringBuilder buffer = new StringBuilder();
        for (String part : pauseCuts) {
            part = part.trim();
            if (part.isEmpty()) continue;

            if (buffer.length() + part.length() + 1 <= 220) {
                if (buffer.length() > 0) buffer.append(' ');
                buffer.append(part);
            } else {
                if (buffer.length() > 0) {
                    result.add(buffer.toString());
                    buffer.setLength(0);
                }
                if (part.length() <= 220) {
                    buffer.append(part);
                } else {
                    addMemoryChunksByLength(result, part);
                }
            }
        }
        if (buffer.length() > 0) result.add(buffer.toString());
    }

    private static void addMemoryChunksByLength(List<String> result, String text) {
        int start = 0;
        while (start < text.length()) {
            int end = Math.min(start + 180, text.length());
            if (end < text.length()) {
                int space = text.lastIndexOf(' ', end);
                if (space > start + 60) end = space;
            }
            String chunk = text.substring(start, end).trim();
            if (!chunk.isEmpty()) result.add(chunk);
            start = end;
        }
    }

    private static int similarityScore(String expected, String spoken) {
        String[] expectedWords = normalize(expected).split(" ");
        String[] spokenWords = normalize(spoken).split(" ");
        if (expectedWords.length == 1 && expectedWords[0].isEmpty()) return 0;
        if (spokenWords.length == 1 && spokenWords[0].isEmpty()) return 0;

        int matches = fuzzyLcs(expectedWords, spokenWords);
        int denominator = expectedWords.length + spokenWords.length;
        if (denominator == 0) return 0;
        return Math.max(0, Math.min(100, Math.round((200f * matches) / denominator)));
    }

    private static int fuzzyLcs(String[] first, String[] second) {
        int[][] table = new int[first.length + 1][second.length + 1];
        for (int i = 1; i <= first.length; i++) {
            for (int j = 1; j <= second.length; j++) {
                if (wordsEquivalent(first[i - 1], second[j - 1])) {
                    table[i][j] = table[i - 1][j - 1] + 1;
                } else {
                    table[i][j] = Math.max(table[i - 1][j], table[i][j - 1]);
                }
            }
        }
        return table[first.length][second.length];
    }

    private static boolean wordsEquivalent(String first, String second) {
        if (first.equals(second)) return true;
        if (first.length() < 5 || second.length() < 5) return false;
        if (Math.abs(first.length() - second.length()) > 1) return false;
        return editDistance(first, second) <= 1;
    }

    private static int editDistance(String first, String second) {
        int[] previous = new int[second.length() + 1];
        int[] current = new int[second.length() + 1];
        for (int j = 0; j <= second.length(); j++) previous[j] = j;

        for (int i = 1; i <= first.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= second.length(); j++) {
                int cost = first.charAt(i - 1) == second.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(
                        Math.min(current[j - 1] + 1, previous[j] + 1),
                        previous[j - 1] + cost
                );
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }
        return previous[second.length()];
    }

    private static String normalize(String value) {
        if (value == null) return "";
        String normalized = Normalizer.normalize(value.toLowerCase(new Locale("es", "PE")), Normalizer.Form.NFD);
        normalized = normalized.replaceAll("\\p{M}+", "");
        normalized = normalized.replaceAll("[^a-z0-9ñ]+", " ");
        return normalized.trim().replaceAll("\\s+", " ");
    }
}
