package com.brian.geoexponer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "geo_exponer_prefs";
    private static final String KEY_TEXT = "last_text";
    private static final String KEY_BATTERY_PROMPT_SHOWN = "battery_prompt_shown";

    private EditText inputText;
    private TextView currentPhrase;
    private TextView statusText;
    private Button startButton;

    private String lastState = ExpoPlaybackService.STATE_STOPPED;
    private int lastTotal = 0;

    private RadioButton speed025;
    private RadioButton speed050;
    private RadioButton speed0625;
    private RadioButton speed075;
    private RadioButton speed100;
    private RadioButton speed125;
    private RadioButton speed150;

    private RadioButton modeManual;
    private RadioButton modeAuto;
    private RadioButton modeMixed;
    private RadioButton delay0;
    private RadioButton delay1;
    private RadioButton delay2;
    private RadioButton delay3;
    private RadioButton delay5;
    private RadioButton delay8;
    private RadioButton delay10;

    private SharedPreferences prefs;

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!ExpoPlaybackService.ACTION_STATUS.equals(intent.getAction())) return;

            String phrase = intent.getStringExtra(ExpoPlaybackService.EXTRA_PHRASE);
            int index = intent.getIntExtra(ExpoPlaybackService.EXTRA_INDEX, 0);
            int total = intent.getIntExtra(ExpoPlaybackService.EXTRA_TOTAL, 0);
            String state = intent.getStringExtra(ExpoPlaybackService.EXTRA_STATE);

            if (phrase != null && phrase.trim().length() > 0) {
                currentPhrase.setText(phrase);
            }

            lastState = state != null ? state : ExpoPlaybackService.STATE_STOPPED;
            lastTotal = total;

            if (total > 0) {
                statusText.setText(stateText(state) + " - Frase " + index + " / " + total);
            } else {
                statusText.setText(stateText(state));
            }
            updateMainButtonText();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        inputText = findViewById(R.id.inputText);
        currentPhrase = findViewById(R.id.currentPhrase);
        statusText = findViewById(R.id.statusText);
        speed025 = findViewById(R.id.speed025);
        speed050 = findViewById(R.id.speed050);
        speed0625 = findViewById(R.id.speed0625);
        speed075 = findViewById(R.id.speed075);
        speed100 = findViewById(R.id.speed100);
        speed125 = findViewById(R.id.speed125);
        speed150 = findViewById(R.id.speed150);

        modeManual = findViewById(R.id.modeManual);
        modeAuto = findViewById(R.id.modeAuto);
        modeMixed = findViewById(R.id.modeMixed);
        delay0 = findViewById(R.id.delay0);
        delay1 = findViewById(R.id.delay1);
        delay2 = findViewById(R.id.delay2);
        delay3 = findViewById(R.id.delay3);
        delay5 = findViewById(R.id.delay5);
        delay8 = findViewById(R.id.delay8);
        delay10 = findViewById(R.id.delay10);

        startButton = findViewById(R.id.startButton);
        Button toggleButton = findViewById(R.id.toggleButton);
        Button repeatButton = findViewById(R.id.repeatButton);
        Button previousButton = findViewById(R.id.previousButton);
        Button nextButton = findViewById(R.id.nextButton);
        Button stopButton = findViewById(R.id.stopButton);
        Button memorizeButton = findViewById(R.id.memorizeButton);
        Button physicalControlsButton = findViewById(R.id.physicalControlsButton);

        inputText.setText(prefs.getString(KEY_TEXT, ""));
        inputText.setVerticalScrollBarEnabled(true);
        inputText.setOnTouchListener((v, event) -> {
            if (v.hasFocus()) {
                v.getParent().requestDisallowInterceptTouchEvent(true);
                if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                }
            }
            return false;
        });
        inputText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                prefs.edit().putString(KEY_TEXT, s.toString()).apply();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        setupSpeedButtons();
        setupModeButtons();
        setupDelayButtons();
        requestNotificationPermissionIfNeeded();
        requestBatteryPermissionIfNeeded(false);

        startButton.setOnClickListener(v -> mainButtonAction());
        toggleButton.setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_TOGGLE));
        repeatButton.setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_REPEAT));
        previousButton.setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_PREVIOUS));
        nextButton.setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_NEXT));
        stopButton.setOnClickListener(v -> sendSimpleAction(ExpoPlaybackService.ACTION_STOP));
        memorizeButton.setOnClickListener(v -> openMemorizeMode());
        physicalControlsButton.setOnClickListener(v -> showPhysicalControlsDialog());

        handlePossibleAssistantIntent(getIntent());
        updateMainButtonText();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handlePossibleAssistantIntent(intent);
    }


    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int keyCode = event.getKeyCode();
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
                && event.getAction() == KeyEvent.ACTION_DOWN
                && event.getRepeatCount() == 0) {
            if (practiceRunning()) {
                if (PhysicalControlSettings.isConfigured(this)) {
                    int physicalMode = PhysicalControlSettings.getMode(this);
                    if (PhysicalControlSettings.usesVolume(physicalMode)) {
                        sendSimpleAction(ExpoPlaybackService.ACTION_PHYSICAL_TOGGLE);
                    }
                } else if (modeMixed != null && modeMixed.isChecked()) {
                    // Preserve the previous behavior until the user configures the new option.
                    sendSimpleAction(ExpoPlaybackService.ACTION_TOGGLE);
                }
            }
            // Let Android also change the multimedia volume normally.
            return super.dispatchKeyEvent(event);
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_ASSIST
                || keyCode == KeyEvent.KEYCODE_VOICE_ASSIST
                || keyCode == KeyEvent.KEYCODE_HEADSETHOOK
                || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            sendSimpleAction(ExpoPlaybackService.ACTION_ASSIST_TOGGLE);
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    private void handlePossibleAssistantIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_VOICE_COMMAND.equals(action)) {
            sendSimpleAction(ExpoPlaybackService.ACTION_ASSIST_TOGGLE);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(ExpoPlaybackService.ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(statusReceiver, filter);
        }
        sendSimpleAction(ExpoPlaybackService.ACTION_STATUS_REQUEST);
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            unregisterReceiver(statusReceiver);
        } catch (IllegalArgumentException ignored) {
        }
    }

    private boolean practiceRunning() {
        return lastTotal > 0
                && !ExpoPlaybackService.STATE_STOPPED.equals(lastState)
                && !ExpoPlaybackService.STATE_ERROR.equals(lastState);
    }

    private void mainButtonAction() {
        if (practiceRunning()) {
            sendSimpleAction(ExpoPlaybackService.ACTION_TOGGLE);
        } else {
            startPractice();
        }
    }

    private void updateMainButtonText() {
        if (startButton == null) return;

        if (lastTotal <= 0 || ExpoPlaybackService.STATE_STOPPED.equals(lastState) || ExpoPlaybackService.STATE_ERROR.equals(lastState)) {
            startButton.setText("INICIAR PRÁCTICA");
        } else if (ExpoPlaybackService.STATE_WAITING.equals(lastState)) {
            if (isManualModeSelected()) {
                startButton.setText("CONTINUAR");
            } else {
                startButton.setText("PAUSAR");
            }
        } else if (ExpoPlaybackService.STATE_PAUSED.equals(lastState)) {
            startButton.setText("REANUDAR");
        } else if (ExpoPlaybackService.STATE_PLAYING.equals(lastState)) {
            startButton.setText("PAUSAR");
        } else {
            startButton.setText("CONTINUAR");
        }
    }

    private void startPractice() {
        String text = inputText.getText().toString().trim();
        if (text.length() < 2) {
            Toast.makeText(this, "Primero pega tu texto de exposición.", Toast.LENGTH_SHORT).show();
            return;
        }

        prefs.edit().putString(KEY_TEXT, text).apply();
        currentPhrase.setText("Preparando lectura...");
        statusText.setText("Iniciando práctica...");
        lastState = ExpoPlaybackService.STATE_PLAYING;
        lastTotal = 1;
        updateMainButtonText();

        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(ExpoPlaybackService.ACTION_START);
        intent.putExtra(ExpoPlaybackService.EXTRA_TEXT, text);
        intent.putExtra(ExpoPlaybackService.EXTRA_SPEED, getSelectedSpeed());
        intent.putExtra(ExpoPlaybackService.EXTRA_PAUSE_MS, getSelectedPauseMs());
        intent.putExtra(ExpoPlaybackService.EXTRA_MODE, getSelectedMode());
        startServiceCompat(intent);
    }

    private void showPhysicalControlsDialog() {
        String[] options = new String[]{
                "Desactivado",
                "Botones de volumen",
                "Encender/apagar pantalla",
                "Volumen + pantalla"
        };

        int selected = PhysicalControlSettings.getMode(this);
        final int[] pendingSelection = new int[]{selected};

        new AlertDialog.Builder(this)
                .setTitle("Controles físicos de pausa")
                .setSingleChoiceItems(options, selected, (dialog, which) -> pendingSelection[0] = which)
                .setPositiveButton("Guardar", (dialog, which) -> {
                    PhysicalControlSettings.saveMode(this, pendingSelection[0]);
                    Toast.makeText(this, "Control físico guardado: " + options[pendingSelection[0]], Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void openMemorizeMode() {
        String text = inputText.getText().toString().trim();
        if (text.length() < 2) {
            Toast.makeText(this, "Primero pega tu texto de exposición.", Toast.LENGTH_SHORT).show();
            return;
        }

        prefs.edit().putString(KEY_TEXT, text).apply();
        if (practiceRunning()) {
            sendSimpleAction(ExpoPlaybackService.ACTION_STOP);
        }

        Intent intent = new Intent(this, MemorizeActivity.class);
        intent.putExtra(MemorizeActivity.EXTRA_MEMORY_TEXT, text);
        startActivity(intent);
    }

    private void sendSettingsUpdateIfRunning() {
        if (!practiceRunning()) return;
        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(ExpoPlaybackService.ACTION_UPDATE_SETTINGS);
        intent.putExtra(ExpoPlaybackService.EXTRA_SPEED, getSelectedSpeed());
        startServiceCompat(intent);
    }

    private void sendSimpleAction(String action) {
        Intent intent = new Intent(this, ExpoPlaybackService.class);
        intent.setAction(action);
        startServiceCompat(intent);
    }

    private void startServiceCompat(Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    private void setupSpeedButtons() {
        RadioButton[] speeds = new RadioButton[]{speed025, speed050, speed0625, speed075, speed100, speed125, speed150};
        for (RadioButton button : speeds) {
            button.setOnClickListener(v -> {
                for (RadioButton item : speeds) {
                    item.setChecked(item == v);
                }
                sendSettingsUpdateIfRunning();
            });
        }
        speed100.setChecked(true);
    }

    private void setupModeButtons() {
        RadioButton[] modes = new RadioButton[]{modeManual, modeAuto, modeMixed};
        for (RadioButton button : modes) {
            button.setOnClickListener(v -> {
                for (RadioButton item : modes) {
                    item.setChecked(item == v);
                }
                updateMainButtonText();
            });
        }
        modeManual.setChecked(true);
    }

    private void setupDelayButtons() {
        RadioButton[] delays = new RadioButton[]{delay0, delay1, delay2, delay3, delay5, delay8, delay10};
        for (RadioButton button : delays) {
            button.setOnClickListener(v -> {
                for (RadioButton item : delays) {
                    item.setChecked(item == v);
                }
            });
        }
        delay1.setChecked(true);
    }

    private float getSelectedSpeed() {
        if (speed025.isChecked()) return 0.25f;
        if (speed050.isChecked()) return 0.50f;
        if (speed0625.isChecked()) return 0.625f;
        if (speed075.isChecked()) return 0.75f;
        if (speed125.isChecked()) return 1.25f;
        if (speed150.isChecked()) return 1.50f;
        speed100.setChecked(true);
        return 1.0f;
    }

    private boolean isManualModeSelected() {
        return modeManual != null && modeManual.isChecked();
    }

    private String getSelectedMode() {
        if (modeMixed != null && modeMixed.isChecked()) return ExpoPlaybackService.MODE_MIXED;
        if (modeAuto != null && modeAuto.isChecked()) return ExpoPlaybackService.MODE_AUTO;
        return ExpoPlaybackService.MODE_MANUAL;
    }

    private int getSelectedPauseMs() {
        if (isManualModeSelected()) return -1;
        if (delay0.isChecked()) return 0;
        if (delay1.isChecked()) return 1000;
        if (delay2.isChecked()) return 2000;
        if (delay3.isChecked()) return 3000;
        if (delay5.isChecked()) return 5000;
        if (delay8.isChecked()) return 8000;
        if (delay10.isChecked()) return 10000;
        delay1.setChecked(true);
        return 1000;
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
            }
        }
    }

    private void requestBatteryPermissionIfNeeded(boolean forcedByUser) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            if (forcedByUser) {
                Toast.makeText(this, "Tu Android no necesita este permiso.", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        if (isIgnoringBatteryOptimizations()) {
            if (forcedByUser) {
                Toast.makeText(this, "Permiso de batería ya permitido.", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        boolean shownBefore = prefs.getBoolean(KEY_BATTERY_PROMPT_SHOWN, false);
        if (!forcedByUser && shownBefore) {
            return;
        }

        prefs.edit().putBoolean(KEY_BATTERY_PROMPT_SHOWN, true).apply();

        new AlertDialog.Builder(this)
                .setTitle("Permiso de batería")
                .setMessage("Para que Geo Exponer no se cierre con la pantalla bloqueada, toca Permitir en el permiso de batería. En algunos celulares también debes poner la app en batería sin restricciones.")
                .setPositiveButton("Abrir permiso", (dialog, which) -> openBatteryPermissionScreen())
                .setNegativeButton("Luego", null)
                .show();
    }

    private boolean isIgnoringBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    private void openBatteryPermissionScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                return;
            } catch (Exception ignored) {
            }

            try {
                Intent intent = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                startActivity(intent);
                return;
            } catch (Exception ignored) {
            }
        }

        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception ignored) {
            Toast.makeText(this, "No se pudo abrir ajustes. Hazlo manual desde Ajustes > Batería.", Toast.LENGTH_LONG).show();
        }
    }

    private String stateText(String state) {
        if (ExpoPlaybackService.STATE_PLAYING.equals(state)) return "Reproduciendo";
        if (ExpoPlaybackService.STATE_PAUSED.equals(state)) return "Pausado";
        if (ExpoPlaybackService.STATE_STOPPED.equals(state)) return "Detenido";
        if (ExpoPlaybackService.STATE_WAITING.equals(state)) return "Esperando continuar";
        if (ExpoPlaybackService.STATE_ERROR.equals(state)) return "Error";
        return "Listo";
    }
}
