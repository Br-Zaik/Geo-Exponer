# Modo Memorizar con voz

Esta versión mantiene el modo normal de Geo Exponer y añade una pantalla independiente para memorizar.

## Acceso

- El modo normal sigue siendo la pantalla principal.
- El acceso a **Modo Memorizar** está en el engranaje ubicado junto al título **Geo Exponer**.
- Se eliminó el botón grande de memorizar que estaba al final de la pantalla principal.

## Selección por diapositivas

1. Pega todo el texto en la pantalla principal.
2. Usa encabezados como `Diapo 1. Portada.`, `Diapo 2. ¿Qué es el EPP?` o `Frase`.
3. Entra al engranaje.
4. La app organiza automáticamente el contenido por diapositivas.
5. Marca únicamente las diapositivas que quieras practicar.
6. Toca **EMPEZAR CON LO SELECCIONADO**.

Los encabezados `Diapo...`, `Diapositiva...` y `Frase` solo sirven para organizar. No se leen, no se repiten y no se comparan con la voz.

## Práctica

1. La app toma cada oración completa hasta el punto, signo de pregunta o signo de exclamación; luego la lee y la oculta.
2. Repítela en voz alta.
3. La app muestra lo que entendió y calcula la coincidencia.
4. Con 78 % o más avanza automáticamente.
5. Si falta una parte de la frase o la coincidencia queda por debajo de 78 %, la app vuelve a leer automáticamente la frase completa y abre un nuevo intento.
6. Después de leer la frase, la app mantiene una ventana de espera de hasta **45 segundos**. Si el reconocedor de Google se apaga antes por silencio, se reactiva automáticamente sin que tengas que tocar **REINTENTAR**.
7. Si pasan los 45 segundos sin detectar voz, la escucha se detiene para evitar un bucle permanente y queda disponible **REINTENTAR**.
8. Si el reconocimiento falla aunque la hayas dicho bien, usa **YO LO DIJE BIEN**.
9. **PAUSAR / REANUDAR** conserva la frase actual y continúa desde esa misma frase.
10. **Cambiar diapositivas seleccionadas** permite volver a la lista sin regresar al modo normal.

## Notas

- Requiere permiso de micrófono.
- El reconocimiento usa el servicio de voz disponible en el teléfono; según el dispositivo puede necesitar conexión.
- Para ruido de fondo, se recomienda usar auriculares con micrófono y hablar cerca de él.
- `ExpoPlaybackService.java` y `ButtonIntentReceiver.java` no fueron modificados.

## Continuar donde se dejó

- La app guarda la diapositiva, la frase actual, las diapositivas seleccionadas y la velocidad de voz.
- Al volver a entrar con el mismo texto, muestra **CONTINUAR DONDE LO DEJÉ**.
- También permite **Cambiar diapositivas** o **Empezar desde cero**.
- Si el texto principal cambia, el avance anterior no se mezcla con la nueva exposición y vuelve a la selección.
- Al completar todas las frases, el avance pendiente se considera terminado.
